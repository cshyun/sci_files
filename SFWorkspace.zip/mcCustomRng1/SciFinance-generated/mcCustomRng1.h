#ifndef MCCUSTOMRNG1_H
#define MCCUSTOMRNG1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcCustomRng1fn(
    double K,
    int pMax,
    int put,
    double q,
    double r,
    int Seed,
    double sigma,
    double Spot,
    double TMax,
    double & devx,
    double & Vx
    );
     


#endif /* MCCUSTOMRNG1_H */
