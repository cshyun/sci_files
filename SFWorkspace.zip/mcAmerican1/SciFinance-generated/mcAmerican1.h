#ifndef MCAMERICAN1_H
#define MCAMERICAN1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcAmerican1fn(
    double K,
    int maxord,
    int nExer,
    int pMax,
    int pMaxI,
    int put,
    double q,
    double r,
    int Seed,
    int SeedI,
    double sigma,
    double Spot,
    double SpotI,
    double TMax,
    double & devx,
    double & fracCalledx,
    double & meanTcallx,
    double & stdTcallx,
    double & Vx
    );
     


#endif /* MCAMERICAN1_H */
