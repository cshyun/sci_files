



#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcAmerican1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcAmerican1MW
#define openfilemcAmerican1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcAmerican1MR
#define openfilemcAmerican1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcAmerican1M
#define fscanfMmcAmerican1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }



int main()
{
    int maxord,nExer,pMax,pMaxI,Seed,SeedI;
    double devx,fracCalledx,K,meanTcallx,q,r,sigma,Spot,SpotI,stdTcallx,TMax,Vx;
    ArgumentRecord initInputTable[14];
    FILE *IOUNIT,*IOUNIT1;
    int put;
    
    /* *** Key to program variables: *** */
    /* devx: standard deviation error estimate */
    /* fracCalledx, K, maxord, meanTcallx, nExer, put, q, Seed, SeedI, sigma, Spot, SpotI, stdTcallx: solution variable 
       */
    /* IOUNIT, IOUNIT1: I/O channel */
    /* pMax: maximum for path */
    /* pMaxI: maximum for pathI */
    /* r: discount rate */
    /* TMax: maximum time */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcAmerican1MR(IOUNIT1,"init.dat");
    setupargs(initInputTable, 0, "K", K, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "maxord", maxord, READINPUTSINTEGER);
    setupargs(initInputTable, 2, "nExer", nExer, READINPUTSINTEGER);
    setupargs(initInputTable, 3, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 4, "pMaxI", pMaxI, READINPUTSINTEGER);
    setupargs(initInputTable, 5, "put", put, READINPUTSBOOLEAN);
    setupargs(initInputTable, 6, "q", q, READINPUTSDOUBLE);
    setupargs(initInputTable, 7, "r", r, READINPUTSDOUBLE);
    setupargs(initInputTable, 8, "Seed", Seed, READINPUTSINTEGER);
    setupargs(initInputTable, 9, "SeedI", SeedI, READINPUTSINTEGER);
    setupargs(initInputTable, 10, "sigma", sigma, READINPUTSDOUBLE);
    setupargs(initInputTable, 11, "Spot", Spot, READINPUTSDOUBLE);
    setupargs(initInputTable, 12, "SpotI", SpotI, READINPUTSDOUBLE);
    setupargs(initInputTable, 13, "TMax", TMax, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,initInputTable,14)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    /*                            */
    /* Call the computation function. */
    mcAmerican1fn(K,maxord,nExer,pMax,pMaxI,put,q,r,Seed,SeedI,sigma,Spot,SpotI,TMax,devx,fracCalledx,meanTcallx,
       stdTcallx,Vx);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfilemcAmerican1MW(IOUNIT,"V.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file V.out from ResultEq1c. */
    fprintf(IOUNIT, " %18.8e\n", devx);
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file V.out from ResultEq2c. */
    fprintf(IOUNIT, " %18.8e\n", meanTcallx);
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file V.out from ResultEq3c. */
    fprintf(IOUNIT, " %18.8e\n", stdTcallx);
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file V.out from ResultEq4c. */
    fprintf(IOUNIT, " %18.8e\n", fracCalledx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




