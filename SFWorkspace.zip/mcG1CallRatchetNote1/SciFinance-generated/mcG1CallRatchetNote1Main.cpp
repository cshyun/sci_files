

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for CouponDates in file "CouponDates.dat" has maximum index
      nCoup, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nCoup elements,
      to be stored in CouponDates(1..nCoup).

   The table for Gear in file "CouponDates.dat" has maximum index
      nCoup, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nCoup elements,
      to be stored in Gear(1..nCoup).

   The table for isCallable in file "CouponDates.dat" has maximum index
      nCoup, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nCoup elements,
      to be stored in isCallable(1..nCoup).

   The table for Ratchet in file "CouponDates.dat" has maximum index
      nCoup, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nCoup elements,
      to be stored in Ratchet(1..nCoup).

   The table for Spread in file "CouponDates.dat" has maximum index
      nCoup, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nCoup elements,
      to be stored in Spread(1..nCoup).

   The table for TCurve in file "ZCurve.dat" has maximum index
      nCurve, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nCurve elements,
      to be stored in TCurve(0..nCurve).

   The table for ZCurve in file "ZCurve.dat" has maximum index
      nCurve, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nCurve elements,
      to be stored in ZCurve(0..nCurve).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcG1CallRatchetNote1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcG1CallRatchetNote1MW
#define openfilemcG1CallRatchetNote1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcG1CallRatchetNote1MR
#define openfilemcG1CallRatchetNote1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcG1CallRatchetNote1M
#define fscanfMmcG1CallRatchetNote1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2

#undef spreadargs5
#define spreadargs5(a1,a2,a3,a4,a5) a1,a2,a3,a4,a5


int main()
{
    int itvar1,maxord1,maxord2,nCoup,nCurve,nMax,pMax,pMaxI,Series;
    double CallPrice,Flr,kappa,Notional,prevFixing,prevResetDate,sigma,Vx;
    ArgumentRecord g1noteInputTable[15];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3;
    
    /* *** Key to program variables: *** */
    /* CallPrice, CouponDates, Flr, Gear, isCallable, kappa, maxord1, maxord2, Notional, prevFixing, prevResetDate,     
       Ratchet, Series, sigma, Spread, TCurve, ZCurve: solution variable */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3: I/O channel */
    /* nCoup: array maximum for CouponDates, Gear, Spread, Ratchet and isCallable */
    /* nCurve: array maximum for TCurve and ZCurve */
    /* nMax: number of grid cells for t */
    /* pMax: maximum for path */
    /* pMaxI: maximum for pathI */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcG1CallRatchetNote1MR(IOUNIT1,"g1note.dat");
    setupargs(g1noteInputTable, 0, "CallPrice", CallPrice, READINPUTSDOUBLE);
    setupargs(g1noteInputTable, 1, "Flr", Flr, READINPUTSDOUBLE);
    setupargs(g1noteInputTable, 2, "kappa", kappa, READINPUTSDOUBLE);
    setupargs(g1noteInputTable, 3, "maxord1", maxord1, READINPUTSINTEGER);
    setupargs(g1noteInputTable, 4, "maxord2", maxord2, READINPUTSINTEGER);
    setupargs(g1noteInputTable, 5, "nCoup", nCoup, READINPUTSINTEGER);
    setupargs(g1noteInputTable, 6, "nCurve", nCurve, READINPUTSINTEGER);
    setupargs(g1noteInputTable, 7, "nMax", nMax, READINPUTSINTEGER);
    setupargs(g1noteInputTable, 8, "Notional", Notional, READINPUTSDOUBLE);
    setupargs(g1noteInputTable, 9, "pMax", pMax, READINPUTSINTEGER);
    setupargs(g1noteInputTable, 10, "pMaxI", pMaxI, READINPUTSINTEGER);
    setupargs(g1noteInputTable, 11, "prevFixing", prevFixing, READINPUTSDOUBLE);
    setupargs(g1noteInputTable, 12, "prevResetDate", prevResetDate, READINPUTSDOUBLE);
    setupargs(g1noteInputTable, 13, "Series", Series, READINPUTSINTEGER);
    setupargs(g1noteInputTable, 14, "sigma", sigma, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,g1noteInputTable,15)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    SciArray1<double>CouponDates(nCoup + 1);
    SciArray1<double>Gear(nCoup + 1);
    SciArray1<double>Spread(nCoup + 1);
    SciArray1<double>Ratchet(nCoup + 1);
    SciArray1<int>isCallable(nCoup + 1);
    /* Read CouponDates from file. Read Gear from file. Read Spread from file. Read Ratchet from file. Read isCallable  
       from file */
    if (nCoup>=1)
        {
        openfilemcG1CallRatchetNote1MR(IOUNIT2,"CouponDates.dat");
        for (itvar1=1; itvar1<=nCoup; itvar1++) {
            fscanfMmcG1CallRatchetNote1M(IOUNIT2,
               "%lg%lg%lg%lg%i"
               ,5,((&CouponDates(itvar1)),(&Gear(itvar1)),(&Spread(itvar1)),(&Ratchet(itvar1)),(&isCallable(itvar1))));
        }
        fclose(IOUNIT2);
        }
    SciArray1<double>TCurve(nCurve + 1);
    SciArray1<double>ZCurve(nCurve + 1);
    /* Read TCurve from file. Read ZCurve from file */
    if (nCurve>=0)
        {
        openfilemcG1CallRatchetNote1MR(IOUNIT3,"ZCurve.dat");
        for (itvar1=0; itvar1<=nCurve; itvar1++) {
            fscanfMmcG1CallRatchetNote1M(IOUNIT3,"%lg%lg",2,((&TCurve(itvar1)),(&ZCurve(itvar1))));
        }
        fclose(IOUNIT3);
        }
    /*                            */
    /* Call the computation function. */
    mcG1CallRatchetNote1fn(CallPrice,CouponDates,Flr,Gear,isCallable,kappa,maxord1,maxord2,nCoup,nCurve,nMax,Notional,
       pMax,pMaxI,prevFixing,prevResetDate,Ratchet,Series,sigma,Spread,TCurve,ZCurve,Vx);
    /*                            */
    /* Writing collected output to file atSpot.out from ResultEqc. */
    openfilemcG1CallRatchetNote1MW(IOUNIT,"atSpot.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




