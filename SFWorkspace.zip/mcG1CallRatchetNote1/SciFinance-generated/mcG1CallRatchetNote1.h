#ifndef MCG1CALLRATCHETNOTE1_H
#define MCG1CALLRATCHETNOTE1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcG1CallRatchetNote1fn(
    double CallPrice,
    const SciArray1<double>& CouponDates,
    double Flr,
    const SciArray1<double>& Gear,
    const SciArray1<int>& isCallable,
    double kappa,
    int maxord1,
    int maxord2,
    int nCoup,
    int nCurve,
    int nMax,
    double Notional,
    int pMax,
    int pMaxI,
    double prevFixing,
    double prevResetDate,
    const SciArray1<double>& Ratchet,
    int Series,
    double sigma,
    const SciArray1<double>& Spread,
    const SciArray1<double>& TCurve,
    const SciArray1<double>& ZCurve,
    double & Vx
    );
     


#endif /* MCG1CALLRATCHETNOTE1_H */
