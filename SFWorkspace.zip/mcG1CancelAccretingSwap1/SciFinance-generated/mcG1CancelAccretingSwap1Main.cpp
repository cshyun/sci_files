

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for CouponDatesFixed in file "CouponDataFixed.dat" has maximum index
      nCpnFixed, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nCpnFixed elements,
      to be stored in CouponDatesFixed(1..nCpnFixed).

   The table for CouponDatesFloat in file "CouponDataFloat.dat" has maximum index
      nCpnFloat, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nCpnFloat elements,
      to be stored in CouponDatesFloat(1..nCpnFloat).

   The table for ExerciseDates in file "ExerciseDates.dat" has maximum index
      nExer, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nExer elements,
      to be stored in ExerciseDates(1..nExer).

   The table for Nfixed in file "CouponDataFixed.dat" has maximum index
      nCpnFixed, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nCpnFixed elements,
      to be stored in Nfixed(1..nCpnFixed).

   The table for Nfloat in file "CouponDataFloat.dat" has maximum index
      nCpnFloat, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nCpnFloat elements,
      to be stored in Nfloat(1..nCpnFloat).

   The table for zDates in file "ZeroCurve.dat" has maximum index
      nZero, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nZero elements,
      to be stored in zDates(0..nZero).

   The table for zRates in file "ZeroCurve.dat" has maximum index
      nZero, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nZero elements,
      to be stored in zRates(0..nZero).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcG1CancelAccretingSwap1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcG1CancelAccretingSwap1MW
#define openfilemcG1CancelAccretingSwap1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcG1CancelAccretingSwap1MR
#define openfilemcG1CancelAccretingSwap1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcG1CancelAccretingSwap1M
#define fscanfMmcG1CancelAccretingSwap1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2


int main()
{
    int itvar1,maxord1,maxord2,nCpnFixed,nCpnFloat,nExer,nMax,nZero,pMax,Series;
    double CallPrice,CommenceDate,CouponFixed,Gear,kappa,PastLibor,sigma,Spread,Vx;
    ArgumentRecord initInputTable[18];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4,*IOUNIT5;
    int isPayer;
    
    /* *** Key to program variables: *** */
    /* CallPrice, CommenceDate, CouponDatesFixed, CouponDatesFloat, CouponFixed, ExerciseDates, Gear, isPayer, kappa,   
       maxord1, maxord2, Nfixed, Nfloat, PastLibor, Series, sigma, Spread, zDates, zRates: solution variable */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5: I/O channel */
    /* nCpnFixed: array maximum for CouponDatesFixed and Nfixed */
    /* nCpnFloat: array maximum for CouponDatesFloat and Nfloat */
    /* nExer: array maximum for ExerciseDates */
    /* nMax: number of grid cells for t */
    /* nZero: array maximum for zDates and zRates */
    /* pMax: maximum for path */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcG1CancelAccretingSwap1MR(IOUNIT1,"init.dat");
    setupargs(initInputTable, 0, "CallPrice", CallPrice, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "CommenceDate", CommenceDate, READINPUTSDOUBLE);
    setupargs(initInputTable, 2, "CouponFixed", CouponFixed, READINPUTSDOUBLE);
    setupargs(initInputTable, 3, "Gear", Gear, READINPUTSDOUBLE);
    setupargs(initInputTable, 4, "isPayer", isPayer, READINPUTSBOOLEAN);
    setupargs(initInputTable, 5, "kappa", kappa, READINPUTSDOUBLE);
    setupargs(initInputTable, 6, "maxord1", maxord1, READINPUTSINTEGER);
    setupargs(initInputTable, 7, "maxord2", maxord2, READINPUTSINTEGER);
    setupargs(initInputTable, 8, "nCpnFixed", nCpnFixed, READINPUTSINTEGER);
    setupargs(initInputTable, 9, "nCpnFloat", nCpnFloat, READINPUTSINTEGER);
    setupargs(initInputTable, 10, "nExer", nExer, READINPUTSINTEGER);
    setupargs(initInputTable, 11, "nMax", nMax, READINPUTSINTEGER);
    setupargs(initInputTable, 12, "nZero", nZero, READINPUTSINTEGER);
    setupargs(initInputTable, 13, "PastLibor", PastLibor, READINPUTSDOUBLE);
    setupargs(initInputTable, 14, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 15, "Series", Series, READINPUTSINTEGER);
    setupargs(initInputTable, 16, "sigma", sigma, READINPUTSDOUBLE);
    setupargs(initInputTable, 17, "Spread", Spread, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,initInputTable,18)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    SciArray1<double>CouponDatesFixed(nCpnFixed + 1);
    SciArray1<double>Nfixed(nCpnFixed + 1);
    /* Read CouponDatesFixed from file. Read Nfixed from file */
    if (nCpnFixed>=1)
        {
        openfilemcG1CancelAccretingSwap1MR(IOUNIT2,"CouponDataFixed.dat");
        for (itvar1=1; itvar1<=nCpnFixed; itvar1++) {
            fscanfMmcG1CancelAccretingSwap1M(IOUNIT2,"%lg%lg",2,((&CouponDatesFixed(itvar1)),(&Nfixed(itvar1))));
        }
        fclose(IOUNIT2);
        }
    SciArray1<double>CouponDatesFloat(nCpnFloat + 1);
    SciArray1<double>Nfloat(nCpnFloat + 1);
    /* Read CouponDatesFloat from file. Read Nfloat from file */
    if (nCpnFloat>=1)
        {
        openfilemcG1CancelAccretingSwap1MR(IOUNIT3,"CouponDataFloat.dat");
        for (itvar1=1; itvar1<=nCpnFloat; itvar1++) {
            fscanfMmcG1CancelAccretingSwap1M(IOUNIT3,"%lg%lg",2,((&CouponDatesFloat(itvar1)),(&Nfloat(itvar1))));
        }
        fclose(IOUNIT3);
        }
    /* Read ExerciseDates from file */
    SciArray1<double>ExerciseDates(nExer + 1);
    if (nExer>=1)
        {
        openfilemcG1CancelAccretingSwap1MR(IOUNIT4,"ExerciseDates.dat");
        for (itvar1=1; itvar1<=nExer; itvar1++) {
            fscanfMmcG1CancelAccretingSwap1M(IOUNIT4,"%lg",1,((&ExerciseDates(itvar1))));
        }
        fclose(IOUNIT4);
        }
    SciArray1<double>zDates(nZero + 1);
    SciArray1<double>zRates(nZero + 1);
    /* Read zDates from file. Read zRates from file */
    if (nZero>=0)
        {
        openfilemcG1CancelAccretingSwap1MR(IOUNIT5,"ZeroCurve.dat");
        for (itvar1=0; itvar1<=nZero; itvar1++) {
            fscanfMmcG1CancelAccretingSwap1M(IOUNIT5,"%lg%lg",2,((&zDates(itvar1)),(&zRates(itvar1))));
        }
        fclose(IOUNIT5);
        }
    /*                            */
    /* Call the computation function. */
    mcG1CancelAccretingSwap1fn(CallPrice,CommenceDate,CouponDatesFixed,CouponDatesFloat,CouponFixed,ExerciseDates,Gear,
       isPayer,kappa,maxord1,maxord2,nCpnFixed,nCpnFloat,nExer,Nfixed,Nfloat,nMax,nZero,PastLibor,pMax,Series,sigma,
       Spread,zDates,zRates,Vx);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfilemcG1CancelAccretingSwap1MW(IOUNIT,"V.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




