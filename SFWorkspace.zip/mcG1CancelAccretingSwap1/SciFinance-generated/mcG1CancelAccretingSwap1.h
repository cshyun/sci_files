#ifndef MCG1CANCELACCRETINGSWAP1_H
#define MCG1CANCELACCRETINGSWAP1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcG1CancelAccretingSwap1fn(
    double CallPrice,
    double CommenceDate,
    const SciArray1<double>& CouponDatesFixed,
    const SciArray1<double>& CouponDatesFloat,
    double CouponFixed,
    const SciArray1<double>& ExerciseDates,
    double Gear,
    int isPayer,
    double kappa,
    int maxord1,
    int maxord2,
    int nCpnFixed,
    int nCpnFloat,
    int nExer,
    const SciArray1<double>& Nfixed,
    const SciArray1<double>& Nfloat,
    int nMax,
    int nZero,
    double PastLibor,
    int pMax,
    int Series,
    double sigma,
    double Spread,
    const SciArray1<double>& zDates,
    const SciArray1<double>& zRates,
    double & Vx
    );
     


#endif /* MCG1CANCELACCRETINGSWAP1_H */
