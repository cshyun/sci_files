/*** Key to program variables: ***
  CalibOptsx: solution variable; an input
  ftol: solution variable; an input
  MarketFitx: solution variable; an input
  nOpt: array maximum for OptionMatrix; an input
  OptionMatrix: solution variable; an input
  Paramsx: solution variable; an input
  pGuess: solution variable; an input
  pMax: solution variable; an input
  pMin: solution variable; an input
  xtol: solution variable; an input
  infox: solution variable; an output
  nColx: array maximum for OptionMatrix; an output
  nDx: array maximum for pGuess, pMin and pMax; an output
  nfevx: solution variable; an output
  RMSFitx: solution variable; an output
  tmpx: solution variable; an output
*** end Key to program variables: ***/


/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for OptionMatrix in file "OptionMatrix.dat" has maximum indices
      nOpt and nCol, 
     with minimum indices 1, 1 respectively.
      The index bounds are not read from this file.
        Following should be the nCol*nOpt elements,
      to be stored in OptionMatrix(1..nOpt, 1..nCol).
   The first index is the most slowly varying and 
      the last index is the most rapidly varying.

   The table for pGuess in file "Params.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in pGuess(1..nD).

   The table for pMax in file "Params.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in pMax(1..nD).

   The table for pMin in file "Params.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in pMin(1..nD).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "calATMS971.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilecalATMS971MW
#define openfilecalATMS971MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilecalATMS971MR
#define openfilecalATMS971MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMcalATMS971M
#define fscanfMcalATMS971M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs3
#define spreadargs3(a1,a2,a3) a1,a2,a3


int main()
{
    int iCol,inD,infox,iOpt,iOpt1,itvar1,itvar2,nCol,nColx,nD,nDx,nfevx,nOpt,tmpx;
    double **CalibOptsC,ftol,*MarketFitC,*ParamsC,RMSFitx,xtol;
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4,*IOUNIT5,*IOUNIT6;
    ArgumentRecord taggedvarsInputTable[3];
    
    /* *** Key to program variables: *** */
    /* CalibOpts, ftol, infox, MarketFit, nfevx, OptionMatrix, Params, pGuess, pMax, pMin, RMSFitx, tmpx, xtol: solution
       variable */
    /* iCol, iOpt: index variable for OptionMatrix */
    /* inD: index variable for pGuess */
    /* iOpt1: index variable for MarketFit */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5, IOUNIT6: I/O channel */
    /* nCol, nColx, nOpt: array maximum for OptionMatrix */
    /* nD, nDx: array maximum for pGuess, pMin and pMax */
    try {
    /* Read Tagged Input File */
    openfilecalATMS971MR(IOUNIT4,"taggedvars.dat");
    setupargs(taggedvarsInputTable, 0, "ftol", ftol, READINPUTSDOUBLE);
    setupargs(taggedvarsInputTable, 1, "nOpt", nOpt, READINPUTSINTEGER);
    setupargs(taggedvarsInputTable, 2, "xtol", xtol, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT4,taggedvarsInputTable,3)!=0)
        {
        fclose(IOUNIT4);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT4);
    nCol = 4;
    nD = 4;
    /* Read OptionMatrix from file */
    SciArray2<double>OptionMatrix(nOpt + 1, nCol + 1);
    if ((nCol>=1&&nOpt>=1))
        {
        openfilecalATMS971MR(IOUNIT5,"OptionMatrix.dat");
        for (itvar1=1; itvar1<=nOpt; itvar1++) {
            for (itvar2=1; itvar2<=nCol; itvar2++) {
                fscanfMcalATMS971M(IOUNIT5,"%lg",1,((&OptionMatrix(itvar1,itvar2))));
            }
        }
        fclose(IOUNIT5);
        }
    SciArray1<double>pGuess(nD + 1);
    SciArray1<double>pMin(nD + 1);
    SciArray1<double>pMax(nD + 1);
    /* Read pGuess from file. Read pMin from file. Read pMax from file */
    if (nD>=1)
        {
        openfilecalATMS971MR(IOUNIT6,"Params.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMcalATMS971M(IOUNIT6,"%lg%lg%lg",3,((&pGuess(itvar1)),(&pMin(itvar1)),(&pMax(itvar1))));
        }
        fclose(IOUNIT6);
        }
    /*                            */
    /* Call the computation function. */
    calATMS971fnC(&CalibOptsC,ftol,&MarketFitC,nOpt,OptionMatrix.array(),&ParamsC,pGuess.array(),pMax.array(),pMin.array
       (),xtol,&infox,&nColx,&nDx,&nfevx,&RMSFitx,&tmpx);
    SciArray2Ref<double> CalibOpts(CalibOptsC, nOpt + 1, nColx + 1);
    SciArray1Ref<double> MarketFit(MarketFitC, tmpx + 1);
    SciArray1Ref<double> Params(ParamsC, nDx + 1);
    /*                            */
    /* Writing collected output to file CalibOpts.out from ResultEqc. */
    openfilecalATMS971MW(IOUNIT,"CalibOpts.out");
    for (iOpt=1; iOpt<=nOpt; iOpt++) {
        for (iCol=1; iCol<=nColx; iCol++) {
            fprintf(IOUNIT, " %18.8e\n", CalibOpts(iOpt,iCol));
        }
    }
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* Writing collected output to file MarketFit.out from ResultEq1c. */
    openfilecalATMS971MW(IOUNIT1,"MarketFit.out");
    for (iOpt1=1; iOpt1<=tmpx; iOpt1++) {
        fprintf(IOUNIT1, " %18.8e\n", MarketFit(iOpt1));
    }
    fprintf(IOUNIT1, "\n");
    fclose(IOUNIT1);
    /* Writing collected output to file Params.out from ResultEq2c. */
    openfilecalATMS971MW(IOUNIT2,"Params.out");
    for (inD=1; inD<=nDx; inD++) {
        fprintf(IOUNIT2, " %18.8e\n", Params(inD));
    }
    fprintf(IOUNIT2, "\n");
    fclose(IOUNIT2);
    /* Writing collected output to file Diagnostics.out from ResultEq3c. */
    openfilecalATMS971MW(IOUNIT3,"Diagnostics.out");
    fprintf(IOUNIT3, " %i\n", infox);
    fprintf(IOUNIT3, "\n");
    /* Writing collected output to file Diagnostics.out from ResultEq4c. */
    fprintf(IOUNIT3, " %i\n", nfevx);
    fprintf(IOUNIT3, "\n");
    /* Writing collected output to file Diagnostics.out from ResultEq5c. */
    fprintf(IOUNIT3, " %18.8e\n", RMSFitx);
    fprintf(IOUNIT3, "\n");
    fclose(IOUNIT3);
    SciAlloc<double>::free(CalibOptsC, nOpt + 1, nColx + 1);
    delete[] MarketFitC;
    delete[] ParamsC;
    return 0;
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




