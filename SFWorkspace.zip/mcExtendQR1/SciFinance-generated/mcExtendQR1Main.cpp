

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for D0 in file "D0.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in D0(1..nD).

   The table for loan in file "loan.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in loan(1..nD).

   The table for rho in file "rho.dat" has maximum indices
      nD and nD, 
     with minimum indices 1, 1 respectively.
      The index bounds are not read from this file.
        Following should be the nD^2 elements,
      to be stored in rho(1..nD, 1..nD).
   The first index is the most slowly varying and 
      the last index is the most rapidly varying.

   The table for sigma in file "sigma.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in sigma(1..nD).

   The table for Spot in file "Spot.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in Spot(1..nD).

   The table for tsample in file "A1samplingTime.dat" has maximum index
      nsampleToGoA1, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nsampleToGoA1 elements,
      to be stored in tsample(1..nsampleToGoA1).

   The table for weight in file "weight.dat" has maximum indices
      nD and nsampleToGoA1, 
     with minimum indices 1, 1 respectively.
      The index bounds are not read from this file.
        Following should be the nD*nsampleToGoA1 elements,
      to be stored in weight(1..nD, 1..nsampleToGoA1).
   The first index is the most slowly varying and 
      the last index is the most rapidly varying.


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcExtendQR1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcExtendQR1MW
#define openfilemcExtendQR1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcExtendQR1MR
#define openfilemcExtendQR1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcExtendQR1M
#define fscanfMmcExtendQR1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1


int main()
{
    int itvar1,itvar2,nD,nQRDimMax,nsampleToGoA1,pMax,Seed,Series;
    double disc,K,lastA1,TMax,Vx;
    ArgumentRecord initInputTable[10];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4,*IOUNIT5,*IOUNIT6,*IOUNIT7,*IOUNIT8;
    
    /* *** Key to program variables: *** */
    /* D0, K, lastA1, loan, rho, Seed, Series, sigma, Spot, weight: solution variable */
    /* disc: discount rate */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5, IOUNIT6, IOUNIT7, IOUNIT8: I/O channel */
    /* nD: maximum for i */
    /* nQRDimMax: maximum for extending Sobol */
    /* nsampleToGoA1: array maximum for tsample */
    /* pMax: maximum for path */
    /* TMax: maximum time */
    /* tsample: Sample array for Path */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcExtendQR1MR(IOUNIT1,"init.dat");
    setupargs(initInputTable, 0, "disc", disc, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "K", K, READINPUTSDOUBLE);
    setupargs(initInputTable, 2, "lastA1", lastA1, READINPUTSDOUBLE);
    setupargs(initInputTable, 3, "nD", nD, READINPUTSINTEGER);
    setupargs(initInputTable, 4, "nQRDimMax", nQRDimMax, READINPUTSINTEGER);
    setupargs(initInputTable, 5, "nsampleToGoA1", nsampleToGoA1, READINPUTSINTEGER);
    setupargs(initInputTable, 6, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 7, "Seed", Seed, READINPUTSINTEGER);
    setupargs(initInputTable, 8, "Series", Series, READINPUTSINTEGER);
    setupargs(initInputTable, 9, "TMax", TMax, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,initInputTable,10)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    /* Read tsample from file */
    SciArray1<double>tsample(nsampleToGoA1 + 1);
    if (nsampleToGoA1>=1)
        {
        openfilemcExtendQR1MR(IOUNIT2,"A1samplingTime.dat");
        for (itvar1=1; itvar1<=nsampleToGoA1; itvar1++) {
            fscanfMmcExtendQR1M(IOUNIT2,"%lg",1,((&tsample(itvar1))));
        }
        fclose(IOUNIT2);
        }
    SciArray1<double>D0(nD + 1);
    SciArray1<double>loan(nD + 1);
    SciArray2<double>rho(nD + 1, nD + 1);
    SciArray1<double>sigma(nD + 1);
    SciArray1<double>Spot(nD + 1);
    if (nD>=1)
        {
        /* Read D0 from file */
        openfilemcExtendQR1MR(IOUNIT3,"D0.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcExtendQR1M(IOUNIT3,"%lg",1,((&D0(itvar1))));
        }
        fclose(IOUNIT3);
        /* Read loan from file */
        openfilemcExtendQR1MR(IOUNIT4,"loan.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcExtendQR1M(IOUNIT4,"%lg",1,((&loan(itvar1))));
        }
        fclose(IOUNIT4);
        /* Read rho from file */
        openfilemcExtendQR1MR(IOUNIT5,"rho.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            for (itvar2=1; itvar2<=nD; itvar2++) {
                fscanfMmcExtendQR1M(IOUNIT5,"%lg",1,((&rho(itvar1,itvar2))));
            }
        }
        fclose(IOUNIT5);
        /* Read sigma from file */
        openfilemcExtendQR1MR(IOUNIT6,"sigma.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcExtendQR1M(IOUNIT6,"%lg",1,((&sigma(itvar1))));
        }
        fclose(IOUNIT6);
        /* Read Spot from file */
        openfilemcExtendQR1MR(IOUNIT7,"Spot.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcExtendQR1M(IOUNIT7,"%lg",1,((&Spot(itvar1))));
        }
        fclose(IOUNIT7);
        }
    /* Read weight from file */
    SciArray2<double>weight(nD + 1, nsampleToGoA1 + 1);
    if ((nD>=1&&nsampleToGoA1>=1))
        {
        openfilemcExtendQR1MR(IOUNIT8,"weight.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            for (itvar2=1; itvar2<=nsampleToGoA1; itvar2++) {
                fscanfMmcExtendQR1M(IOUNIT8,"%lg",1,((&weight(itvar1,itvar2))));
            }
        }
        fclose(IOUNIT8);
        }
    /*                            */
    /* Call the computation function. */
    mcExtendQR1fn(D0,disc,K,lastA1,loan,nD,nQRDimMax,nsampleToGoA1,pMax,rho,Seed,Series,sigma,Spot,TMax,tsample,weight,
       Vx);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfilemcExtendQR1MW(IOUNIT,"V.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




