#ifndef MCEXTENDQR1_H
#define MCEXTENDQR1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcExtendQR1fn(
    const SciArray1<double>& D0,
    double disc,
    double K,
    double lastA1,
    const SciArray1<double>& loan,
    int nD,
    int nQRDimMax,
    int nsampleToGoA1,
    int pMax,
    const SciArray2<double>& rho,
    int Seed,
    int Series,
    const SciArray1<double>& sigma,
    const SciArray1<double>& Spot,
    double TMax,
    const SciArray1<double>& tsample,
    const SciArray2<double>& weight,
    double & Vx
    );
     


#endif /* MCEXTENDQR1_H */
