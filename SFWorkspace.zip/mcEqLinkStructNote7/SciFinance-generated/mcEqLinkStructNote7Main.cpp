

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for Currency in file "FundData.dat" has maximum index
      nFund, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nFund elements,
      to be stored in Currency(1..nFund).

   The table for EvalDate in file "EvalDates.dat" has maximum index
      nEval, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nEval elements,
      to be stored in EvalDate(1..nEval).

   The table for FundRef0 in file "FundData.dat" has maximum index
      nFund, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nFund elements,
      to be stored in FundRef0(1..nFund).

   The table for FundSpot in file "FundData.dat" has maximum index
      nFund, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nFund elements,
      to be stored in FundSpot(1..nFund).

   The table for LockedRtnHist in file "EvalDates.dat" has maximum index
      nEval, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nEval elements,
      to be stored in LockedRtnHist(1..nEval).

   The table for MgtFee in file "FundData.dat" has maximum index
      nFund, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nFund elements,
      to be stored in MgtFee(1..nFund).

   The table for PortfolioWeight in file "PortfolioWeight.dat" has maximum indices
      nFund and nPortfolio, 
     with minimum indices 1, 1 respectively.
      The index bounds are not read from this file.
        Following should be the nFund*nPortfolio elements,
      to be stored in PortfolioWeight(1..nFund, 1..nPortfolio).
   The first index is the most slowly varying and 
      the last index is the most rapidly varying.

   The table for rho in file "rho.dat" has maximum indices
      nFund and nFund, 
     with minimum indices 1, 1 respectively.
      The index bounds are not read from this file.
        Following should be the nFund^2 elements,
      to be stored in rho(1..nFund, 1..nFund).
   The first index is the most slowly varying and 
      the last index is the most rapidly varying.

   The table for sigma in file "FundData.dat" has maximum index
      nFund, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nFund elements,
      to be stored in sigma(1..nFund).

   The table for ZeroDates1 in file "ZeroCurve1.dat" has maximum index
      nZero1, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nZero1 elements,
      to be stored in ZeroDates1(0..nZero1).

   The table for ZeroDates2 in file "ZeroCurve2.dat" has maximum index
      nZero2, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nZero2 elements,
      to be stored in ZeroDates2(0..nZero2).

   The table for ZeroDates3 in file "ZeroCurve3.dat" has maximum index
      nZero3, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nZero3 elements,
      to be stored in ZeroDates3(0..nZero3).

   The table for ZeroDates4 in file "ZeroCurve4.dat" has maximum index
      nZero4, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nZero4 elements,
      to be stored in ZeroDates4(0..nZero4).

   The table for ZeroRates1 in file "ZeroCurve1.dat" has maximum index
      nZero1, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nZero1 elements,
      to be stored in ZeroRates1(0..nZero1).

   The table for ZeroRates2 in file "ZeroCurve2.dat" has maximum index
      nZero2, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nZero2 elements,
      to be stored in ZeroRates2(0..nZero2).

   The table for ZeroRates3 in file "ZeroCurve3.dat" has maximum index
      nZero3, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nZero3 elements,
      to be stored in ZeroRates3(0..nZero3).

   The table for ZeroRates4 in file "ZeroCurve4.dat" has maximum index
      nZero4, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nZero4 elements,
      to be stored in ZeroRates4(0..nZero4).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcEqLinkStructNote7.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcEqLinkStructNote7MW
#define openfilemcEqLinkStructNote7MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcEqLinkStructNote7MR
#define openfilemcEqLinkStructNote7MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcEqLinkStructNote7M
#define fscanfMmcEqLinkStructNote7M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2

#undef spreadargs5
#define spreadargs5(a1,a2,a3,a4,a5) a1,a2,a3,a4,a5


int main()
{
    int cumulative,DomCurrency,itvar1,itvar2,nEval,nFund,nMax,nPortfolio,nZero1,nZero2,nZero3,nZero4,pMax,Series;
    ArgumentRecord initInputTable[16];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4,*IOUNIT5,*IOUNIT6,*IOUNIT7,*IOUNIT8,*IOUNIT9;
    double MaturityDate,Notional,PR,Strike,Vx;
    
    /* *** Key to program variables: *** */
    /* cumulative, Currency, DomCurrency, EvalDate, FundRef0, FundSpot, LockedRtnHist, MaturityDate, MgtFee, Notional,  
       PortfolioWeight, PR, rho, Series, sigma, Strike, ZeroDates1, ZeroDates2, ZeroDates3, ZeroDates4, ZeroRates1,     
       ZeroRates2, ZeroRates3, ZeroRates4: solution variable */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5, IOUNIT6, IOUNIT7, IOUNIT8, IOUNIT9: I/O channel */
    /* nEval: array maximum for EvalDate and LockedRtnHist */
    /* nFund: maximum for iFund */
    /* nMax: number of grid cells for t */
    /* nPortfolio: array maximum for PortfolioWeight */
    /* nZero1: array maximum for ZeroDates1 and ZeroRates1 */
    /* nZero2: array maximum for ZeroDates2 and ZeroRates2 */
    /* nZero3: array maximum for ZeroDates3 and ZeroRates3 */
    /* nZero4: array maximum for ZeroDates4 and ZeroRates4 */
    /* pMax: maximum for path */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcEqLinkStructNote7MR(IOUNIT1,"init.dat");
    setupargs(initInputTable, 0, "cumulative", cumulative, READINPUTSINTEGER);
    setupargs(initInputTable, 1, "DomCurrency", DomCurrency, READINPUTSINTEGER);
    setupargs(initInputTable, 2, "MaturityDate", MaturityDate, READINPUTSDOUBLE);
    setupargs(initInputTable, 3, "nEval", nEval, READINPUTSINTEGER);
    setupargs(initInputTable, 4, "nFund", nFund, READINPUTSINTEGER);
    setupargs(initInputTable, 5, "nMax", nMax, READINPUTSINTEGER);
    setupargs(initInputTable, 6, "Notional", Notional, READINPUTSDOUBLE);
    setupargs(initInputTable, 7, "nPortfolio", nPortfolio, READINPUTSINTEGER);
    setupargs(initInputTable, 8, "nZero1", nZero1, READINPUTSINTEGER);
    setupargs(initInputTable, 9, "nZero2", nZero2, READINPUTSINTEGER);
    setupargs(initInputTable, 10, "nZero3", nZero3, READINPUTSINTEGER);
    setupargs(initInputTable, 11, "nZero4", nZero4, READINPUTSINTEGER);
    setupargs(initInputTable, 12, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 13, "PR", PR, READINPUTSDOUBLE);
    setupargs(initInputTable, 14, "Series", Series, READINPUTSINTEGER);
    setupargs(initInputTable, 15, "Strike", Strike, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,initInputTable,16)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    SciArray1<double>EvalDate(nEval + 1);
    SciArray1<double>LockedRtnHist(nEval + 1);
    /* Read EvalDate from file. Read LockedRtnHist from file */
    if (nEval>=1)
        {
        openfilemcEqLinkStructNote7MR(IOUNIT2,"EvalDates.dat");
        for (itvar1=1; itvar1<=nEval; itvar1++) {
            fscanfMmcEqLinkStructNote7M(IOUNIT2,"%lg%lg",2,((&EvalDate(itvar1)),(&LockedRtnHist(itvar1))));
        }
        fclose(IOUNIT2);
        }
    SciArray1<double>FundSpot(nFund + 1);
    SciArray1<double>FundRef0(nFund + 1);
    SciArray1<double>sigma(nFund + 1);
    SciArray1<int>Currency(nFund + 1);
    SciArray1<double>MgtFee(nFund + 1);
    /* Read FundSpot from file. Read FundRef0 from file. Read sigma from file. Read Currency from file. Read MgtFee from
       file */
    if (nFund>=1)
        {
        openfilemcEqLinkStructNote7MR(IOUNIT3,"FundData.dat");
        for (itvar1=1; itvar1<=nFund; itvar1++) {
            fscanfMmcEqLinkStructNote7M(IOUNIT3,
               "%lg%lg%lg%i%lg"
               ,5,((&FundSpot(itvar1)),(&FundRef0(itvar1)),(&sigma(itvar1)),(&Currency(itvar1)),(&MgtFee(itvar1))));
        }
        fclose(IOUNIT3);
        }
    /* Read PortfolioWeight from file */
    SciArray2<double>PortfolioWeight(nFund + 1, nPortfolio + 1);
    if ((nFund>=1&&nPortfolio>=1))
        {
        openfilemcEqLinkStructNote7MR(IOUNIT4,"PortfolioWeight.dat");
        for (itvar1=1; itvar1<=nFund; itvar1++) {
            for (itvar2=1; itvar2<=nPortfolio; itvar2++) {
                fscanfMmcEqLinkStructNote7M(IOUNIT4,"%lg",1,((&PortfolioWeight(itvar1,itvar2))));
            }
        }
        fclose(IOUNIT4);
        }
    /* Read rho from file */
    SciArray2<double>rho(nFund + 1, nFund + 1);
    if (nFund>=1)
        {
        openfilemcEqLinkStructNote7MR(IOUNIT5,"rho.dat");
        for (itvar1=1; itvar1<=nFund; itvar1++) {
            for (itvar2=1; itvar2<=nFund; itvar2++) {
                fscanfMmcEqLinkStructNote7M(IOUNIT5,"%lg",1,((&rho(itvar1,itvar2))));
            }
        }
        fclose(IOUNIT5);
        }
    SciArray1<double>ZeroDates1(nZero1 + 1);
    SciArray1<double>ZeroRates1(nZero1 + 1);
    /* Read ZeroDates1 from file. Read ZeroRates1 from file */
    if (nZero1>=0)
        {
        openfilemcEqLinkStructNote7MR(IOUNIT6,"ZeroCurve1.dat");
        for (itvar1=0; itvar1<=nZero1; itvar1++) {
            fscanfMmcEqLinkStructNote7M(IOUNIT6,"%lg%lg",2,((&ZeroDates1(itvar1)),(&ZeroRates1(itvar1))));
        }
        fclose(IOUNIT6);
        }
    SciArray1<double>ZeroDates2(nZero2 + 1);
    SciArray1<double>ZeroRates2(nZero2 + 1);
    /* Read ZeroDates2 from file. Read ZeroRates2 from file */
    if (nZero2>=0)
        {
        openfilemcEqLinkStructNote7MR(IOUNIT7,"ZeroCurve2.dat");
        for (itvar1=0; itvar1<=nZero2; itvar1++) {
            fscanfMmcEqLinkStructNote7M(IOUNIT7,"%lg%lg",2,((&ZeroDates2(itvar1)),(&ZeroRates2(itvar1))));
        }
        fclose(IOUNIT7);
        }
    SciArray1<double>ZeroDates3(nZero3 + 1);
    SciArray1<double>ZeroRates3(nZero3 + 1);
    /* Read ZeroDates3 from file. Read ZeroRates3 from file */
    if (nZero3>=0)
        {
        openfilemcEqLinkStructNote7MR(IOUNIT8,"ZeroCurve3.dat");
        for (itvar1=0; itvar1<=nZero3; itvar1++) {
            fscanfMmcEqLinkStructNote7M(IOUNIT8,"%lg%lg",2,((&ZeroDates3(itvar1)),(&ZeroRates3(itvar1))));
        }
        fclose(IOUNIT8);
        }
    SciArray1<double>ZeroDates4(nZero4 + 1);
    SciArray1<double>ZeroRates4(nZero4 + 1);
    /* Read ZeroDates4 from file. Read ZeroRates4 from file */
    if (nZero4>=0)
        {
        openfilemcEqLinkStructNote7MR(IOUNIT9,"ZeroCurve4.dat");
        for (itvar1=0; itvar1<=nZero4; itvar1++) {
            fscanfMmcEqLinkStructNote7M(IOUNIT9,"%lg%lg",2,((&ZeroDates4(itvar1)),(&ZeroRates4(itvar1))));
        }
        fclose(IOUNIT9);
        }
    /*                            */
    /* Call the computation function. */
    mcEqLinkStructNote7fn(cumulative,Currency,DomCurrency,EvalDate,FundRef0,FundSpot,LockedRtnHist,MaturityDate,MgtFee,
       nEval,nFund,nMax,Notional,nPortfolio,nZero1,nZero2,nZero3,nZero4,pMax,PortfolioWeight,PR,rho,Series,sigma,Strike,
       ZeroDates1,ZeroDates2,ZeroDates3,ZeroDates4,ZeroRates1,ZeroRates2,ZeroRates3,ZeroRates4,Vx);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfilemcEqLinkStructNote7MW(IOUNIT,"V.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




