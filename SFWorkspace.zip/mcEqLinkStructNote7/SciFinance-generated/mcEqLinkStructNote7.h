#ifndef MCEQLINKSTRUCTNOTE7_H
#define MCEQLINKSTRUCTNOTE7_H

#include "SciArrayN.h" /* SciComp arrays */

void mcEqLinkStructNote7fn(
    int cumulative,
    SciArray1<int>& Currency,
    int DomCurrency,
    const SciArray1<double>& EvalDate,
    const SciArray1<double>& FundRef0,
    const SciArray1<double>& FundSpot,
    const SciArray1<double>& LockedRtnHist,
    double MaturityDate,
    const SciArray1<double>& MgtFee,
    int nEval,
    int nFund,
    int nMax,
    double Notional,
    int nPortfolio,
    int nZero1,
    int nZero2,
    int nZero3,
    int nZero4,
    int pMax,
    const SciArray2<double>& PortfolioWeight,
    double PR,
    const SciArray2<double>& rho,
    int Series,
    const SciArray1<double>& sigma,
    double Strike,
    const SciArray1<double>& ZeroDates1,
    const SciArray1<double>& ZeroDates2,
    const SciArray1<double>& ZeroDates3,
    const SciArray1<double>& ZeroDates4,
    const SciArray1<double>& ZeroRates1,
    const SciArray1<double>& ZeroRates2,
    const SciArray1<double>& ZeroRates3,
    const SciArray1<double>& ZeroRates4,
    double & Vx
    );
     


#endif /* MCEQLINKSTRUCTNOTE7_H */
