/*** Key to program variables: ***
  accuracy: solution variable; an input
  callTrigger: solution variable; an input
  CR: solution variable; an input
  D0: solution variable; an input
  iMax: number of grid cells for x; an input
  nacc: solution variable; an input
  nMax: number of grid cells for tau; an input
  nput: array maximum for tPut; an input
  parValue: solution variable; an input
  racc: solution variable; an input
  rfree: solution variable; an input
  rspread: solution variable; an input
  sigma: solution variable; an input
  Spot: solution variable; an input
  tCall1: solution variable; an input
  tCall2: solution variable; an input
  TMax: minimum physical value in dimension tau; an input
  tolSOR: solution variable; an input
  tPut: Sample array for Exercise; an input
  xMax: maximum physical value in dimension x; an input
  xMin: minimum physical value in dimension x; an input
  Deltax: solution variable; an output
  Delta2x: output variable for der[V, {x, 1}]/J; an output
  Gammax: solution variable; an output
  Gamma1x: output variable for der[der[V, {x, 1}]/J, {x, 1}]/J; an output
  Sx: solution variable; an output
  Vx: solution variable; an output
  V1x: solution variable; an output
*** end Key to program variables: ***/


/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for tPut in file "tPut.dat" has maximum index
      nput, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nput elements,
      to be stored in tPut(1..nput).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "ZCCBond1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfileZCCBond1MW
#define openfileZCCBond1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfileZCCBond1MR
#define openfileZCCBond1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMZCCBond1M
#define fscanfMZCCBond1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1


int main()
{
    int i5,iMax,itvar1,nacc,nMax,nput;
    double accuracy,callTrigger,CR,D0,Deltax,Gammax,parValue,racc,rfree,rspread,sigma,Spot,tCall1,tCall2,TMax,tolSOR,V1x
       ,xMax,xMin;
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4;
    ArgumentRecord pcinitInputTable[20];
    
    /* *** Key to program variables: *** */
    /* accuracy, callTrigger, CR, D0, Deltax, Gammax, nacc, parValue, racc, rfree, rspread, sigma, Spot, tCall1, tCall2,
       tolSOR, V, V1x: solution variable */
    /* Delta2: output variable for der[V, {x, 1}]/J */
    /* Gamma1: output variable for der[der[V, {x, 1}]/J, {x, 1}]/J */
    /* i5: index variable for x */
    /* iMax: number of grid cells for x */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4: I/O channel */
    /* nMax: number of grid cells for tau */
    /* nput: array maximum for tPut */
    /* TMax: minimum physical value in dimension tau */
    /* tPut: Sample array for Exercise */
    /* xMax: maximum physical value in dimension x */
    /* xMin: minimum physical value in dimension x */
    try {
    /* Read Tagged Input File */
    openfileZCCBond1MR(IOUNIT3,"pcinit.dat");
    setupargs(pcinitInputTable, 0, "accuracy", accuracy, READINPUTSDOUBLE);
    setupargs(pcinitInputTable, 1, "callTrigger", callTrigger, READINPUTSDOUBLE);
    setupargs(pcinitInputTable, 2, "CR", CR, READINPUTSDOUBLE);
    setupargs(pcinitInputTable, 3, "D0", D0, READINPUTSDOUBLE);
    setupargs(pcinitInputTable, 4, "iMax", iMax, READINPUTSINTEGER);
    setupargs(pcinitInputTable, 5, "nacc", nacc, READINPUTSINTEGER);
    setupargs(pcinitInputTable, 6, "nMax", nMax, READINPUTSINTEGER);
    setupargs(pcinitInputTable, 7, "nput", nput, READINPUTSINTEGER);
    setupargs(pcinitInputTable, 8, "parValue", parValue, READINPUTSDOUBLE);
    setupargs(pcinitInputTable, 9, "racc", racc, READINPUTSDOUBLE);
    setupargs(pcinitInputTable, 10, "rfree", rfree, READINPUTSDOUBLE);
    setupargs(pcinitInputTable, 11, "rspread", rspread, READINPUTSDOUBLE);
    setupargs(pcinitInputTable, 12, "sigma", sigma, READINPUTSDOUBLE);
    setupargs(pcinitInputTable, 13, "Spot", Spot, READINPUTSDOUBLE);
    setupargs(pcinitInputTable, 14, "tCall1", tCall1, READINPUTSDOUBLE);
    setupargs(pcinitInputTable, 15, "tCall2", tCall2, READINPUTSDOUBLE);
    setupargs(pcinitInputTable, 16, "TMax", TMax, READINPUTSDOUBLE);
    setupargs(pcinitInputTable, 17, "tolSOR", tolSOR, READINPUTSDOUBLE);
    setupargs(pcinitInputTable, 18, "xMax", xMax, READINPUTSDOUBLE);
    setupargs(pcinitInputTable, 19, "xMin", xMin, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT3,pcinitInputTable,20)!=0)
        {
        fclose(IOUNIT3);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT3);
    /* Read tPut from file */
    SciArray1<double>tPut(nput + 1);
    if (nput>=1)
        {
        openfileZCCBond1MR(IOUNIT4,"tPut.dat");
        for (itvar1=1; itvar1<=nput; itvar1++) {
            fscanfMZCCBond1M(IOUNIT4,"%lg",1,((&tPut(itvar1))));
        }
        fclose(IOUNIT4);
        }
    /*                            */
    /* Call the computation function. */
    SciArray1<double> Delta2;
    SciArray1<double> Gamma1;
    SciArray1<double> S;
    SciArray1<double> V;
    ZCCBond1fn(accuracy,callTrigger,CR,D0,iMax,nacc,nMax,nput,parValue,racc,rfree,rspread,sigma,Spot,tCall1,tCall2,TMax,
       tolSOR,tPut,xMax,xMin,Deltax,Delta2,Gammax,Gamma1,S,V,V1x);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfileZCCBond1MW(IOUNIT,"V.out");
    fprintf(IOUNIT, " %g %18.8e %18.8e\n", 0.,Spot,V1x);
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file Delta.out from ResultEq1c. */
    openfileZCCBond1MW(IOUNIT1,"Delta.out");
    fprintf(IOUNIT1, " %g %18.8e %18.8e\n", 0.,Spot,Deltax);
    fprintf(IOUNIT1, "\n");
    /* Writing collected output to file Gamma.out from ResultEq2c. */
    openfileZCCBond1MW(IOUNIT2,"Gamma.out");
    fprintf(IOUNIT2, " %g %18.8e %18.8e\n", 0.,Spot,Gammax);
    fprintf(IOUNIT2, "\n");
    /* Writing collected output to file V.out from ResultEq3c. */
    for (i5=0; i5<=(int)V.size0() - 1; i5++) {
        fprintf(IOUNIT, " %g %18.8e %18.8e\n", 0.,S(i5),V(i5));
    }
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* Writing collected output to file Delta.out from ResultEq4c. */
    for (i5=0; i5<=(int)Delta2.size0() - 1; i5++) {
        fprintf(IOUNIT1, " %g %18.8e %18.8e\n", 0.,S(i5),Delta2(i5));
    }
    fprintf(IOUNIT1, "\n");
    fclose(IOUNIT1);
    /* Writing collected output to file Gamma.out from ResultEq5c. */
    for (i5=0; i5<=(int)Gamma1.size0() - 1; i5++) {
        fprintf(IOUNIT2, " %g %18.8e %18.8e\n", 0.,S(i5),Gamma1(i5));
    }
    fprintf(IOUNIT2, "\n");
    fclose(IOUNIT2);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




