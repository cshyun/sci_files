#ifndef ZCCBOND1_H
#define ZCCBOND1_H

#include "SciArrayN.h" /* SciComp arrays */

void ZCCBond1fn(
    double accuracy,
    double callTrigger,
    double CR,
    double D0,
    int iMax,
    int nacc,
    int nMax,
    int nput,
    double parValue,
    double racc,
    double rfree,
    double rspread,
    double sigma,
    double Spot,
    double tCall1,
    double tCall2,
    double TMax,
    double tolSOR,
    const SciArray1<double>& tPut,
    double xMax,
    double xMin,
    double & Deltax,
    SciArray1<double>& Delta2x,
    double & Gammax,
    SciArray1<double>& Gamma1x,
    SciArray1<double>& Sx,
    SciArray1<double>& Vx,
    double & V1x
    );
     


#endif /* ZCCBOND1_H */
