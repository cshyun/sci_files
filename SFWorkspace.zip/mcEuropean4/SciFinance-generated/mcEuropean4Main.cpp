



#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcEuropean4.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcEuropean4MW
#define openfilemcEuropean4MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcEuropean4MR
#define openfilemcEuropean4MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcEuropean4M
#define fscanfMmcEuropean4M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }



int main()
{
    int pMax,Series;
    double Deltax,epsilon,Gammax,K,q,r,RhoQx,Rhox,sigma,Spot,Thetax,TMax,Vannax,Vegax,Volgax,Vx;
    ArgumentRecord initInputTable[10];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4,*IOUNIT5,*IOUNIT6,*IOUNIT7,*IOUNIT8,*IOUNIT9;
    int put;
    
    /* *** Key to program variables: *** */
    /* Deltax, epsilon, Gammax, K, put, q, RhoQx, Rhox, Series, sigma, Spot, Thetax, Vannax, Vegax, Volgax: solution    
       variable */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5, IOUNIT6, IOUNIT7, IOUNIT8, IOUNIT9: I/O channel */
    /* pMax: maximum for path */
    /* r: discount rate */
    /* TMax: maximum time */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcEuropean4MR(IOUNIT9,"init.dat");
    setupargs(initInputTable, 0, "epsilon", epsilon, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "K", K, READINPUTSDOUBLE);
    setupargs(initInputTable, 2, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 3, "put", put, READINPUTSBOOLEAN);
    setupargs(initInputTable, 4, "q", q, READINPUTSDOUBLE);
    setupargs(initInputTable, 5, "r", r, READINPUTSDOUBLE);
    setupargs(initInputTable, 6, "Series", Series, READINPUTSINTEGER);
    setupargs(initInputTable, 7, "sigma", sigma, READINPUTSDOUBLE);
    setupargs(initInputTable, 8, "Spot", Spot, READINPUTSDOUBLE);
    setupargs(initInputTable, 9, "TMax", TMax, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT9,initInputTable,10)!=0)
        {
        fclose(IOUNIT9);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT9);
    /*                            */
    /* Call the computation function. */
    mcEuropean4fn(epsilon,K,pMax,put,q,r,Series,sigma,Spot,TMax,Deltax,Gammax,Rhox,RhoQx,Thetax,Vx,Vannax,Vegax,Volgax);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfilemcEuropean4MW(IOUNIT,"V.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* Writing collected output to file Delta.out from ResultEq1c. */
    openfilemcEuropean4MW(IOUNIT1,"Delta.out");
    fprintf(IOUNIT1, " %18.8e\n", Deltax);
    fprintf(IOUNIT1, "\n");
    fclose(IOUNIT1);
    /* Writing collected output to file Gamma.out from ResultEq2c. */
    openfilemcEuropean4MW(IOUNIT2,"Gamma.out");
    fprintf(IOUNIT2, " %18.8e\n", Gammax);
    fprintf(IOUNIT2, "\n");
    fclose(IOUNIT2);
    /* Writing collected output to file Theta.out from ResultEq3c. */
    openfilemcEuropean4MW(IOUNIT3,"Theta.out");
    fprintf(IOUNIT3, " %18.8e\n", Thetax);
    fprintf(IOUNIT3, "\n");
    fclose(IOUNIT3);
    /* Writing collected output to file Vega.out from ResultEq4c. */
    openfilemcEuropean4MW(IOUNIT4,"Vega.out");
    fprintf(IOUNIT4, " %18.8e\n", Vegax);
    fprintf(IOUNIT4, "\n");
    fclose(IOUNIT4);
    /* Writing collected output to file Rho.out from ResultEq5c. */
    openfilemcEuropean4MW(IOUNIT5,"Rho.out");
    fprintf(IOUNIT5, " %18.8e\n", Rhox);
    fprintf(IOUNIT5, "\n");
    fclose(IOUNIT5);
    /* Writing collected output to file RhoQ.out from ResultEq6c. */
    openfilemcEuropean4MW(IOUNIT6,"RhoQ.out");
    fprintf(IOUNIT6, " %18.8e\n", RhoQx);
    fprintf(IOUNIT6, "\n");
    fclose(IOUNIT6);
    /* Writing collected output to file Volga.out from ResultEq7c. */
    openfilemcEuropean4MW(IOUNIT7,"Volga.out");
    fprintf(IOUNIT7, " %18.8e\n", Volgax);
    fprintf(IOUNIT7, "\n");
    fclose(IOUNIT7);
    /* Writing collected output to file Vanna.out from ResultEq8c. */
    openfilemcEuropean4MW(IOUNIT8,"Vanna.out");
    fprintf(IOUNIT8, " %18.8e\n", Vannax);
    fprintf(IOUNIT8, "\n");
    fclose(IOUNIT8);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




