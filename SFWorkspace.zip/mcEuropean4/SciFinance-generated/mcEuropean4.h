#ifndef MCEUROPEAN4_H
#define MCEUROPEAN4_H

#include "SciArrayN.h" /* SciComp arrays */

void mcEuropean4fn(
    double epsilon,
    double K,
    int pMax,
    int put,
    double q,
    double r,
    int Series,
    double sigma,
    double Spot,
    double TMax,
    double & Deltax,
    double & Gammax,
    double & Rhox,
    double & RhoQx,
    double & Thetax,
    double & Vx,
    double & Vannax,
    double & Vegax,
    double & Volgax
    );
     


#endif /* MCEUROPEAN4_H */
