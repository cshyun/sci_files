#ifndef MCG2CANCELCMSSPREADRASWAP1_H
#define MCG2CANCELCMSSPREADRASWAP1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcG2CancelCMSSpreadRASwap1fn(
    const SciArray1<double>& AccrualCms,
    const SciArray1<double>& AccrualFlt,
    double CallPrice,
    double CmsBarrier,
    double CmsInitCoupon,
    double CommenceDate,
    const SciArray1<double>& ExerciseDates,
    double GearFlt,
    double kappa1,
    double kappa2,
    int maxord1,
    int maxord2,
    int maxord3,
    int nCMS1,
    int nCMS2,
    int nCpn,
    int nExer,
    int nMax,
    int nMon,
    double Notional,
    int nRst,
    int nZero,
    double PastLibor,
    const SciArray1<double>& PaymentDates,
    int pMax,
    const SciArray1<double>& RanMonitorDates,
    const SciArray1<double>& RanResetDates,
    double rho12,
    int Series,
    double sigma1,
    double sigma2,
    double SpreadFlt,
    double tauCMS,
    double tauLibor,
    const SciArray1<double>& zDates,
    const SciArray1<double>& zRates,
    double & Vx
    );
     


#endif /* MCG2CANCELCMSSPREADRASWAP1_H */
