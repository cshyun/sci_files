#ifndef MCBARHIMALAYA1_H
#define MCBARHIMALAYA1_H

#include "SciArrayN.h" /* SciComp arrays */

void MCBarHimalaya1fn(
    const SciArray1<double>& D0,
    double disc,
    double H,
    const SciArray1<double>& K,
    const SciArray1<double>& loan,
    int nbar,
    int nD,
    int nreset,
    int pMax,
    const SciArray1<double>& ResetTimes,
    const SciArray2<double>& rho,
    int Seed,
    const SciArray1<double>& sigma,
    const SciArray1<double>& Spot,
    double TMax,
    double X,
    double Y,
    double & devx,
    double & Vx
    );
     


#endif /* MCBARHIMALAYA1_H */
