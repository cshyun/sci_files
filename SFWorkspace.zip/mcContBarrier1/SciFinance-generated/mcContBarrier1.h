#ifndef MCCONTBARRIER1_H
#define MCCONTBARRIER1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcContBarrier1fn(
    double B,
    double K,
    int nsamp,
    int pMax,
    int put,
    double q,
    double r,
    double Rebate,
    int Seed,
    double sigma,
    double Spot,
    double TMax,
    const SciArray1<double>& tsamp,
    int up,
    double & devx,
    double & Vx
    );
     


#endif /* MCCONTBARRIER1_H */
