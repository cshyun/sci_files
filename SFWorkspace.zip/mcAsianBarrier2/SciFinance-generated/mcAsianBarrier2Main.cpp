

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for SampleDates in file "SampleDates.dat" has maximum index
      nsampToGo, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nsampToGo elements,
      to be stored in SampleDates(1..nsampToGo).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcAsianBarrier2.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcAsianBarrier2MW
#define openfilemcAsianBarrier2MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcAsianBarrier2MR
#define openfilemcAsianBarrier2MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcAsianBarrier2M
#define fscanfMmcAsianBarrier2M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1


int main()
{
    int ABarType,itvar1,nsampSoFar,nsampToGo,nSBar,pMax,SBarType,Series;
    double ABarEnd,ABarStart,ADnBar,ADnRebate,ASpot,AUpBar,AUpRebate,K,q,r,SBarEnd,SBarStart,SDnBar,SDnRebate,sigma,Spot
       ,SUpBar,SUpRebate,TMax,Vx;
    ArgumentRecord initInputTable[27];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2;
    int put;
    
    /* *** Key to program variables: *** */
    /* ABarEnd, ABarStart, ABarType, ADnBar, ADnRebate, ASpot, AUpBar, AUpRebate, K, nsampSoFar, nSBar, put, q,         
       SampleDates, SBarEnd, SBarStart, SBarType, SDnBar, SDnRebate, Series, sigma, Spot, SUpBar, SUpRebate: solution   
       variable */
    /* IOUNIT, IOUNIT1, IOUNIT2: I/O channel */
    /* nsampToGo: array maximum for SampleDates */
    /* pMax: maximum for path */
    /* r: discount rate */
    /* TMax: maximum time */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcAsianBarrier2MR(IOUNIT1,"init.dat");
    setupargs(initInputTable, 0, "ABarEnd", ABarEnd, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "ABarStart", ABarStart, READINPUTSDOUBLE);
    setupargs(initInputTable, 2, "ABarType", ABarType, READINPUTSINTEGER);
    setupargs(initInputTable, 3, "ADnBar", ADnBar, READINPUTSDOUBLE);
    setupargs(initInputTable, 4, "ADnRebate", ADnRebate, READINPUTSDOUBLE);
    setupargs(initInputTable, 5, "ASpot", ASpot, READINPUTSDOUBLE);
    setupargs(initInputTable, 6, "AUpBar", AUpBar, READINPUTSDOUBLE);
    setupargs(initInputTable, 7, "AUpRebate", AUpRebate, READINPUTSDOUBLE);
    setupargs(initInputTable, 8, "K", K, READINPUTSDOUBLE);
    setupargs(initInputTable, 9, "nsampSoFar", nsampSoFar, READINPUTSINTEGER);
    setupargs(initInputTable, 10, "nsampToGo", nsampToGo, READINPUTSINTEGER);
    setupargs(initInputTable, 11, "nSBar", nSBar, READINPUTSINTEGER);
    setupargs(initInputTable, 12, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 13, "put", put, READINPUTSBOOLEAN);
    setupargs(initInputTable, 14, "q", q, READINPUTSDOUBLE);
    setupargs(initInputTable, 15, "r", r, READINPUTSDOUBLE);
    setupargs(initInputTable, 16, "SBarEnd", SBarEnd, READINPUTSDOUBLE);
    setupargs(initInputTable, 17, "SBarStart", SBarStart, READINPUTSDOUBLE);
    setupargs(initInputTable, 18, "SBarType", SBarType, READINPUTSINTEGER);
    setupargs(initInputTable, 19, "SDnBar", SDnBar, READINPUTSDOUBLE);
    setupargs(initInputTable, 20, "SDnRebate", SDnRebate, READINPUTSDOUBLE);
    setupargs(initInputTable, 21, "Series", Series, READINPUTSINTEGER);
    setupargs(initInputTable, 22, "sigma", sigma, READINPUTSDOUBLE);
    setupargs(initInputTable, 23, "Spot", Spot, READINPUTSDOUBLE);
    setupargs(initInputTable, 24, "SUpBar", SUpBar, READINPUTSDOUBLE);
    setupargs(initInputTable, 25, "SUpRebate", SUpRebate, READINPUTSDOUBLE);
    setupargs(initInputTable, 26, "TMax", TMax, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,initInputTable,27)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    /* Read SampleDates from file */
    SciArray1<double>SampleDates(nsampToGo + 1);
    if (nsampToGo>=1)
        {
        openfilemcAsianBarrier2MR(IOUNIT2,"SampleDates.dat");
        for (itvar1=1; itvar1<=nsampToGo; itvar1++) {
            fscanfMmcAsianBarrier2M(IOUNIT2,"%lg",1,((&SampleDates(itvar1))));
        }
        fclose(IOUNIT2);
        }
    /*                            */
    /* Call the computation function. */
    mcAsianBarrier2fn(ABarEnd,ABarStart,ABarType,ADnBar,ADnRebate,ASpot,AUpBar,AUpRebate,K,nsampSoFar,nsampToGo,nSBar,
       pMax,put,q,r,SampleDates,SBarEnd,SBarStart,SBarType,SDnBar,SDnRebate,Series,sigma,Spot,SUpBar,SUpRebate,TMax,Vx);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfilemcAsianBarrier2MW(IOUNIT,"V.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




