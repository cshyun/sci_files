#ifndef MCASIANBARRIER2_H
#define MCASIANBARRIER2_H

#include "SciArrayN.h" /* SciComp arrays */

void mcAsianBarrier2fn(
    double ABarEnd,
    double ABarStart,
    int ABarType,
    double ADnBar,
    double ADnRebate,
    double ASpot,
    double AUpBar,
    double AUpRebate,
    double K,
    int nsampSoFar,
    int nsampToGo,
    int nSBar,
    int pMax,
    int put,
    double q,
    double r,
    const SciArray1<double>& SampleDates,
    double SBarEnd,
    double SBarStart,
    int SBarType,
    double SDnBar,
    double SDnRebate,
    int Series,
    double sigma,
    double Spot,
    double SUpBar,
    double SUpRebate,
    double TMax,
    double & Vx
    );
     


#endif /* MCASIANBARRIER2_H */
