#ifndef MCG2CALLFRN1_H
#define MCG2CALLFRN1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcG2CallFRN1fn(
    const SciArray1<double>& Accrual,
    double CallPrice,
    const SciArray1<double>& Cap,
    const SciArray1<double>& ExerciseDates,
    const SciArray1<double>& Flr,
    const SciArray1<double>& Gear,
    double kappa1,
    double kappa2,
    int maxord1,
    int maxord2,
    int maxord3,
    int nCpn,
    int nExer,
    int nMax,
    double Notional,
    int nRst,
    int nZero,
    double PastLibor,
    const SciArray1<double>& PaymentDates,
    int pMax,
    const SciArray1<double>& ResetDates,
    double rho12,
    int Series,
    double sigma1,
    double sigma2,
    const SciArray1<double>& Spread,
    double tau,
    const SciArray1<double>& zDates,
    const SciArray1<double>& zRates,
    double & Vx
    );
     


#endif /* MCG2CALLFRN1_H */
