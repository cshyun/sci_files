#ifndef MCATLAS1_H
#define MCATLAS1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcAtlas1fn(
    const SciArray1<double>& beta,
    const SciArray1<double>& D0,
    double disc,
    double K,
    const SciArray1<double>& loan,
    int nbest,
    int nD,
    int nMax,
    int nworst,
    int pMax,
    const SciArray2<double>& rho,
    const SciArray1<double>& S0,
    int Series,
    const SciArray1<double>& sigma,
    const SciArray1<double>& SNorm,
    const SciArray1<double>& Spot,
    double TMax,
    double & Vx
    );
     


#endif /* MCATLAS1_H */
