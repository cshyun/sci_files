

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for aFac in file "factor.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in aFac(1..nD).

   The table for AttachCDO in file "AttachCDO.dat" has maximum index
      nCDO, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nCDO elements,
      to be stored in AttachCDO(1..nCDO).

   The table for DetachCDO in file "DetachCDO.dat" has maximum index
      nCDO, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nCDO elements,
      to be stored in DetachCDO(1..nCDO).

   The table for h in file "spreads.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in h(1..nD).

   The table for hDswitch in file "hDswitch.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in hDswitch(1..nD).

   The table for Notional in file "notional.dat" has maximum indices
      nD and nCDO, 
     with minimum indices 1, 1 respectively.
      The index bounds are not read from this file.
        Following should be the nCDO*nD elements,
      to be stored in Notional(1..nD, 1..nCDO).
   The first index is the most slowly varying and 
      the last index is the most rapidly varying.

   The table for Recovery in file "spreads.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in Recovery(1..nD).

   The table for tC in file "PaymentDates.dat" has maximum index
      nC, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nC elements,
      to be stored in tC(1..nC).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcCDOSQ.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcCDOSQMW
#define openfilemcCDOSQMW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcCDOSQMR
#define openfilemcCDOSQMR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcCDOSQM
#define fscanfMmcCDOSQM(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2


int main()
{
    int i,itvar1,itvar2,leap,nC,nCDO,nD,pMax,sskip;
    double AttachCDOSQ,DetachCDOSQ,greekFD,PVCDOSQLOSSx,r;
    ArgumentRecord initInputTable[10];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4,*IOUNIT5,*IOUNIT6,*IOUNIT7,*IOUNIT8,*IOUNIT9;
    
    /* *** Key to program variables: *** */
    /* aFac, AttachCDO, AttachCDOSQ, DetachCDO, DetachCDOSQ, greekFD, h, hDswitch, leap, Notional, Recovery, sskip, tC: 
       solution variable */
    /* hDelta: greek for if[hDswitch, der[PVCDOSQLOSS, {h, 1}], seq[]] */
    /* i: vector index */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5, IOUNIT6, IOUNIT7, IOUNIT8, IOUNIT9: I/O channel */
    /* nC: array maximum for tC */
    /* nCDO: array maximum for DetachCDO, AttachCDO and Notional */
    /* nD: maximum for i */
    /* pMax: maximum for path */
    /* PVCDOSQLOSSx: discounted value */
    /* r: discount rate */
    try {
    /* Read Tagged Input File */
    openfilemcCDOSQMR(IOUNIT2,"init.dat");
    setupargs(initInputTable, 0, "AttachCDOSQ", AttachCDOSQ, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "DetachCDOSQ", DetachCDOSQ, READINPUTSDOUBLE);
    setupargs(initInputTable, 2, "greekFD", greekFD, READINPUTSDOUBLE);
    setupargs(initInputTable, 3, "leap", leap, READINPUTSINTEGER);
    setupargs(initInputTable, 4, "nC", nC, READINPUTSINTEGER);
    setupargs(initInputTable, 5, "nCDO", nCDO, READINPUTSINTEGER);
    setupargs(initInputTable, 6, "nD", nD, READINPUTSINTEGER);
    setupargs(initInputTable, 7, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 8, "r", r, READINPUTSDOUBLE);
    setupargs(initInputTable, 9, "sskip", sskip, READINPUTSINTEGER);
    if (ReadInputs(IOUNIT2,initInputTable,10)!=0)
        {
        fclose(IOUNIT2);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT2);
    SciArray1<double>AttachCDO(nCDO + 1);
    SciArray1<double>DetachCDO(nCDO + 1);
    if (nCDO>=1)
        {
        /* Read AttachCDO from file */
        openfilemcCDOSQMR(IOUNIT3,"AttachCDO.dat");
        for (itvar1=1; itvar1<=nCDO; itvar1++) {
            fscanfMmcCDOSQM(IOUNIT3,"%lg",1,((&AttachCDO(itvar1))));
        }
        fclose(IOUNIT3);
        /* Read DetachCDO from file */
        openfilemcCDOSQMR(IOUNIT4,"DetachCDO.dat");
        for (itvar1=1; itvar1<=nCDO; itvar1++) {
            fscanfMmcCDOSQM(IOUNIT4,"%lg",1,((&DetachCDO(itvar1))));
        }
        fclose(IOUNIT4);
        }
    SciArray1<double>aFac(nD + 1);
    SciArray1<int>hDswitch(nD + 1);
    if (nD>=1)
        {
        /* Read aFac from file */
        openfilemcCDOSQMR(IOUNIT5,"factor.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCDOSQM(IOUNIT5,"%lg",1,((&aFac(itvar1))));
        }
        fclose(IOUNIT5);
        /* Read hDswitch from file */
        openfilemcCDOSQMR(IOUNIT6,"hDswitch.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCDOSQM(IOUNIT6,"%i",1,((&hDswitch(itvar1))));
        }
        fclose(IOUNIT6);
        }
    /* Read Notional from file */
    SciArray2<double>Notional(nD + 1, nCDO + 1);
    if ((nCDO>=1&&nD>=1))
        {
        openfilemcCDOSQMR(IOUNIT7,"notional.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            for (itvar2=1; itvar2<=nCDO; itvar2++) {
                fscanfMmcCDOSQM(IOUNIT7,"%lg",1,((&Notional(itvar1,itvar2))));
            }
        }
        fclose(IOUNIT7);
        }
    /* Read tC from file */
    SciArray1<double>tC(nC + 1);
    if (nC>=1)
        {
        openfilemcCDOSQMR(IOUNIT8,"PaymentDates.dat");
        for (itvar1=1; itvar1<=nC; itvar1++) {
            fscanfMmcCDOSQM(IOUNIT8,"%lg",1,((&tC(itvar1))));
        }
        fclose(IOUNIT8);
        }
    SciArray1<double>h(nD + 1);
    SciArray1<double>Recovery(nD + 1);
    /* Read h from file. Read Recovery from file */
    if (nD>=1)
        {
        openfilemcCDOSQMR(IOUNIT9,"spreads.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCDOSQM(IOUNIT9,"%lg%lg",2,((&h(itvar1)),(&Recovery(itvar1))));
        }
        fclose(IOUNIT9);
        }
    /*                            */
    /* Call the computation function. */
    SciArray1<double> hDelta;
    mcCDOSQfn(aFac,AttachCDO,AttachCDOSQ,DetachCDO,DetachCDOSQ,greekFD,h,hDswitch,leap,nC,nCDO,nD,Notional,pMax,r,
       Recovery,sskip,tC,hDelta,PVCDOSQLOSSx);
    /*                            */
    /* Writing collected output to file CDOSQ.out from ResultEqc. */
    openfilemcCDOSQMW(IOUNIT,"CDOSQ.out");
    fprintf(IOUNIT, " %18.8e\n", PVCDOSQLOSSx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* Writing collected output to file hDelta.out from ResultEq1c. */
    openfilemcCDOSQMW(IOUNIT1,"hDelta.out");
    for (i=1; i<=(int)hDelta.size0() - 1; i++) {
        fprintf(IOUNIT1, " %18.8e\n", hDelta(i));
    }
    fprintf(IOUNIT1, "\n");
    fclose(IOUNIT1);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




