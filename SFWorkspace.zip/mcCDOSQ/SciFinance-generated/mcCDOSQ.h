#ifndef MCCDOSQ_H
#define MCCDOSQ_H

#include "SciArrayN.h" /* SciComp arrays */

void mcCDOSQfn(
    const SciArray1<double>& aFac,
    const SciArray1<double>& AttachCDO,
    double AttachCDOSQ,
    const SciArray1<double>& DetachCDO,
    double DetachCDOSQ,
    double greekFD,
    const SciArray1<double>& h,
    const SciArray1<int>& hDswitch,
    int leap,
    int nC,
    int nCDO,
    int nD,
    const SciArray2<double>& Notional,
    int pMax,
    double r,
    const SciArray1<double>& Recovery,
    int sskip,
    const SciArray1<double>& tC,
    SciArray1<double>& hDeltax,
    double & PVCDOSQLOSSx
    );
     


#endif /* MCCDOSQ_H */
