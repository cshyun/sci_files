#ifndef MCDARO1_H
#define MCDARO1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcDaro1fn(
    double D0,
    double disc,
    double lastA1,
    double lastA2,
    int leap,
    double loan,
    int nsampleSoFarA1,
    int nsampleSoFarA2,
    int nsampleToGoA1,
    int nsampleToGoA2,
    int pMax,
    int put,
    double sigma,
    double Spot,
    int sskip,
    double TMax,
    const SciArray1<double>& tsample1,
    const SciArray1<double>& tsample2,
    double & Vx
    );
     


#endif /* MCDARO1_H */
