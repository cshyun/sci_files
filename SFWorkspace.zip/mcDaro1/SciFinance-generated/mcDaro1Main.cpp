

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for tsample1 in file "A1samplingTime.dat" has maximum index
      nsampleToGoA1, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nsampleToGoA1 elements,
      to be stored in tsample1(1..nsampleToGoA1).

   The table for tsample2 in file "A2samplingTime.dat" has maximum index
      nsampleToGoA2, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nsampleToGoA2 elements,
      to be stored in tsample2(1..nsampleToGoA2).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcDaro1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcDaro1MW
#define openfilemcDaro1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcDaro1MR
#define openfilemcDaro1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcDaro1M
#define fscanfMmcDaro1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1


int main()
{
    int itvar1,leap,nsampleSoFarA1,nsampleSoFarA2,nsampleToGoA1,nsampleToGoA2,pMax,sskip;
    double D0,disc,lastA1,lastA2,loan,sigma,Spot,TMax,Vx;
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3;
    ArgumentRecord pcinitInputTable[16];
    int put;
    
    /* *** Key to program variables: *** */
    /* D0, lastA1, lastA2, leap, loan, nsampleSoFarA1, nsampleSoFarA2, put, sigma, Spot, sskip: solution variable */
    /* disc: discount rate */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3: I/O channel */
    /* nsampleToGoA1: array maximum for tsample1 */
    /* nsampleToGoA2: array maximum for tsample2 */
    /* pMax: maximum for path */
    /* TMax: maximum time */
    /* tsample1, tsample2: Sample array for Path */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcDaro1MR(IOUNIT1,"pcinit.dat");
    setupargs(pcinitInputTable, 0, "D0", D0, READINPUTSDOUBLE);
    setupargs(pcinitInputTable, 1, "disc", disc, READINPUTSDOUBLE);
    setupargs(pcinitInputTable, 2, "lastA1", lastA1, READINPUTSDOUBLE);
    setupargs(pcinitInputTable, 3, "lastA2", lastA2, READINPUTSDOUBLE);
    setupargs(pcinitInputTable, 4, "leap", leap, READINPUTSINTEGER);
    setupargs(pcinitInputTable, 5, "loan", loan, READINPUTSDOUBLE);
    setupargs(pcinitInputTable, 6, "nsampleSoFarA1", nsampleSoFarA1, READINPUTSINTEGER);
    setupargs(pcinitInputTable, 7, "nsampleSoFarA2", nsampleSoFarA2, READINPUTSINTEGER);
    setupargs(pcinitInputTable, 8, "nsampleToGoA1", nsampleToGoA1, READINPUTSINTEGER);
    setupargs(pcinitInputTable, 9, "nsampleToGoA2", nsampleToGoA2, READINPUTSINTEGER);
    setupargs(pcinitInputTable, 10, "pMax", pMax, READINPUTSINTEGER);
    setupargs(pcinitInputTable, 11, "put", put, READINPUTSBOOLEAN);
    setupargs(pcinitInputTable, 12, "sigma", sigma, READINPUTSDOUBLE);
    setupargs(pcinitInputTable, 13, "Spot", Spot, READINPUTSDOUBLE);
    setupargs(pcinitInputTable, 14, "sskip", sskip, READINPUTSINTEGER);
    setupargs(pcinitInputTable, 15, "TMax", TMax, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,pcinitInputTable,16)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    /* Read tsample1 from file */
    SciArray1<double>tsample1(nsampleToGoA1 + 1);
    if (nsampleToGoA1>=1)
        {
        openfilemcDaro1MR(IOUNIT2,"A1samplingTime.dat");
        for (itvar1=1; itvar1<=nsampleToGoA1; itvar1++) {
            fscanfMmcDaro1M(IOUNIT2,"%lg",1,((&tsample1(itvar1))));
        }
        fclose(IOUNIT2);
        }
    /* Read tsample2 from file */
    SciArray1<double>tsample2(nsampleToGoA2 + 1);
    if (nsampleToGoA2>=1)
        {
        openfilemcDaro1MR(IOUNIT3,"A2samplingTime.dat");
        for (itvar1=1; itvar1<=nsampleToGoA2; itvar1++) {
            fscanfMmcDaro1M(IOUNIT3,"%lg",1,((&tsample2(itvar1))));
        }
        fclose(IOUNIT3);
        }
    /*                            */
    /* Call the computation function. */
    mcDaro1fn(D0,disc,lastA1,lastA2,leap,loan,nsampleSoFarA1,nsampleSoFarA2,nsampleToGoA1,nsampleToGoA2,pMax,put,sigma,
       Spot,sskip,TMax,tsample1,tsample2,Vx);
    /*                            */
    /* Writing collected output to file value.out from ResultEqc. */
    openfilemcDaro1MW(IOUNIT,"value.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




