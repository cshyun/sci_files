#ifndef MCDIVIDENDS1_H
#define MCDIVIDENDS1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcDividends1fn(
    const SciArray1<double>& DivAmounts1,
    const SciArray1<double>& DivAmounts3,
    SciArray1<double>& DivAmounts4,
    const SciArray1<double>& DivDates1,
    const SciArray1<double>& DivDates2,
    const SciArray1<double>& DivDates3,
    const SciArray1<double>& DivDates4,
    const SciArray1<double>& DivRates2,
    SciArray1<double>& DivRates4,
    double K,
    int nDiv1,
    int nDiv2,
    int nDiv3,
    int nDiv4,
    int pMax,
    int put,
    double r,
    int Seed,
    double sigma,
    double Spot,
    double SwitchDate,
    double TMax,
    double & devx,
    double & Vx
    );
     


#endif /* MCDIVIDENDS1_H */
