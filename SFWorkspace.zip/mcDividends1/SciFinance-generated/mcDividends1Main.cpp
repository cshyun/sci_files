

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for DivAmounts1 in file "Dividends1.dat" has maximum index
      nDiv1, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nDiv1 elements,
      to be stored in DivAmounts1(1..nDiv1).

   The table for DivAmounts3 in file "Dividends3.dat" has maximum index
      nDiv3, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nDiv3 elements,
      to be stored in DivAmounts3(1..nDiv3).

   The table for DivAmounts4 in file "Dividends4.dat" has maximum index
      nDiv4, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nDiv4 elements,
      to be stored in DivAmounts4(1..nDiv4).

   The table for DivDates1 in file "Dividends1.dat" has maximum index
      nDiv1, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nDiv1 elements,
      to be stored in DivDates1(1..nDiv1).

   The table for DivDates2 in file "Dividends2.dat" has maximum index
      nDiv2, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nDiv2 elements,
      to be stored in DivDates2(1..nDiv2).

   The table for DivDates3 in file "Dividends3.dat" has maximum index
      nDiv3, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nDiv3 elements,
      to be stored in DivDates3(1..nDiv3).

   The table for DivDates4 in file "Dividends4.dat" has maximum index
      nDiv4, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nDiv4 elements,
      to be stored in DivDates4(1..nDiv4).

   The table for DivRates2 in file "Dividends2.dat" has maximum index
      nDiv2, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nDiv2 elements,
      to be stored in DivRates2(1..nDiv2).

   The table for DivRates4 in file "Dividends4.dat" has maximum index
      nDiv4, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nDiv4 elements,
      to be stored in DivRates4(1..nDiv4).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcDividends1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcDividends1MW
#define openfilemcDividends1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcDividends1MR
#define openfilemcDividends1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcDividends1M
#define fscanfMmcDividends1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2

#undef spreadargs3
#define spreadargs3(a1,a2,a3) a1,a2,a3


int main()
{
    int itvar1,nDiv1,nDiv2,nDiv3,nDiv4,pMax,Seed;
    double devx,K,r,sigma,Spot,SwitchDate,TMax,Vx;
    ArgumentRecord initInputTable[13];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4,*IOUNIT5;
    int put;
    
    /* *** Key to program variables: *** */
    /* devx: standard deviation error estimate */
    /* DivAmounts1, DivAmounts3, DivAmounts4, DivDates1, DivDates2, DivDates3, DivDates4, DivRates2, DivRates4, K, put, 
       Seed, sigma, Spot, SwitchDate: solution variable */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5: I/O channel */
    /* nDiv1: array maximum for DivDates1 and DivAmounts1 */
    /* nDiv2: array maximum for DivDates2 and DivRates2 */
    /* nDiv3: array maximum for DivDates3 and DivAmounts3 */
    /* nDiv4: array maximum for DivDates4, DivAmounts4 and DivRates4 */
    /* pMax: maximum for path */
    /* r: discount rate */
    /* TMax: maximum time */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcDividends1MR(IOUNIT1,"init.dat");
    setupargs(initInputTable, 0, "K", K, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "nDiv1", nDiv1, READINPUTSINTEGER);
    setupargs(initInputTable, 2, "nDiv2", nDiv2, READINPUTSINTEGER);
    setupargs(initInputTable, 3, "nDiv3", nDiv3, READINPUTSINTEGER);
    setupargs(initInputTable, 4, "nDiv4", nDiv4, READINPUTSINTEGER);
    setupargs(initInputTable, 5, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 6, "put", put, READINPUTSBOOLEAN);
    setupargs(initInputTable, 7, "r", r, READINPUTSDOUBLE);
    setupargs(initInputTable, 8, "Seed", Seed, READINPUTSINTEGER);
    setupargs(initInputTable, 9, "sigma", sigma, READINPUTSDOUBLE);
    setupargs(initInputTable, 10, "Spot", Spot, READINPUTSDOUBLE);
    setupargs(initInputTable, 11, "SwitchDate", SwitchDate, READINPUTSDOUBLE);
    setupargs(initInputTable, 12, "TMax", TMax, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,initInputTable,13)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    SciArray1<double>DivDates1(nDiv1 + 1);
    SciArray1<double>DivAmounts1(nDiv1 + 1);
    /* Read DivDates1 from file. Read DivAmounts1 from file */
    if (nDiv1>=1)
        {
        openfilemcDividends1MR(IOUNIT2,"Dividends1.dat");
        for (itvar1=1; itvar1<=nDiv1; itvar1++) {
            fscanfMmcDividends1M(IOUNIT2,"%lg%lg",2,((&DivDates1(itvar1)),(&DivAmounts1(itvar1))));
        }
        fclose(IOUNIT2);
        }
    SciArray1<double>DivDates2(nDiv2 + 1);
    SciArray1<double>DivRates2(nDiv2 + 1);
    /* Read DivDates2 from file. Read DivRates2 from file */
    if (nDiv2>=1)
        {
        openfilemcDividends1MR(IOUNIT3,"Dividends2.dat");
        for (itvar1=1; itvar1<=nDiv2; itvar1++) {
            fscanfMmcDividends1M(IOUNIT3,"%lg%lg",2,((&DivDates2(itvar1)),(&DivRates2(itvar1))));
        }
        fclose(IOUNIT3);
        }
    SciArray1<double>DivDates3(nDiv3 + 1);
    SciArray1<double>DivAmounts3(nDiv3 + 1);
    /* Read DivDates3 from file. Read DivAmounts3 from file */
    if (nDiv3>=1)
        {
        openfilemcDividends1MR(IOUNIT4,"Dividends3.dat");
        for (itvar1=1; itvar1<=nDiv3; itvar1++) {
            fscanfMmcDividends1M(IOUNIT4,"%lg%lg",2,((&DivDates3(itvar1)),(&DivAmounts3(itvar1))));
        }
        fclose(IOUNIT4);
        }
    SciArray1<double>DivDates4(nDiv4 + 1);
    SciArray1<double>DivAmounts4(nDiv4 + 1);
    SciArray1<double>DivRates4(nDiv4 + 1);
    /* Read DivDates4 from file. Read DivAmounts4 from file. Read DivRates4 from file */
    if (nDiv4>=1)
        {
        openfilemcDividends1MR(IOUNIT5,"Dividends4.dat");
        for (itvar1=1; itvar1<=nDiv4; itvar1++) {
            fscanfMmcDividends1M(IOUNIT5,
               "%lg%lg%lg",3,((&DivDates4(itvar1)),(&DivAmounts4(itvar1)),(&DivRates4(itvar1))));
        }
        fclose(IOUNIT5);
        }
    /*                            */
    /* Call the computation function. */
    mcDividends1fn(DivAmounts1,DivAmounts3,DivAmounts4,DivDates1,DivDates2,DivDates3,DivDates4,DivRates2,DivRates4,K,
       nDiv1,nDiv2,nDiv3,nDiv4,pMax,put,r,Seed,sigma,Spot,SwitchDate,TMax,devx,Vx);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfilemcDividends1MW(IOUNIT,"V.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file V.out from ResultEq1c. */
    fprintf(IOUNIT, " %18.8e\n", devx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




