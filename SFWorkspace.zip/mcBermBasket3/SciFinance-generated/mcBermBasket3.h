#ifndef MCBERMBASKET3_H
#define MCBERMBASKET3_H

#include "SciArrayN.h" /* SciComp arrays */

void mcBermBasket3fn(
    const SciArray1<double>& D0,
    double disc,
    double epsilon,
    double K,
    const SciArray1<double>& loan,
    int maxord,
    int nD,
    int nExer,
    int pMax,
    int pMaxI,
    int put,
    const SciArray2<double>& rho,
    int Series,
    const SciArray1<double>& sigma,
    const SciArray1<double>& Spot,
    double TMax,
    const SciArray1<double>& weight,
    SciArray1<double>& Deltax,
    SciArray1<double>& Gammax,
    double & Vx
    );
     


#endif /* MCBERMBASKET3_H */
