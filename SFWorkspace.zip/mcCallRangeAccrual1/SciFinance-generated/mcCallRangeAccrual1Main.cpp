

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for CallPrice in file "BulletCall.dat" has maximum index
      nCall, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nCall elements,
      to be stored in CallPrice(1..nCall).

   The table for tCall in file "BulletCall.dat" has maximum index
      nCall, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nCall elements,
      to be stored in tCall(1..nCall).

   The table for tRange in file "tRange.dat" has maximum index
      nRange, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nRange elements,
      to be stored in tRange(1..nRange).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcCallRangeAccrual1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcCallRangeAccrual1MW
#define openfilemcCallRangeAccrual1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcCallRangeAccrual1MR
#define openfilemcCallRangeAccrual1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcCallRangeAccrual1M
#define fscanfMmcCallRangeAccrual1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2


int main()
{
    int itvar1,maxord,nCall,nRange,pMax,pMaxI,Series;
    double A,Deltax,epsilon,Gammax,L,MSpot,q,r,sigma,Spot,SpotI,TMax,U,Vx;
    ArgumentRecord initInputTable[17];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3;
    
    /* *** Key to program variables: *** */
    /* A, CallPrice, Deltax, epsilon, Gammax, L, maxord, MSpot, q, Series, sigma, Spot, SpotI, tCall, tRange, U:        
       solution variable */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3: I/O channel */
    /* nCall: array maximum for tCall and CallPrice */
    /* nRange: array maximum for tRange */
    /* pMax: maximum for path */
    /* pMaxI: maximum for pathI */
    /* r: discount rate */
    /* TMax: maximum time */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcCallRangeAccrual1MR(IOUNIT1,"init.dat");
    setupargs(initInputTable, 0, "A", A, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "epsilon", epsilon, READINPUTSDOUBLE);
    setupargs(initInputTable, 2, "L", L, READINPUTSDOUBLE);
    setupargs(initInputTable, 3, "maxord", maxord, READINPUTSINTEGER);
    setupargs(initInputTable, 4, "MSpot", MSpot, READINPUTSDOUBLE);
    setupargs(initInputTable, 5, "nCall", nCall, READINPUTSINTEGER);
    setupargs(initInputTable, 6, "nRange", nRange, READINPUTSINTEGER);
    setupargs(initInputTable, 7, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 8, "pMaxI", pMaxI, READINPUTSINTEGER);
    setupargs(initInputTable, 9, "q", q, READINPUTSDOUBLE);
    setupargs(initInputTable, 10, "r", r, READINPUTSDOUBLE);
    setupargs(initInputTable, 11, "Series", Series, READINPUTSINTEGER);
    setupargs(initInputTable, 12, "sigma", sigma, READINPUTSDOUBLE);
    setupargs(initInputTable, 13, "Spot", Spot, READINPUTSDOUBLE);
    setupargs(initInputTable, 14, "SpotI", SpotI, READINPUTSDOUBLE);
    setupargs(initInputTable, 15, "TMax", TMax, READINPUTSDOUBLE);
    setupargs(initInputTable, 16, "U", U, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,initInputTable,17)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    SciArray1<double>tCall(nCall + 1);
    SciArray1<double>CallPrice(nCall + 1);
    /* Read tCall from file. Read CallPrice from file */
    if (nCall>=1)
        {
        openfilemcCallRangeAccrual1MR(IOUNIT2,"BulletCall.dat");
        for (itvar1=1; itvar1<=nCall; itvar1++) {
            fscanfMmcCallRangeAccrual1M(IOUNIT2,"%lg%lg",2,((&tCall(itvar1)),(&CallPrice(itvar1))));
        }
        fclose(IOUNIT2);
        }
    /* Read tRange from file */
    SciArray1<double>tRange(nRange + 1);
    if (nRange>=1)
        {
        openfilemcCallRangeAccrual1MR(IOUNIT3,"tRange.dat");
        for (itvar1=1; itvar1<=nRange; itvar1++) {
            fscanfMmcCallRangeAccrual1M(IOUNIT3,"%lg",1,((&tRange(itvar1))));
        }
        fclose(IOUNIT3);
        }
    /*                            */
    /* Call the computation function. */
    mcCallRangeAccrual1fn(A,CallPrice,Deltax,epsilon,Gammax,L,maxord,MSpot,nCall,nRange,pMax,pMaxI,q,r,Series,sigma,Spot
       ,SpotI,tCall,TMax,tRange,U,Vx);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfilemcCallRangeAccrual1MW(IOUNIT,"V.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file V.out from ResultEq1c. */
    fprintf(IOUNIT, " %18.8e\n", Deltax);
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file V.out from ResultEq2c. */
    fprintf(IOUNIT, " %18.8e\n", Gammax);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




