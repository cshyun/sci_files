#ifndef MCCALLRANGEACCRUAL1_H
#define MCCALLRANGEACCRUAL1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcCallRangeAccrual1fn(
    double A,
    const SciArray1<double>& CallPrice,
    double & Deltax,
    double epsilon,
    double & Gammax,
    double L,
    int maxord,
    double MSpot,
    int nCall,
    int nRange,
    int pMax,
    int pMaxI,
    double q,
    double r,
    int Series,
    double sigma,
    double Spot,
    double SpotI,
    const SciArray1<double>& tCall,
    double TMax,
    const SciArray1<double>& tRange,
    double U,
    double & Vx
    );
     


#endif /* MCCALLRANGEACCRUAL1_H */
