#ifndef MCDIGITAL2LFD_H
#define MCDIGITAL2LFD_H

#include "SciArrayN.h" /* SciComp arrays */

void mcDigital2LFDfn(
    double epsilon,
    double K,
    int pMax,
    double q,
    double r,
    int Seed,
    double sigma,
    double Spot,
    double TMax,
    double & Deltax,
    double & devx,
    double & EDeltax,
    double & EGammax,
    double & ERhox,
    double & ERhoQx,
    double & EThetax,
    double & EVannax,
    double & EVegax,
    double & EVolgax,
    double & Gammax,
    double & Rhox,
    double & RhoQx,
    double & Thetax,
    double & Vx,
    double & Vannax,
    double & Vegax,
    double & Volgax
    );
     


#endif /* MCDIGITAL2LFD_H */
