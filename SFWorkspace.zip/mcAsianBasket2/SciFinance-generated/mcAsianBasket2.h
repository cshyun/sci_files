#ifndef MCASIANBASKET2_H
#define MCASIANBASKET2_H

#include "SciArrayN.h" /* SciComp arrays */

void mcAsianBasket2fn(
    const SciArray1<double>& D0,
    double disc,
    double K,
    double lastA,
    const SciArray1<double>& loan,
    int nD,
    int nsampToGo,
    int pMax,
    const SciArray2<double>& rho,
    int Series,
    const SciArray1<double>& sigma,
    const SciArray1<double>& Spot,
    double TMax,
    const SciArray1<double>& tsamp,
    const SciArray2<double>& weight,
    double & Vx
    );
     


#endif /* MCASIANBASKET2_H */
