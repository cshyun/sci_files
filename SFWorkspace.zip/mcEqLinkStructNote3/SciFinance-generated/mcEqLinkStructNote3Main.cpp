

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for CallBarrier in file "Barriers.dat" has maximum index
      nObs, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nObs elements,
      to be stored in CallBarrier(1..nObs).

   The table for ObsDates in file "Barriers.dat" has maximum index
      nObs, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nObs elements,
      to be stored in ObsDates(1..nObs).

   The table for q in file "Basket.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in q(1..nD).

   The table for rho in file "rho.dat" has maximum indices
      nD and nD, 
     with minimum indices 1, 1 respectively.
      The index bounds are not read from this file.
        Following should be the nD^2 elements,
      to be stored in rho(1..nD, 1..nD).
   The first index is the most slowly varying and 
      the last index is the most rapidly varying.

   The table for sigma in file "Basket.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in sigma(1..nD).

   The table for Spot in file "Basket.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in Spot(1..nD).

   The table for SRef in file "Basket.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in SRef(1..nD).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcEqLinkStructNote3.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcEqLinkStructNote3MW
#define openfilemcEqLinkStructNote3MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcEqLinkStructNote3MR
#define openfilemcEqLinkStructNote3MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcEqLinkStructNote3M
#define fscanfMmcEqLinkStructNote3M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2

#undef spreadargs4
#define spreadargs4(a1,a2,a3,a4) a1,a2,a3,a4


int main()
{
    int itvar1,itvar2,nD,nObs,nSub,pMax,Series;
    double BonusCoupon,cascade,KnockInLevel,MatCoupon,Notional,r,TMax,Vx;
    ArgumentRecord initInputTable[12];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4;
    
    /* *** Key to program variables: *** */
    /* BonusCoupon, CallBarrier, cascade, KnockInLevel, MatCoupon, Notional, nSub, ObsDates, q, rho, Series, sigma,     
       Spot, SRef: solution variable */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4: I/O channel */
    /* nD: array maximum for rho, Spot, SRef, q and sigma */
    /* nObs: array maximum for ObsDates and CallBarrier */
    /* pMax: maximum for path */
    /* r: discount rate */
    /* TMax: maximum time */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcEqLinkStructNote3MR(IOUNIT1,"init.dat");
    setupargs(initInputTable, 0, "BonusCoupon", BonusCoupon, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "cascade", cascade, READINPUTSDOUBLE);
    setupargs(initInputTable, 2, "KnockInLevel", KnockInLevel, READINPUTSDOUBLE);
    setupargs(initInputTable, 3, "MatCoupon", MatCoupon, READINPUTSDOUBLE);
    setupargs(initInputTable, 4, "nD", nD, READINPUTSINTEGER);
    setupargs(initInputTable, 5, "nObs", nObs, READINPUTSINTEGER);
    setupargs(initInputTable, 6, "Notional", Notional, READINPUTSDOUBLE);
    setupargs(initInputTable, 7, "nSub", nSub, READINPUTSINTEGER);
    setupargs(initInputTable, 8, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 9, "r", r, READINPUTSDOUBLE);
    setupargs(initInputTable, 10, "Series", Series, READINPUTSINTEGER);
    setupargs(initInputTable, 11, "TMax", TMax, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,initInputTable,12)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    SciArray1<double>ObsDates(nObs + 1);
    SciArray1<double>CallBarrier(nObs + 1);
    /* Read ObsDates from file. Read CallBarrier from file */
    if (nObs>=1)
        {
        openfilemcEqLinkStructNote3MR(IOUNIT2,"Barriers.dat");
        for (itvar1=1; itvar1<=nObs; itvar1++) {
            fscanfMmcEqLinkStructNote3M(IOUNIT2,"%lg%lg",2,((&ObsDates(itvar1)),(&CallBarrier(itvar1))));
        }
        fclose(IOUNIT2);
        }
    SciArray1<double>Spot(nD + 1);
    SciArray1<double>SRef(nD + 1);
    SciArray1<double>q(nD + 1);
    SciArray1<double>sigma(nD + 1);
    SciArray2<double>rho(nD + 1, nD + 1);
    if (nD>=1)
        {
        /* Read Spot from file. Read SRef from file. Read q from file. Read sigma from file */
        openfilemcEqLinkStructNote3MR(IOUNIT3,"Basket.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcEqLinkStructNote3M(IOUNIT3,
               "%lg%lg%lg%lg",4,((&Spot(itvar1)),(&SRef(itvar1)),(&q(itvar1)),(&sigma(itvar1))));
        }
        fclose(IOUNIT3);
        /* Read rho from file */
        openfilemcEqLinkStructNote3MR(IOUNIT4,"rho.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            for (itvar2=1; itvar2<=nD; itvar2++) {
                fscanfMmcEqLinkStructNote3M(IOUNIT4,"%lg",1,((&rho(itvar1,itvar2))));
            }
        }
        fclose(IOUNIT4);
        }
    /*                            */
    /* Call the computation function. */
    mcEqLinkStructNote3fn(BonusCoupon,CallBarrier,cascade,KnockInLevel,MatCoupon,nD,nObs,Notional,nSub,ObsDates,pMax,q,r
       ,rho,Series,sigma,Spot,SRef,TMax,Vx);
    /*                            */
    /* Writing collected output to file Value.out from ResultEqc. */
    openfilemcEqLinkStructNote3MW(IOUNIT,"Value.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




