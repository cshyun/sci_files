#ifndef MCEQLINKSTRUCTNOTE3_H
#define MCEQLINKSTRUCTNOTE3_H

#include "SciArrayN.h" /* SciComp arrays */

void mcEqLinkStructNote3fn(
    double BonusCoupon,
    const SciArray1<double>& CallBarrier,
    double cascade,
    double KnockInLevel,
    double MatCoupon,
    int nD,
    int nObs,
    double Notional,
    int nSub,
    const SciArray1<double>& ObsDates,
    int pMax,
    const SciArray1<double>& q,
    double r,
    const SciArray2<double>& rho,
    int Series,
    const SciArray1<double>& sigma,
    const SciArray1<double>& Spot,
    const SciArray1<double>& SRef,
    double TMax,
    double & Vx
    );
     


#endif /* MCEQLINKSTRUCTNOTE3_H */
