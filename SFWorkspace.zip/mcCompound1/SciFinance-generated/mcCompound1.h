#ifndef MCCOMPOUND1_H
#define MCCOMPOUND1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcCompound1fn(
    int callC,
    int callU,
    double KC,
    double KU,
    int maxord,
    int pMax,
    int pMaxI,
    double q,
    double r,
    int Series,
    double sigma,
    double Spot,
    double SpotI,
    double T1,
    double TMax,
    double & VCx,
    double & VUx
    );
     


#endif /* MCCOMPOUND1_H */
