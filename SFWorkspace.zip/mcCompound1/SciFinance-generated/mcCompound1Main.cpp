



#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcCompound1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcCompound1MW
#define openfilemcCompound1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcCompound1MR
#define openfilemcCompound1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcCompound1M
#define fscanfMmcCompound1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }



int main()
{
    int maxord,pMax,pMaxI,Series;
    int callC,callU;
    ArgumentRecord initInputTable[15];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2;
    double KC,KU,q,r,sigma,Spot,SpotI,T1,TMax,VCx,VUx;
    
    /* *** Key to program variables: *** */
    /* callC, callU, KC, KU, maxord, q, Series, sigma, Spot, SpotI, T1: solution variable */
    /* IOUNIT, IOUNIT1, IOUNIT2: I/O channel */
    /* pMax: maximum for path */
    /* pMaxI: maximum for pathI */
    /* r: discount rate */
    /* TMax: maximum time */
    /* VCx, VUx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcCompound1MR(IOUNIT2,"init.dat");
    setupargs(initInputTable, 0, "callC", callC, READINPUTSBOOLEAN);
    setupargs(initInputTable, 1, "callU", callU, READINPUTSBOOLEAN);
    setupargs(initInputTable, 2, "KC", KC, READINPUTSDOUBLE);
    setupargs(initInputTable, 3, "KU", KU, READINPUTSDOUBLE);
    setupargs(initInputTable, 4, "maxord", maxord, READINPUTSINTEGER);
    setupargs(initInputTable, 5, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 6, "pMaxI", pMaxI, READINPUTSINTEGER);
    setupargs(initInputTable, 7, "q", q, READINPUTSDOUBLE);
    setupargs(initInputTable, 8, "r", r, READINPUTSDOUBLE);
    setupargs(initInputTable, 9, "Series", Series, READINPUTSINTEGER);
    setupargs(initInputTable, 10, "sigma", sigma, READINPUTSDOUBLE);
    setupargs(initInputTable, 11, "Spot", Spot, READINPUTSDOUBLE);
    setupargs(initInputTable, 12, "SpotI", SpotI, READINPUTSDOUBLE);
    setupargs(initInputTable, 13, "T1", T1, READINPUTSDOUBLE);
    setupargs(initInputTable, 14, "TMax", TMax, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT2,initInputTable,15)!=0)
        {
        fclose(IOUNIT2);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT2);
    /*                            */
    /* Call the computation function. */
    mcCompound1fn(callC,callU,KC,KU,maxord,pMax,pMaxI,q,r,Series,sigma,Spot,SpotI,T1,TMax,VCx,VUx);
    /*                            */
    /* Writing collected output to file VU.out from ResultEqc. */
    openfilemcCompound1MW(IOUNIT,"VU.out");
    fprintf(IOUNIT, " %18.8e\n", VUx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* Writing collected output to file VC.out from ResultEq1c. */
    openfilemcCompound1MW(IOUNIT1,"VC.out");
    fprintf(IOUNIT1, " %18.8e\n", VCx);
    fprintf(IOUNIT1, "\n");
    fclose(IOUNIT1);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




