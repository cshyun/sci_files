#ifndef CORRIDOR3_H
#define CORRIDOR3_H

#include "SciArrayN.h" /* SciComp arrays */

void corridor3fn(
    double Accuracy,
    int asset,
    double D0,
    int iMax,
    double K,
    const SciArray1<double>& LBDates,
    const SciArray1<double>& LBLevels,
    int nLB,
    int nMax,
    int nUB,
    int put,
    double r,
    double Spot,
    double TMax,
    const SciArray1<double>& UBDates,
    const SciArray1<double>& UBLevels,
    double & atSpotx
    );
     


#endif /* CORRIDOR3_H */
