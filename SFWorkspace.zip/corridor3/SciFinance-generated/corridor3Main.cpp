/*** Key to program variables: ***
  Accuracy: solution variable; an input
  asset: solution variable; an input
  D0: continuous dividend yield; an input
  iMax: number of grid cells for xi; an input
  K: solution variable; an input
  LBDates: solution variable; an input
  LBLevels: solution variable; an input
  nLB: array maximum for LBLevels and LBDates; an input
  nMax: number of grid cells for tau; an input
  nUB: array maximum for UBLevels and UBDates; an input
  put: solution variable; an input
  r: interest rate; an input
  Spot: solution variable; an input
  TMax: minimum physical value in dimension tau; an input
  UBDates: solution variable; an input
  UBLevels: solution variable; an input
  atSpotx: solution variable; an output
*** end Key to program variables: ***/


/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for LBDates in file "LBDates.dat" has maximum index
      nLB, 
     with minimum index 0.
         nLB should be on line 1 of the file.
   Following should be the 1 + nLB elements,
      to be stored in LBDates(0..nLB).

   The table for LBLevels in file "LBLevels.dat" has maximum index
      nLB, 
     with minimum index 0.
         nLB should be on line 1 of the file.
   Following should be the 1 + nLB elements,
      to be stored in LBLevels(0..nLB).

   The table for UBDates in file "UBDates.dat" has maximum index
      nUB, 
     with minimum index 0.
         nUB should be on line 1 of the file.
   Following should be the 1 + nUB elements,
      to be stored in UBDates(0..nUB).

   The table for UBLevels in file "UBLevels.dat" has maximum index
      nUB, 
     with minimum index 0.
         nUB should be on line 1 of the file.
   Following should be the 1 + nUB elements,
      to be stored in UBLevels(0..nUB).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "corridor3.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilecorridor3MW
#define openfilecorridor3MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilecorridor3MR
#define openfilecorridor3MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMcorridor3M
#define fscanfMcorridor3M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1


int main()
{
    int asset,iMax,itvar1,nLB,nMax,nUB;
    double Accuracy,atSpotx,D0,K,r,Spot,TMax;
    ArgumentRecord ddbInputTable[10];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4,*IOUNIT5;
    int put;
    
    /* *** Key to program variables: *** */
    /* Accuracy, asset, atSpotx, K, LBDates, LBLevels, put, Spot, UBDates, UBLevels: solution variable */
    /* D0: continuous dividend yield */
    /* iMax: number of grid cells for xi */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5: I/O channel */
    /* nLB: array maximum for LBLevels and LBDates */
    /* nMax: number of grid cells for tau */
    /* nUB: array maximum for UBLevels and UBDates */
    /* r: interest rate */
    /* TMax: minimum physical value in dimension tau */
    try {
    /* Read Tagged Input File */
    openfilecorridor3MR(IOUNIT1,"ddb.dat");
    setupargs(ddbInputTable, 0, "Accuracy", Accuracy, READINPUTSDOUBLE);
    setupargs(ddbInputTable, 1, "asset", asset, READINPUTSINTEGER);
    setupargs(ddbInputTable, 2, "D0", D0, READINPUTSDOUBLE);
    setupargs(ddbInputTable, 3, "iMax", iMax, READINPUTSINTEGER);
    setupargs(ddbInputTable, 4, "K", K, READINPUTSDOUBLE);
    setupargs(ddbInputTable, 5, "nMax", nMax, READINPUTSINTEGER);
    setupargs(ddbInputTable, 6, "put", put, READINPUTSBOOLEAN);
    setupargs(ddbInputTable, 7, "r", r, READINPUTSDOUBLE);
    setupargs(ddbInputTable, 8, "Spot", Spot, READINPUTSDOUBLE);
    setupargs(ddbInputTable, 9, "TMax", TMax, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,ddbInputTable,10)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    /* Read LBDates from file */
    openfilecorridor3MR(IOUNIT2,"LBDates.dat");
    fscanfMcorridor3M(IOUNIT2,"%i",1,((&nLB)));
    SciArray1<double>LBDates(nLB + 1);
    if (nLB>=0)
        {
        for (itvar1=0; itvar1<=nLB; itvar1++) {
            fscanfMcorridor3M(IOUNIT2,"%lg",1,((&LBDates(itvar1))));
        }
        }
    fclose(IOUNIT2);
    /* Read LBLevels from file */
    openfilecorridor3MR(IOUNIT3,"LBLevels.dat");
    fscanfMcorridor3M(IOUNIT3,"%i",1,((&nLB)));
    SciArray1<double>LBLevels(nLB + 1);
    if (nLB>=0)
        {
        for (itvar1=0; itvar1<=nLB; itvar1++) {
            fscanfMcorridor3M(IOUNIT3,"%lg",1,((&LBLevels(itvar1))));
        }
        }
    fclose(IOUNIT3);
    /* Read UBDates from file */
    openfilecorridor3MR(IOUNIT4,"UBDates.dat");
    fscanfMcorridor3M(IOUNIT4,"%i",1,((&nUB)));
    SciArray1<double>UBDates(nUB + 1);
    if (nUB>=0)
        {
        for (itvar1=0; itvar1<=nUB; itvar1++) {
            fscanfMcorridor3M(IOUNIT4,"%lg",1,((&UBDates(itvar1))));
        }
        }
    fclose(IOUNIT4);
    /* Read UBLevels from file */
    openfilecorridor3MR(IOUNIT5,"UBLevels.dat");
    fscanfMcorridor3M(IOUNIT5,"%i",1,((&nUB)));
    SciArray1<double>UBLevels(nUB + 1);
    if (nUB>=0)
        {
        for (itvar1=0; itvar1<=nUB; itvar1++) {
            fscanfMcorridor3M(IOUNIT5,"%lg",1,((&UBLevels(itvar1))));
        }
        }
    fclose(IOUNIT5);
    /*                            */
    /* Call the computation function. */
    corridor3fn(Accuracy,asset,D0,iMax,K,LBDates,LBLevels,nLB,nMax,nUB,put,r,Spot,TMax,UBDates,UBLevels,atSpotx);
    /*                            */
    /* Writing collected output to file atSpot.out from ResultEqc. */
    openfilecorridor3MW(IOUNIT,"atSpot.out");
    fprintf(IOUNIT, " %18.8e\n", atSpotx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




