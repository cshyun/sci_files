#ifndef MCCIRBOND1_H
#define MCCIRBOND1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcCIRBond1fn(
    double kappa,
    int nMax,
    int pMax,
    double rfloor,
    double rSpot,
    int Seed,
    double sigma,
    double theta,
    double TMax,
    double & devx,
    double & Vx
    );
     


#endif /* MCCIRBOND1_H */
