

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for tsamp in file "AsamplingTime.dat" has maximum index
      nsampToGo, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nsampToGo elements,
      to be stored in tsamp(1..nsampToGo).

   The table for weight in file "AsamplingTime.dat" has maximum index
      nsampToGo, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nsampToGo elements,
      to be stored in weight(1..nsampToGo).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcAveStrike1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcAveStrike1MW
#define openfilemcAveStrike1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcAveStrike1MR
#define openfilemcAveStrike1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcAveStrike1M
#define fscanfMmcAveStrike1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2


int main()
{
    int itvar1,nsampSoFar,nsampToGo,pMax,Series;
    ArgumentRecord initInputTable[11];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2;
    double lastA,q,r,sigma,Spot,TMax,Vx;
    int put;
    
    /* *** Key to program variables: *** */
    /* IOUNIT, IOUNIT1, IOUNIT2: I/O channel */
    /* lastA, nsampSoFar, put, q, Series, sigma, Spot, tsamp, weight: solution variable */
    /* nsampToGo: array maximum for tsamp and weight */
    /* pMax: maximum for path */
    /* r: discount rate */
    /* TMax: maximum time */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcAveStrike1MR(IOUNIT1,"init.dat");
    setupargs(initInputTable, 0, "lastA", lastA, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "nsampSoFar", nsampSoFar, READINPUTSINTEGER);
    setupargs(initInputTable, 2, "nsampToGo", nsampToGo, READINPUTSINTEGER);
    setupargs(initInputTable, 3, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 4, "put", put, READINPUTSBOOLEAN);
    setupargs(initInputTable, 5, "q", q, READINPUTSDOUBLE);
    setupargs(initInputTable, 6, "r", r, READINPUTSDOUBLE);
    setupargs(initInputTable, 7, "Series", Series, READINPUTSINTEGER);
    setupargs(initInputTable, 8, "sigma", sigma, READINPUTSDOUBLE);
    setupargs(initInputTable, 9, "Spot", Spot, READINPUTSDOUBLE);
    setupargs(initInputTable, 10, "TMax", TMax, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,initInputTable,11)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    SciArray1<double>tsamp(nsampToGo + 1);
    SciArray1<double>weight(nsampToGo + 1);
    /* Read tsamp from file. Read weight from file */
    if (nsampToGo>=1)
        {
        openfilemcAveStrike1MR(IOUNIT2,"AsamplingTime.dat");
        for (itvar1=1; itvar1<=nsampToGo; itvar1++) {
            fscanfMmcAveStrike1M(IOUNIT2,"%lg%lg",2,((&tsamp(itvar1)),(&weight(itvar1))));
        }
        fclose(IOUNIT2);
        }
    /*                            */
    /* Call the computation function. */
    mcAveStrike1fn(lastA,nsampSoFar,nsampToGo,pMax,put,q,r,Series,sigma,Spot,TMax,tsamp,weight,Vx);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfilemcAveStrike1MW(IOUNIT,"V.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




