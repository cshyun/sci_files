#ifndef MCAVERATE1_H
#define MCAVERATE1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcAveRate1fn(
    double K,
    double lastA,
    int nsampSoFar,
    int nsampToGo,
    int pMax,
    int put,
    double q,
    double r,
    int Series,
    double sigma,
    double Spot,
    double TMax,
    const SciArray1<double>& tsamp,
    const SciArray1<double>& weight,
    double & Vx
    );
     


#endif /* MCAVERATE1_H */
