#ifndef MCCSO7_H
#define MCCSO7_H

#include "SciArrayN.h" /* SciComp arrays */

void mcCSO7fn(
    const SciArray1<double>& aFac,
    double beta1,
    double beta2,
    double CdsBump,
    const SciArray2<double>& CdsCurve,
    double CdsInit,
    double CdsInterval,
    const SciArray1<double>& CdsTCurve,
    const SciArray1<double>& Detach,
    double FacBump,
    const SciArray1<int>& MezzLDswitch,
    const SciArray1<int>& MezzLFswitch,
    const SciArray1<int>& MezzPDswitch,
    const SciArray1<int>& MezzPFswitch,
    int nC,
    int ncds,
    int nD,
    const SciArray1<double>& Notional,
    int nT,
    int nZ,
    int pMax,
    int RecSwitch,
    const SciArray1<double>& RSpread,
    const SciArray1<double>& tC,
    const SciArray1<double>& TCurve,
    double UFee,
    double UniformRecovery,
    const SciArray1<double>& ZCurve,
    SciArray1<double>& FairValuex,
    SciArray1<double>& FSpreadx,
    SciArray1<double>& LossValuex,
    SciArray1<double>& MezzLDeltax,
    SciArray1<double>& MezzLFacDeltax,
    SciArray1<double>& MezzPDeltax,
    SciArray1<double>& MezzPFacDeltax,
    SciArray1<double>& PremValuex
    );
     


#endif /* MCCSO7_H */
