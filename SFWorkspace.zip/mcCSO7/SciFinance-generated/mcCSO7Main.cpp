

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for aFac in file "aFac.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in aFac(1..nD).

   The table for CdsCurve in file "CdsCurves.dat" has maximum indices
      nD and ncds, 
     with minimum indices 1, 1 respectively.
      The index bounds are not read from this file.
        Following should be the ncds*nD elements,
      to be stored in CdsCurve(1..nD, 1..ncds).
   The first index is the most slowly varying and 
      the last index is the most rapidly varying.

   The table for CdsTCurve in file "CdsTCurve.dat" has maximum index
      ncds, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the ncds elements,
      to be stored in CdsTCurve(1..ncds).

   The table for Detach in file "Detachment.dat" has maximum index
      nT, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nT elements,
      to be stored in Detach(1..nT).

   The table for MezzLDswitch in file "MezzLDswitch.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in MezzLDswitch(1..nD).

   The table for MezzLFswitch in file "MezzLFswitch.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in MezzLFswitch(1..nD).

   The table for MezzPDswitch in file "MezzPDswitch.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in MezzPDswitch(1..nD).

   The table for MezzPFswitch in file "MezzPFswitch.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in MezzPFswitch(1..nD).

   The table for Notional in file "Notional.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in Notional(1..nD).

   The table for RSpread in file "RSpread.dat" has maximum index
      nT, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nT elements,
      to be stored in RSpread(1..nT).

   The table for tC in file "PaymentDates.dat" has maximum index
      nC, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nC elements,
      to be stored in tC(1..nC).

   The table for TCurve in file "ZCurve.dat" has maximum index
      nZ, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nZ elements,
      to be stored in TCurve(1..nZ).

   The table for ZCurve in file "ZCurve.dat" has maximum index
      nZ, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nZ elements,
      to be stored in ZCurve(1..nZ).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcCSO7.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcCSO7MW
#define openfilemcCSO7MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcCSO7MR
#define openfilemcCSO7MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcCSO7M
#define fscanfMmcCSO7M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2


int main()
{
    int i,iT,itvar1,itvar2,nC,ncds,nD,nT,nZ,pMax,RecSwitch;
    double beta1,beta2,CdsBump,CdsInit,CdsInterval,FacBump,UFee,UniformRecovery;
    ArgumentRecord initInputTable[15];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT10,*IOUNIT11,*IOUNIT12,*IOUNIT13,*IOUNIT14,*IOUNIT15,*IOUNIT16,*IOUNIT17,*IOUNIT2,*
       IOUNIT3,*IOUNIT4,*IOUNIT5,*IOUNIT6,*IOUNIT7,*IOUNIT8,*IOUNIT9;
    
    /* *** Key to program variables: *** */
    /* aFac, beta1, beta2, CdsBump, CdsCurve, CdsInit, CdsInterval, CdsTCurve, Detach, FacBump, FairValue, FSpread,     
       MezzLDswitch, MezzLFswitch, MezzPDswitch, MezzPFswitch, Notional, RecSwitch, RSpread, tC, TCurve, UFee,          
       UniformRecovery, ZCurve: solution variable */
    /* i, iT: vector index */
    /* IOUNIT, IOUNIT1, IOUNIT10, IOUNIT11, IOUNIT12, IOUNIT13, IOUNIT14, IOUNIT15, IOUNIT16, IOUNIT17, IOUNIT2,        
       IOUNIT3, IOUNIT4, IOUNIT5, IOUNIT6, IOUNIT7, IOUNIT8, IOUNIT9: I/O channel */
    /* LossValue, PremValue: discounted value */
    /* MezzLDelta: greek for if[MezzLDswitch, der[LossValue[2], {h, 1}], seq[]] */
    /* MezzLFacDelta: greek for if[MezzLFswitch, der[LossValue[2], {aFac, 1}], seq[]] */
    /* MezzPDelta: greek for if[MezzPDswitch, der[PremValue[2], {h, 1}], seq[]] */
    /* MezzPFacDelta: greek for if[MezzPFswitch, der[PremValue[2], {aFac, 1}], seq[]] */
    /* nC: array maximum for tC */
    /* ncds: array maximum for CdsCurve and CdsTCurve */
    /* nD: maximum for i */
    /* nT: maximum for iT */
    /* nZ: array maximum for ZCurve and TCurve */
    /* pMax: maximum for path */
    try {
    /* Read Tagged Input File */
    openfilemcCSO7MR(IOUNIT5,"init.dat");
    setupargs(initInputTable, 0, "beta1", beta1, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "beta2", beta2, READINPUTSDOUBLE);
    setupargs(initInputTable, 2, "CdsBump", CdsBump, READINPUTSDOUBLE);
    setupargs(initInputTable, 3, "CdsInit", CdsInit, READINPUTSDOUBLE);
    setupargs(initInputTable, 4, "CdsInterval", CdsInterval, READINPUTSDOUBLE);
    setupargs(initInputTable, 5, "FacBump", FacBump, READINPUTSDOUBLE);
    setupargs(initInputTable, 6, "nC", nC, READINPUTSINTEGER);
    setupargs(initInputTable, 7, "ncds", ncds, READINPUTSINTEGER);
    setupargs(initInputTable, 8, "nD", nD, READINPUTSINTEGER);
    setupargs(initInputTable, 9, "nT", nT, READINPUTSINTEGER);
    setupargs(initInputTable, 10, "nZ", nZ, READINPUTSINTEGER);
    setupargs(initInputTable, 11, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 12, "RecSwitch", RecSwitch, READINPUTSINTEGER);
    setupargs(initInputTable, 13, "UFee", UFee, READINPUTSDOUBLE);
    setupargs(initInputTable, 14, "UniformRecovery", UniformRecovery, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT5,initInputTable,15)!=0)
        {
        fclose(IOUNIT5);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT5);
    SciArray1<double>aFac(nD + 1);
    SciArray1<int>MezzLDswitch(nD + 1);
    SciArray1<int>MezzLFswitch(nD + 1);
    SciArray1<int>MezzPDswitch(nD + 1);
    SciArray1<int>MezzPFswitch(nD + 1);
    SciArray1<double>Notional(nD + 1);
    if (nD>=1)
        {
        /* Read aFac from file */
        openfilemcCSO7MR(IOUNIT6,"aFac.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCSO7M(IOUNIT6,"%lg",1,((&aFac(itvar1))));
        }
        fclose(IOUNIT6);
        /* Read MezzLDswitch from file */
        openfilemcCSO7MR(IOUNIT7,"MezzLDswitch.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCSO7M(IOUNIT7,"%i",1,((&MezzLDswitch(itvar1))));
        }
        fclose(IOUNIT7);
        /* Read MezzLFswitch from file */
        openfilemcCSO7MR(IOUNIT8,"MezzLFswitch.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCSO7M(IOUNIT8,"%i",1,((&MezzLFswitch(itvar1))));
        }
        fclose(IOUNIT8);
        /* Read MezzPDswitch from file */
        openfilemcCSO7MR(IOUNIT9,"MezzPDswitch.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCSO7M(IOUNIT9,"%i",1,((&MezzPDswitch(itvar1))));
        }
        fclose(IOUNIT9);
        /* Read MezzPFswitch from file */
        openfilemcCSO7MR(IOUNIT10,"MezzPFswitch.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCSO7M(IOUNIT10,"%i",1,((&MezzPFswitch(itvar1))));
        }
        fclose(IOUNIT10);
        /* Read Notional from file */
        openfilemcCSO7MR(IOUNIT11,"Notional.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCSO7M(IOUNIT11,"%lg",1,((&Notional(itvar1))));
        }
        fclose(IOUNIT11);
        }
    /* Read CdsCurve from file */
    SciArray2<double>CdsCurve(nD + 1, ncds + 1);
    if ((ncds>=1&&nD>=1))
        {
        openfilemcCSO7MR(IOUNIT12,"CdsCurves.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            for (itvar2=1; itvar2<=ncds; itvar2++) {
                fscanfMmcCSO7M(IOUNIT12,"%lg",1,((&CdsCurve(itvar1,itvar2))));
            }
        }
        fclose(IOUNIT12);
        }
    /* Read CdsTCurve from file */
    SciArray1<double>CdsTCurve(ncds + 1);
    if (ncds>=1)
        {
        openfilemcCSO7MR(IOUNIT13,"CdsTCurve.dat");
        for (itvar1=1; itvar1<=ncds; itvar1++) {
            fscanfMmcCSO7M(IOUNIT13,"%lg",1,((&CdsTCurve(itvar1))));
        }
        fclose(IOUNIT13);
        }
    /* Read Detach from file */
    SciArray1<double>Detach(nT + 1);
    if (nT>=1)
        {
        openfilemcCSO7MR(IOUNIT14,"Detachment.dat");
        for (itvar1=1; itvar1<=nT; itvar1++) {
            fscanfMmcCSO7M(IOUNIT14,"%lg",1,((&Detach(itvar1))));
        }
        fclose(IOUNIT14);
        }
    /* Read tC from file */
    SciArray1<double>tC(nC + 1);
    if (nC>=1)
        {
        openfilemcCSO7MR(IOUNIT15,"PaymentDates.dat");
        for (itvar1=1; itvar1<=nC; itvar1++) {
            fscanfMmcCSO7M(IOUNIT15,"%lg",1,((&tC(itvar1))));
        }
        fclose(IOUNIT15);
        }
    /* Read RSpread from file */
    SciArray1<double>RSpread(nT + 1);
    if (nT>=1)
        {
        openfilemcCSO7MR(IOUNIT16,"RSpread.dat");
        for (itvar1=1; itvar1<=nT; itvar1++) {
            fscanfMmcCSO7M(IOUNIT16,"%lg",1,((&RSpread(itvar1))));
        }
        fclose(IOUNIT16);
        }
    SciArray1<double>ZCurve(nZ + 1);
    SciArray1<double>TCurve(nZ + 1);
    /* Read ZCurve from file. Read TCurve from file */
    if (nZ>=1)
        {
        openfilemcCSO7MR(IOUNIT17,"ZCurve.dat");
        for (itvar1=1; itvar1<=nZ; itvar1++) {
            fscanfMmcCSO7M(IOUNIT17,"%lg%lg",2,((&ZCurve(itvar1)),(&TCurve(itvar1))));
        }
        fclose(IOUNIT17);
        }
    /*                            */
    /* Call the computation function. */
    SciArray1<double> FairValue;
    SciArray1<double> FSpread;
    SciArray1<double> LossValue;
    SciArray1<double> MezzLDelta;
    SciArray1<double> MezzLFacDelta;
    SciArray1<double> MezzPDelta;
    SciArray1<double> MezzPFacDelta;
    SciArray1<double> PremValue;
    mcCSO7fn(aFac,beta1,beta2,CdsBump,CdsCurve,CdsInit,CdsInterval,CdsTCurve,Detach,FacBump,MezzLDswitch,MezzLFswitch,
       MezzPDswitch,MezzPFswitch,nC,ncds,nD,Notional,nT,nZ,pMax,RecSwitch,RSpread,tC,TCurve,UFee,UniformRecovery,ZCurve,
       FairValue,FSpread,LossValue,MezzLDelta,MezzLFacDelta,MezzPDelta,MezzPFacDelta,PremValue);
    /*                            */
    /* Writing collected output to file FairValue.out from ResultEqc. */
    openfilemcCSO7MW(IOUNIT,"FairValue.out");
    for (iT=1; iT<=(int)FairValue.size0() - 1; iT++) {
        fprintf(IOUNIT, " %18.8e\n", FairValue(iT));
    }
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* Writing collected output to file PremValue.out from ResultEq1c. */
    openfilemcCSO7MW(IOUNIT1,"PremValue.out");
    for (iT=1; iT<=(int)PremValue.size0() - 1; iT++) {
        fprintf(IOUNIT1, " %18.8e\n", PremValue(iT));
    }
    fprintf(IOUNIT1, "\n");
    fclose(IOUNIT1);
    /* Writing collected output to file LossValue.out from ResultEq2c. */
    openfilemcCSO7MW(IOUNIT2,"LossValue.out");
    for (iT=1; iT<=(int)LossValue.size0() - 1; iT++) {
        fprintf(IOUNIT2, " %18.8e\n", LossValue(iT));
    }
    fprintf(IOUNIT2, "\n");
    fclose(IOUNIT2);
    /* Writing collected output to file FairSpread.out from ResultEq3c. */
    openfilemcCSO7MW(IOUNIT3,"FairSpread.out");
    for (iT=1; iT<=(int)FSpread.size0() - 1; iT++) {
        fprintf(IOUNIT3, " %18.8e\n", FSpread(iT));
    }
    fprintf(IOUNIT3, "\n");
    fclose(IOUNIT3);
    /* Writing collected output to file MezzDelta.out from ResultEq4c. */
    openfilemcCSO7MW(IOUNIT4,"MezzDelta.out");
    for (i=1; i<=(int)MezzPDelta.size0() - 1; i++) {
        fprintf(IOUNIT4, " %18.8e\n", MezzPDelta(i));
    }
    fprintf(IOUNIT4, "\n");
    /* Writing collected output to file MezzDelta.out from ResultEq5c. */
    for (i=1; i<=(int)MezzLDelta.size0() - 1; i++) {
        fprintf(IOUNIT4, " %18.8e\n", MezzLDelta(i));
    }
    fprintf(IOUNIT4, "\n");
    /* Writing collected output to file MezzDelta.out from ResultEq6c. */
    for (i=1; i<=(int)MezzPFacDelta.size0() - 1; i++) {
        fprintf(IOUNIT4, " %18.8e\n", MezzPFacDelta(i));
    }
    fprintf(IOUNIT4, "\n");
    /* Writing collected output to file MezzDelta.out from ResultEq7c. */
    for (i=1; i<=(int)MezzLFacDelta.size0() - 1; i++) {
        fprintf(IOUNIT4, " %18.8e\n", MezzLFacDelta(i));
    }
    fprintf(IOUNIT4, "\n");
    fclose(IOUNIT4);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




