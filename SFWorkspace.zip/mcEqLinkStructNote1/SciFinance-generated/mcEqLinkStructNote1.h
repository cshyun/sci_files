#ifndef MCEQLINKSTRUCTNOTE1_H
#define MCEQLINKSTRUCTNOTE1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcEqLinkStructNote1fn(
    double AccruedBonus0,
    double BonusCoup,
    const SciArray1<double>& CallBarrier,
    const SciArray1<double>& KI0,
    double KIBarrier,
    double KINum,
    double MatCoup,
    int nD,
    int nObs,
    int nsub,
    const SciArray1<double>& ObsDates,
    int pMax,
    double PrevObsDate,
    const SciArray1<double>& q,
    double r,
    const SciArray2<double>& rho,
    int Series,
    const SciArray1<double>& sigma,
    const SciArray1<double>& Spot,
    const SciArray1<double>& SRef,
    double & Vx
    );
     


#endif /* MCEQLINKSTRUCTNOTE1_H */
