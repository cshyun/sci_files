

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for tsample in file "A1samplingTime.dat" has maximum index
      nsampleToGoA1, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nsampleToGoA1 elements,
      to be stored in tsample(1..nsampleToGoA1).

   The table for weight in file "A1samplingTime.dat" has maximum index
      nsampleToGoA1, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nsampleToGoA1 elements,
      to be stored in weight(1..nsampleToGoA1).


******************* END FORMAT INSTRUCTIONS *******************/


#ifdef __cplusplus
extern "C" {
#endif
extern int MCAsian2XLfn(
    double D0,
    double disc,
    double K,
    double lastA1,
    int leap,
    double loan,
    int nsampleSoFarA1,
    int nsampleToGoA1,
    int pMax,
    int put,
    double sigma,
    double Spot,
    int sskip,
    double TMax,
    double *tsample,
    double *weight,
    double *Vp,
    int * SciErrorFlagp,
    struct error_struct * SciErrorBufferp
    );
     
#ifdef __cplusplus
}
#endif
