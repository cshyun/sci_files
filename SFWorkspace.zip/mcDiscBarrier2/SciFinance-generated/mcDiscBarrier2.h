#ifndef MCDISCBARRIER2_H
#define MCDISCBARRIER2_H

#include "SciArrayN.h" /* SciComp arrays */

void mcDiscBarrier2fn(
    double B,
    int deferrable,
    int in,
    double K,
    int nsamp,
    int pMax,
    int put,
    double q,
    double r,
    double Rebate,
    int Series,
    double sigma,
    double Spot,
    double TMax,
    const SciArray1<double>& tsamp,
    int up,
    double & Vx
    );
     


#endif /* MCDISCBARRIER2_H */
