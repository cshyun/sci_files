

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for AccrualCms in file "CouponStruct.dat" has maximum index
      nCpn, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nCpn elements,
      to be stored in AccrualCms(1..nCpn).

   The table for ExerciseDates in file "ExerciseDates.dat" has maximum index
      nExer, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nExer elements,
      to be stored in ExerciseDates(1..nExer).

   The table for PaymentDates in file "CouponStruct.dat" has maximum index
      nCpn, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nCpn elements,
      to be stored in PaymentDates(1..nCpn).

   The table for RanMonitorDates in file "RanMonitorDates.dat" has maximum index
      nMon, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nMon elements,
      to be stored in RanMonitorDates(1..nMon).

   The table for RanResetDates in file "RanResetDates.dat" has maximum index
      nRst, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nRst elements,
      to be stored in RanResetDates(1..nRst).

   The table for zDates in file "ZeroCurve.dat" has maximum index
      nZero, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nZero elements,
      to be stored in zDates(0..nZero).

   The table for zRates in file "ZeroCurve.dat" has maximum index
      nZero, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nZero elements,
      to be stored in zRates(0..nZero).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcG2CallCMSSpreadRANote1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcG2CallCMSSpreadRANote1MW
#define openfilemcG2CallCMSSpreadRANote1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcG2CallCMSSpreadRANote1MR
#define openfilemcG2CallCMSSpreadRANote1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcG2CallCMSSpreadRANote1M
#define fscanfMmcG2CallCMSSpreadRANote1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2


int main()
{
    int itvar1,maxord1,maxord2,maxord3,nCMS1,nCMS2,nCpn,nExer,nMax,nMon,nRst,nZero,pMax,Series;
    double CallPrice,CmsInitCoupon,kappa1,kappa2,Notional,rho12,Rmax,Rmin,sigma1,sigma2,Spread,tauCMS,Vx;
    ArgumentRecord initInputTable[25];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4,*IOUNIT5,*IOUNIT6;
    
    /* *** Key to program variables: *** */
    /* AccrualCms, CallPrice, CmsInitCoupon, ExerciseDates, kappa1, kappa2, maxord1, maxord2, maxord3, nCMS1, nCMS2,    
       Notional, PaymentDates, RanMonitorDates, RanResetDates, rho12, Rmax, Rmin, Series, sigma1, sigma2, Spread,       
       tauCMS, zDates, zRates: solution variable */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5, IOUNIT6: I/O channel */
    /* nCpn: array maximum for PaymentDates, AccrualCms and AccrualFlt */
    /* nExer: array maximum for ExerciseDates */
    /* nMax: number of grid cells for t */
    /* nMon: array maximum for RanMonitorDates */
    /* nRst: array maximum for RanResetDates */
    /* nZero: array maximum for zDates and zRates */
    /* pMax: maximum for path */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcG2CallCMSSpreadRANote1MR(IOUNIT1,"init.dat");
    setupargs(initInputTable, 0, "CallPrice", CallPrice, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "CmsInitCoupon", CmsInitCoupon, READINPUTSDOUBLE);
    setupargs(initInputTable, 2, "kappa1", kappa1, READINPUTSDOUBLE);
    setupargs(initInputTable, 3, "kappa2", kappa2, READINPUTSDOUBLE);
    setupargs(initInputTable, 4, "maxord1", maxord1, READINPUTSINTEGER);
    setupargs(initInputTable, 5, "maxord2", maxord2, READINPUTSINTEGER);
    setupargs(initInputTable, 6, "maxord3", maxord3, READINPUTSINTEGER);
    setupargs(initInputTable, 7, "nCMS1", nCMS1, READINPUTSINTEGER);
    setupargs(initInputTable, 8, "nCMS2", nCMS2, READINPUTSINTEGER);
    setupargs(initInputTable, 9, "nCpn", nCpn, READINPUTSINTEGER);
    setupargs(initInputTable, 10, "nExer", nExer, READINPUTSINTEGER);
    setupargs(initInputTable, 11, "nMax", nMax, READINPUTSINTEGER);
    setupargs(initInputTable, 12, "nMon", nMon, READINPUTSINTEGER);
    setupargs(initInputTable, 13, "Notional", Notional, READINPUTSDOUBLE);
    setupargs(initInputTable, 14, "nRst", nRst, READINPUTSINTEGER);
    setupargs(initInputTable, 15, "nZero", nZero, READINPUTSINTEGER);
    setupargs(initInputTable, 16, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 17, "rho12", rho12, READINPUTSDOUBLE);
    setupargs(initInputTable, 18, "Rmax", Rmax, READINPUTSDOUBLE);
    setupargs(initInputTable, 19, "Rmin", Rmin, READINPUTSDOUBLE);
    setupargs(initInputTable, 20, "Series", Series, READINPUTSINTEGER);
    setupargs(initInputTable, 21, "sigma1", sigma1, READINPUTSDOUBLE);
    setupargs(initInputTable, 22, "sigma2", sigma2, READINPUTSDOUBLE);
    setupargs(initInputTable, 23, "Spread", Spread, READINPUTSDOUBLE);
    setupargs(initInputTable, 24, "tauCMS", tauCMS, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,initInputTable,25)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    SciArray1<double>PaymentDates(nCpn + 1);
    SciArray1<double>AccrualCms(nCpn + 1);
    /* Read PaymentDates from file. Read AccrualCms from file */
    if (nCpn>=1)
        {
        openfilemcG2CallCMSSpreadRANote1MR(IOUNIT2,"CouponStruct.dat");
        for (itvar1=1; itvar1<=nCpn; itvar1++) {
            fscanfMmcG2CallCMSSpreadRANote1M(IOUNIT2,"%lg%lg",2,((&PaymentDates(itvar1)),(&AccrualCms(itvar1))));
        }
        fclose(IOUNIT2);
        }
    /* Read ExerciseDates from file */
    SciArray1<double>ExerciseDates(nExer + 1);
    if (nExer>=1)
        {
        openfilemcG2CallCMSSpreadRANote1MR(IOUNIT3,"ExerciseDates.dat");
        for (itvar1=1; itvar1<=nExer; itvar1++) {
            fscanfMmcG2CallCMSSpreadRANote1M(IOUNIT3,"%lg",1,((&ExerciseDates(itvar1))));
        }
        fclose(IOUNIT3);
        }
    /* Read RanMonitorDates from file */
    SciArray1<double>RanMonitorDates(nMon + 1);
    if (nMon>=1)
        {
        openfilemcG2CallCMSSpreadRANote1MR(IOUNIT4,"RanMonitorDates.dat");
        for (itvar1=1; itvar1<=nMon; itvar1++) {
            fscanfMmcG2CallCMSSpreadRANote1M(IOUNIT4,"%lg",1,((&RanMonitorDates(itvar1))));
        }
        fclose(IOUNIT4);
        }
    /* Read RanResetDates from file */
    SciArray1<double>RanResetDates(nRst + 1);
    if (nRst>=1)
        {
        openfilemcG2CallCMSSpreadRANote1MR(IOUNIT5,"RanResetDates.dat");
        for (itvar1=1; itvar1<=nRst; itvar1++) {
            fscanfMmcG2CallCMSSpreadRANote1M(IOUNIT5,"%lg",1,((&RanResetDates(itvar1))));
        }
        fclose(IOUNIT5);
        }
    SciArray1<double>zDates(nZero + 1);
    SciArray1<double>zRates(nZero + 1);
    /* Read zDates from file. Read zRates from file */
    if (nZero>=0)
        {
        openfilemcG2CallCMSSpreadRANote1MR(IOUNIT6,"ZeroCurve.dat");
        for (itvar1=0; itvar1<=nZero; itvar1++) {
            fscanfMmcG2CallCMSSpreadRANote1M(IOUNIT6,"%lg%lg",2,((&zDates(itvar1)),(&zRates(itvar1))));
        }
        fclose(IOUNIT6);
        }
    /*                            */
    /* Call the computation function. */
    mcG2CallCMSSpreadRANote1fn(AccrualCms,CallPrice,CmsInitCoupon,ExerciseDates,kappa1,kappa2,maxord1,maxord2,maxord3,
       nCMS1,nCMS2,nCpn,nExer,nMax,nMon,Notional,nRst,nZero,PaymentDates,pMax,RanMonitorDates,RanResetDates,rho12,Rmax,
       Rmin,Series,sigma1,sigma2,Spread,tauCMS,zDates,zRates,Vx);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfilemcG2CallCMSSpreadRANote1MW(IOUNIT,"V.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




