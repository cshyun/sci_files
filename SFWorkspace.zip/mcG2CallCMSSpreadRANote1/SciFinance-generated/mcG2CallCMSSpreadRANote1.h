#ifndef MCG2CALLCMSSPREADRANOTE1_H
#define MCG2CALLCMSSPREADRANOTE1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcG2CallCMSSpreadRANote1fn(
    const SciArray1<double>& AccrualCms,
    double CallPrice,
    double CmsInitCoupon,
    const SciArray1<double>& ExerciseDates,
    double kappa1,
    double kappa2,
    int maxord1,
    int maxord2,
    int maxord3,
    int nCMS1,
    int nCMS2,
    int nCpn,
    int nExer,
    int nMax,
    int nMon,
    double Notional,
    int nRst,
    int nZero,
    const SciArray1<double>& PaymentDates,
    int pMax,
    const SciArray1<double>& RanMonitorDates,
    const SciArray1<double>& RanResetDates,
    double rho12,
    double Rmax,
    double Rmin,
    int Series,
    double sigma1,
    double sigma2,
    double Spread,
    double tauCMS,
    const SciArray1<double>& zDates,
    const SciArray1<double>& zRates,
    double & Vx
    );
     


#endif /* MCG2CALLCMSSPREADRANOTE1_H */
