#ifndef MCEUROPEAN1_H
#define MCEUROPEAN1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcEuropean1fn(
    double K,
    int pMax,
    int put,
    double q,
    double r,
    int Seed,
    double sigma,
    double Spot,
    double TMax,
    double & devx,
    double & Vx
    );
     


#endif /* MCEUROPEAN1_H */
