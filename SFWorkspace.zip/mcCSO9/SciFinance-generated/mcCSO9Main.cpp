

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for Accrual in file "accrual.dat" has maximum index
      nC, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nC elements,
      to be stored in Accrual(1..nC).

   The table for aFac in file "aFac.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in aFac(1..nD).

   The table for CdsCurve in file "CdsCurves.dat" has maximum indices
      nD and ncds, 
     with minimum indices 1, 1 respectively.
      The index bounds are not read from this file.
        Following should be the ncds*nD elements,
      to be stored in CdsCurve(1..nD, 1..ncds).
   The first index is the most slowly varying and 
      the last index is the most rapidly varying.

   The table for CdsTCurve in file "CdsTCurve.dat" has maximum index
      ncds, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the ncds elements,
      to be stored in CdsTCurve(1..ncds).

   The table for Coupon in file "Coupon.dat" has maximum index
      nC, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nC elements,
      to be stored in Coupon(1..nC).

   The table for hDswitch in file "hDswitch.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in hDswitch(1..nD).

   The table for Notional in file "Notional.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in Notional(1..nD).

   The table for Recovery in file "Recovery.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in Recovery(1..nD).

   The table for tC in file "PaymentDates.dat" has maximum index
      nC, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nC elements,
      to be stored in tC(1..nC).

   The table for TCurve in file "ZCurve.dat" has maximum index
      nZ, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nZ elements,
      to be stored in TCurve(1..nZ).

   The table for ZCurve in file "ZCurve.dat" has maximum index
      nZ, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nZ elements,
      to be stored in ZCurve(1..nZ).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcCSO9.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcCSO9MW
#define openfilemcCSO9MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcCSO9MR
#define openfilemcCSO9MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcCSO9M
#define fscanfMmcCSO9M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2


int main()
{
    int i,iC,itvar1,itvar2,nC,ncds,nD,nZ,pMax;
    double CdsBump,CdsInit,CdsInterval,H,L,PresentValuex,TMax;
    ArgumentRecord initInputTable[11];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT10,*IOUNIT11,*IOUNIT12,*IOUNIT13,*IOUNIT14,*IOUNIT15,*IOUNIT2,*IOUNIT3,*IOUNIT4,*
       IOUNIT5,*IOUNIT6,*IOUNIT7,*IOUNIT8,*IOUNIT9;
    
    /* *** Key to program variables: *** */
    /* Accrual, aFac, CdsBump, CdsCurve, CdsInit, CdsInterval, CdsTCurve, Coupon, Dbar, DiscFac, H, hDswitch, L,        
       Notional, Recovery, tC, TCurve, ZCurve: solution variable */
    /* elossMcAve: McAve value for eloss */
    /* fpp1, fpp2: second derivative temporary array */
    /* hDelta: greek for if[hDswitch, der[PresentValue, {h, 1}], seq[]] */
    /* i: vector index */
    /* iC: index variable for DiscFactor */
    /* IOUNIT, IOUNIT1, IOUNIT10, IOUNIT11, IOUNIT12, IOUNIT13, IOUNIT14, IOUNIT15, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5, 
       IOUNIT6, IOUNIT7, IOUNIT8, IOUNIT9: I/O channel */
    /* nC: array maximum for tC, Accrual and Coupon */
    /* ncds: array maximum for CdsCurve and CdsTCurve */
    /* nD: maximum for i */
    /* nZ: array maximum for ZCurve and TCurve */
    /* pMax: maximum for path */
    /* PresentValuex: discounted value */
    /* TMax: maximum time */
    /* TriT1iC1, TriT1iZ1, TriT2iC1, TriT2iZ1: spline temporary array */
    try {
    /* Read Tagged Input File */
    openfilemcCSO9MR(IOUNIT5,"init.dat");
    setupargs(initInputTable, 0, "CdsBump", CdsBump, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "CdsInit", CdsInit, READINPUTSDOUBLE);
    setupargs(initInputTable, 2, "CdsInterval", CdsInterval, READINPUTSDOUBLE);
    setupargs(initInputTable, 3, "H", H, READINPUTSDOUBLE);
    setupargs(initInputTable, 4, "L", L, READINPUTSDOUBLE);
    setupargs(initInputTable, 5, "nC", nC, READINPUTSINTEGER);
    setupargs(initInputTable, 6, "ncds", ncds, READINPUTSINTEGER);
    setupargs(initInputTable, 7, "nD", nD, READINPUTSINTEGER);
    setupargs(initInputTable, 8, "nZ", nZ, READINPUTSINTEGER);
    setupargs(initInputTable, 9, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 10, "TMax", TMax, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT5,initInputTable,11)!=0)
        {
        fclose(IOUNIT5);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT5);
    SciArray1<double>Accrual(nC + 1);
    SciArray1<double>Coupon(nC + 1);
    SciArray1<double>tC(nC + 1);
    if (nC>=1)
        {
        /* Read Accrual from file */
        openfilemcCSO9MR(IOUNIT6,"accrual.dat");
        for (itvar1=1; itvar1<=nC; itvar1++) {
            fscanfMmcCSO9M(IOUNIT6,"%lg",1,((&Accrual(itvar1))));
        }
        fclose(IOUNIT6);
        /* Read Coupon from file */
        openfilemcCSO9MR(IOUNIT7,"Coupon.dat");
        for (itvar1=1; itvar1<=nC; itvar1++) {
            fscanfMmcCSO9M(IOUNIT7,"%lg",1,((&Coupon(itvar1))));
        }
        fclose(IOUNIT7);
        /* Read tC from file */
        openfilemcCSO9MR(IOUNIT8,"PaymentDates.dat");
        for (itvar1=1; itvar1<=nC; itvar1++) {
            fscanfMmcCSO9M(IOUNIT8,"%lg",1,((&tC(itvar1))));
        }
        fclose(IOUNIT8);
        }
    /* Read aFac from file */
    SciArray1<double>aFac(nD + 1);
    if (nD>=1)
        {
        openfilemcCSO9MR(IOUNIT9,"aFac.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCSO9M(IOUNIT9,"%lg",1,((&aFac(itvar1))));
        }
        fclose(IOUNIT9);
        }
    /* Read CdsCurve from file */
    SciArray2<double>CdsCurve(nD + 1, ncds + 1);
    if ((ncds>=1&&nD>=1))
        {
        openfilemcCSO9MR(IOUNIT10,"CdsCurves.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            for (itvar2=1; itvar2<=ncds; itvar2++) {
                fscanfMmcCSO9M(IOUNIT10,"%lg",1,((&CdsCurve(itvar1,itvar2))));
            }
        }
        fclose(IOUNIT10);
        }
    /* Read CdsTCurve from file */
    SciArray1<double>CdsTCurve(ncds + 1);
    if (ncds>=1)
        {
        openfilemcCSO9MR(IOUNIT11,"CdsTCurve.dat");
        for (itvar1=1; itvar1<=ncds; itvar1++) {
            fscanfMmcCSO9M(IOUNIT11,"%lg",1,((&CdsTCurve(itvar1))));
        }
        fclose(IOUNIT11);
        }
    SciArray1<int>hDswitch(nD + 1);
    SciArray1<double>Notional(nD + 1);
    SciArray1<double>Recovery(nD + 1);
    if (nD>=1)
        {
        /* Read hDswitch from file */
        openfilemcCSO9MR(IOUNIT12,"hDswitch.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCSO9M(IOUNIT12,"%i",1,((&hDswitch(itvar1))));
        }
        fclose(IOUNIT12);
        /* Read Notional from file */
        openfilemcCSO9MR(IOUNIT13,"Notional.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCSO9M(IOUNIT13,"%lg",1,((&Notional(itvar1))));
        }
        fclose(IOUNIT13);
        /* Read Recovery from file */
        openfilemcCSO9MR(IOUNIT14,"Recovery.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCSO9M(IOUNIT14,"%lg",1,((&Recovery(itvar1))));
        }
        fclose(IOUNIT14);
        }
    SciArray1<double>ZCurve(nZ + 1);
    SciArray1<double>TCurve(nZ + 1);
    /* Read ZCurve from file. Read TCurve from file */
    if (nZ>=1)
        {
        openfilemcCSO9MR(IOUNIT15,"ZCurve.dat");
        for (itvar1=1; itvar1<=nZ; itvar1++) {
            fscanfMmcCSO9M(IOUNIT15,"%lg%lg",2,((&ZCurve(itvar1)),(&TCurve(itvar1))));
        }
        fclose(IOUNIT15);
        }
    /*                            */
    /* Call the computation function. */
    SciArray1<double> Dbar;
    SciArray1<double> DiscFac;
    SciArray1<double> elossMcAve;
    SciArray1<double> hDelta;
    mcCSO9fn(Accrual,aFac,CdsBump,CdsCurve,CdsInit,CdsInterval,CdsTCurve,Coupon,H,hDswitch,L,nC,ncds,nD,Notional,nZ,pMax
       ,Recovery,tC,TCurve,TMax,ZCurve,Dbar,DiscFac,elossMcAve,hDelta,PresentValuex);
    /*                            */
    /* Writing collected output to file DiscFac.out from ResultEqc. */
    openfilemcCSO9MW(IOUNIT,"DiscFac.out");
    for (iC=1; iC<=(int)DiscFac.size0() - 1; iC++) {
        fprintf(IOUNIT, " %18.8e\n", DiscFac(iC));
    }
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* Writing collected output to file Dbar.out from ResultEq1c. */
    openfilemcCSO9MW(IOUNIT1,"Dbar.out");
    for (iC=1; iC<=(int)Dbar.size0() - 1; iC++) {
        fprintf(IOUNIT1, " %18.8e\n", Dbar(iC));
    }
    fprintf(IOUNIT1, "\n");
    fclose(IOUNIT1);
    /* Writing collected output to file V.out from ResultEq2c. */
    openfilemcCSO9MW(IOUNIT2,"V.out");
    fprintf(IOUNIT2, " %18.8e\n", PresentValuex);
    fprintf(IOUNIT2, "\n");
    fclose(IOUNIT2);
    /* Writing collected output to file hDelta.out from ResultEq3c. */
    openfilemcCSO9MW(IOUNIT3,"hDelta.out");
    for (i=1; i<=(int)hDelta.size0() - 1; i++) {
        fprintf(IOUNIT3, " %18.8e\n", hDelta(i));
    }
    fprintf(IOUNIT3, "\n");
    fclose(IOUNIT3);
    /* Writing collected output to file elossMcAve.out from ResultEq4c. */
    openfilemcCSO9MW(IOUNIT4,"elossMcAve.out");
    for (iC=1; iC<=(int)elossMcAve.size0() - 1; iC++) {
        fprintf(IOUNIT4, " %18.8e\n", elossMcAve(iC));
    }
    fprintf(IOUNIT4, "\n");
    fclose(IOUNIT4);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




