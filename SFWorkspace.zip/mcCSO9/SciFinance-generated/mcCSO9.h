#ifndef MCCSO9_H
#define MCCSO9_H

#include "SciArrayN.h" /* SciComp arrays */

void mcCSO9fn(
    const SciArray1<double>& Accrual,
    const SciArray1<double>& aFac,
    double CdsBump,
    const SciArray2<double>& CdsCurve,
    double CdsInit,
    double CdsInterval,
    const SciArray1<double>& CdsTCurve,
    const SciArray1<double>& Coupon,
    double H,
    const SciArray1<int>& hDswitch,
    double L,
    int nC,
    int ncds,
    int nD,
    const SciArray1<double>& Notional,
    int nZ,
    int pMax,
    const SciArray1<double>& Recovery,
    const SciArray1<double>& tC,
    const SciArray1<double>& TCurve,
    double TMax,
    const SciArray1<double>& ZCurve,
    SciArray1<double>& Dbarx,
    SciArray1<double>& DiscFacx,
    SciArray1<double>& elossMcAvex,
    SciArray1<double>& hDeltax,
    double & PresentValuex
    );
     


#endif /* MCCSO9_H */
