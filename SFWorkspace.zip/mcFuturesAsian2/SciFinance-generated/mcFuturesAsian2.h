#ifndef MCFUTURESASIAN2_H
#define MCFUTURESASIAN2_H

#include "SciArrayN.h" /* SciComp arrays */

void mcFuturesAsian2fn(
    double Ainit,
    const SciArray1<double>& alpha,
    const SciArray1<double>& beta,
    int call,
    const SciArray1<double>& FutMats,
    SciArray1<double>& FutPrice,
    double K,
    const SciArray1<double>& lambda1,
    const SciArray1<double>& lambda2,
    const SciArray1<double>& lambda3,
    int nFut,
    int nMax,
    int nSamp,
    int nSampInit,
    int nZero,
    int pMax,
    const SciArray1<double>& SampleDates,
    int Seed,
    const SciArray1<double>& SviA,
    const SciArray1<double>& SviB,
    const SciArray1<double>& SviMu,
    const SciArray1<double>& SviRho,
    const SciArray1<double>& SviSigma,
    const SciArray1<double>& Weight,
    const SciArray1<double>& zDate,
    const SciArray1<double>& zRate,
    double & devx,
    double & Vx
    );
     


#endif /* MCFUTURESASIAN2_H */
