

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for SampleDates in file "SampleDates.dat" has maximum index
      nsampToGo, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nsampToGo elements,
      to be stored in SampleDates(1..nsampToGo).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcAsianBarrier1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcAsianBarrier1MW
#define openfilemcAsianBarrier1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcAsianBarrier1MR
#define openfilemcAsianBarrier1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcAsianBarrier1M
#define fscanfMmcAsianBarrier1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1


int main()
{
    int BarType,itvar1,nsampSoFar,nsampToGo,pMax,Series;
    double ASpot,Barrier,FirstBarDate,K,q,r,Rebate,sigma,Spot,TMax,Vx;
    ArgumentRecord initInputTable[16];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2;
    int put;
    
    /* *** Key to program variables: *** */
    /* ASpot, Barrier, BarType, FirstBarDate, K, nsampSoFar, put, q, Rebate, SampleDates, Series, sigma, Spot: solution 
       variable */
    /* IOUNIT, IOUNIT1, IOUNIT2: I/O channel */
    /* nsampToGo: array maximum for SampleDates */
    /* pMax: maximum for path */
    /* r: discount rate */
    /* TMax: maximum time */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcAsianBarrier1MR(IOUNIT1,"init.dat");
    setupargs(initInputTable, 0, "ASpot", ASpot, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "Barrier", Barrier, READINPUTSDOUBLE);
    setupargs(initInputTable, 2, "BarType", BarType, READINPUTSINTEGER);
    setupargs(initInputTable, 3, "FirstBarDate", FirstBarDate, READINPUTSDOUBLE);
    setupargs(initInputTable, 4, "K", K, READINPUTSDOUBLE);
    setupargs(initInputTable, 5, "nsampSoFar", nsampSoFar, READINPUTSINTEGER);
    setupargs(initInputTable, 6, "nsampToGo", nsampToGo, READINPUTSINTEGER);
    setupargs(initInputTable, 7, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 8, "put", put, READINPUTSBOOLEAN);
    setupargs(initInputTable, 9, "q", q, READINPUTSDOUBLE);
    setupargs(initInputTable, 10, "r", r, READINPUTSDOUBLE);
    setupargs(initInputTable, 11, "Rebate", Rebate, READINPUTSDOUBLE);
    setupargs(initInputTable, 12, "Series", Series, READINPUTSINTEGER);
    setupargs(initInputTable, 13, "sigma", sigma, READINPUTSDOUBLE);
    setupargs(initInputTable, 14, "Spot", Spot, READINPUTSDOUBLE);
    setupargs(initInputTable, 15, "TMax", TMax, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,initInputTable,16)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    /* Read SampleDates from file */
    SciArray1<double>SampleDates(nsampToGo + 1);
    if (nsampToGo>=1)
        {
        openfilemcAsianBarrier1MR(IOUNIT2,"SampleDates.dat");
        for (itvar1=1; itvar1<=nsampToGo; itvar1++) {
            fscanfMmcAsianBarrier1M(IOUNIT2,"%lg",1,((&SampleDates(itvar1))));
        }
        fclose(IOUNIT2);
        }
    /*                            */
    /* Call the computation function. */
    mcAsianBarrier1fn(ASpot,Barrier,BarType,FirstBarDate,K,nsampSoFar,nsampToGo,pMax,put,q,r,Rebate,SampleDates,Series,
       sigma,Spot,TMax,Vx);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfilemcAsianBarrier1MW(IOUNIT,"V.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




