#ifndef MCASIANBARRIER1_H
#define MCASIANBARRIER1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcAsianBarrier1fn(
    double ASpot,
    double Barrier,
    int BarType,
    double FirstBarDate,
    double K,
    int nsampSoFar,
    int nsampToGo,
    int pMax,
    int put,
    double q,
    double r,
    double Rebate,
    const SciArray1<double>& SampleDates,
    int Series,
    double sigma,
    double Spot,
    double TMax,
    double & Vx
    );
     


#endif /* MCASIANBARRIER1_H */
