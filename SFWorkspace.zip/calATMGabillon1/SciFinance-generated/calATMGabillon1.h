#ifndef CALATMGABILLON1_H
#define CALATMGABILLON1_H

#include "SciStdIncludes.h"
#include "SciArrayN.h" /* SciComp arrays */

int calATMGabillon1fnC(
    double ***CalibOptsxC,
    double ftol,
    double **MarketFitxC,
    int nOpt,
    double **OptionMatrixC,
    double **ParamsxC,
    double *pGuessC,
    double *pMaxC,
    double *pMinC,
    double xtol,
    int *infox,
    int *nColx,
    int *nDx,
    int *nfevx,
    double *RMSFitx,
    int *tmpx
    );
     


#endif /* CALATMGABILLON1_H */
