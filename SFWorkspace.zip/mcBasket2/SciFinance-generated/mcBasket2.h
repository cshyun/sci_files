#ifndef MCBASKET2_H
#define MCBASKET2_H

#include "SciArrayN.h" /* SciComp arrays */

void mcBasket2fn(
    const SciArray1<double>& D0,
    double disc,
    double epsilon,
    double K,
    const SciArray1<double>& loan,
    int nD,
    int pMax,
    const SciArray2<double>& rho,
    int Series,
    const SciArray1<double>& sigma,
    const SciArray1<double>& Spot,
    double TMax,
    const SciArray1<double>& weight,
    SciArray1<double>& Deltax,
    SciArray1<double>& Gammax,
    double & Vx
    );
     


#endif /* MCBASKET2_H */
