

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for DZeroDates in file "DZeroCurve.dat" has maximum index
      nDCurve, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nDCurve elements,
      to be stored in DZeroDates(0..nDCurve).

   The table for DZeroRates in file "DZeroCurve.dat" has maximum index
      nDCurve, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nDCurve elements,
      to be stored in DZeroRates(0..nDCurve).

   The table for FZeroDates in file "FZeroCurve.dat" has maximum index
      nFCurve, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nFCurve elements,
      to be stored in FZeroDates(0..nFCurve).

   The table for FZeroRates in file "FZeroCurve.dat" has maximum index
      nFCurve, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nFCurve elements,
      to be stored in FZeroRates(0..nFCurve).

   The table for MonitorDates in file "MonitorDates.dat" has maximum index
      nMonDates, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nMonDates elements,
      to be stored in MonitorDates(1..nMonDates).

   The table for XMax in file "MonitorDates.dat" has maximum index
      nMonDates, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nMonDates elements,
      to be stored in XMax(1..nMonDates).

   The table for XMin in file "MonitorDates.dat" has maximum index
      nMonDates, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nMonDates elements,
      to be stored in XMin(1..nMonDates).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcDblHestonAccumulator1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcDblHestonAccumulator1MW
#define openfilemcDblHestonAccumulator1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcDblHestonAccumulator1MR
#define openfilemcDblHestonAccumulator1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcDblHestonAccumulator1M
#define fscanfMmcDblHestonAccumulator1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2

#undef spreadargs3
#define spreadargs3(a1,a2,a3) a1,a2,a3


int main()
{
    int count0,inRange0,itvar1,nDCurve,nFCurve,nMax,nMonDates,pMax,Series;
    double Deltax,Gammax,kappa1,kappa2,rho1,rho2,sigma1,sigma2,theta1,theta2,v10,v20,Vx,XSpot;
    ArgumentRecord initInputTable[20];
    int inner;
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4;
    
    /* *** Key to program variables: *** */
    /* count0, Deltax, DZeroDates, DZeroRates, FZeroDates, FZeroRates, Gammax, inner, inRange0, kappa1, kappa2,         
       MonitorDates, rho1, rho2, Series, sigma1, sigma2, theta1, theta2, v10, v20, XMax, XMin, XSpot: solution variable 
       */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4: I/O channel */
    /* nDCurve: array maximum for DZeroDates and DZeroRates */
    /* nFCurve: array maximum for FZeroDates and FZeroRates */
    /* nMax: number of grid cells for t */
    /* nMonDates: array maximum for MonitorDates, XMin and XMax */
    /* pMax: maximum for path */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcDblHestonAccumulator1MR(IOUNIT1,"init.dat");
    setupargs(initInputTable, 0, "count0", count0, READINPUTSINTEGER);
    setupargs(initInputTable, 1, "inner", inner, READINPUTSBOOLEAN);
    setupargs(initInputTable, 2, "inRange0", inRange0, READINPUTSINTEGER);
    setupargs(initInputTable, 3, "kappa1", kappa1, READINPUTSDOUBLE);
    setupargs(initInputTable, 4, "kappa2", kappa2, READINPUTSDOUBLE);
    setupargs(initInputTable, 5, "nDCurve", nDCurve, READINPUTSINTEGER);
    setupargs(initInputTable, 6, "nFCurve", nFCurve, READINPUTSINTEGER);
    setupargs(initInputTable, 7, "nMax", nMax, READINPUTSINTEGER);
    setupargs(initInputTable, 8, "nMonDates", nMonDates, READINPUTSINTEGER);
    setupargs(initInputTable, 9, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 10, "rho1", rho1, READINPUTSDOUBLE);
    setupargs(initInputTable, 11, "rho2", rho2, READINPUTSDOUBLE);
    setupargs(initInputTable, 12, "Series", Series, READINPUTSINTEGER);
    setupargs(initInputTable, 13, "sigma1", sigma1, READINPUTSDOUBLE);
    setupargs(initInputTable, 14, "sigma2", sigma2, READINPUTSDOUBLE);
    setupargs(initInputTable, 15, "theta1", theta1, READINPUTSDOUBLE);
    setupargs(initInputTable, 16, "theta2", theta2, READINPUTSDOUBLE);
    setupargs(initInputTable, 17, "v10", v10, READINPUTSDOUBLE);
    setupargs(initInputTable, 18, "v20", v20, READINPUTSDOUBLE);
    setupargs(initInputTable, 19, "XSpot", XSpot, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,initInputTable,20)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    SciArray1<double>DZeroDates(nDCurve + 1);
    SciArray1<double>DZeroRates(nDCurve + 1);
    /* Read DZeroDates from file. Read DZeroRates from file */
    if (nDCurve>=0)
        {
        openfilemcDblHestonAccumulator1MR(IOUNIT2,"DZeroCurve.dat");
        for (itvar1=0; itvar1<=nDCurve; itvar1++) {
            fscanfMmcDblHestonAccumulator1M(IOUNIT2,"%lg%lg",2,((&DZeroDates(itvar1)),(&DZeroRates(itvar1))));
        }
        fclose(IOUNIT2);
        }
    SciArray1<double>FZeroDates(nFCurve + 1);
    SciArray1<double>FZeroRates(nFCurve + 1);
    /* Read FZeroDates from file. Read FZeroRates from file */
    if (nFCurve>=0)
        {
        openfilemcDblHestonAccumulator1MR(IOUNIT3,"FZeroCurve.dat");
        for (itvar1=0; itvar1<=nFCurve; itvar1++) {
            fscanfMmcDblHestonAccumulator1M(IOUNIT3,"%lg%lg",2,((&FZeroDates(itvar1)),(&FZeroRates(itvar1))));
        }
        fclose(IOUNIT3);
        }
    SciArray1<double>MonitorDates(nMonDates + 1);
    SciArray1<double>XMin(nMonDates + 1);
    SciArray1<double>XMax(nMonDates + 1);
    /* Read MonitorDates from file. Read XMin from file. Read XMax from file */
    if (nMonDates>=1)
        {
        openfilemcDblHestonAccumulator1MR(IOUNIT4,"MonitorDates.dat");
        for (itvar1=1; itvar1<=nMonDates; itvar1++) {
            fscanfMmcDblHestonAccumulator1M(IOUNIT4,
               "%lg%lg%lg",3,((&MonitorDates(itvar1)),(&XMin(itvar1)),(&XMax(itvar1))));
        }
        fclose(IOUNIT4);
        }
    /*                            */
    /* Call the computation function. */
    mcDblHestonAccumulator1fn(count0,Deltax,DZeroDates,DZeroRates,FZeroDates,FZeroRates,Gammax,inner,inRange0,kappa1,
       kappa2,MonitorDates,nDCurve,nFCurve,nMax,nMonDates,pMax,rho1,rho2,Series,sigma1,sigma2,theta1,theta2,v10,v20,XMax
       ,XMin,XSpot,Vx);
    /*                            */
    /* Writing collected output to file Results.out from ResultEqc. */
    openfilemcDblHestonAccumulator1MW(IOUNIT,"Results.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file Results.out from ResultEq1c. */
    fprintf(IOUNIT, " %18.8e\n", Deltax);
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file Results.out from ResultEq2c. */
    fprintf(IOUNIT, " %18.8e\n", Gammax);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




