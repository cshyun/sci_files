#ifndef MCDBLHESTONACCUMULATOR1_H
#define MCDBLHESTONACCUMULATOR1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcDblHestonAccumulator1fn(
    int count0,
    double & Deltax,
    const SciArray1<double>& DZeroDates,
    const SciArray1<double>& DZeroRates,
    const SciArray1<double>& FZeroDates,
    const SciArray1<double>& FZeroRates,
    double & Gammax,
    int inner,
    int inRange0,
    double kappa1,
    double kappa2,
    const SciArray1<double>& MonitorDates,
    int nDCurve,
    int nFCurve,
    int nMax,
    int nMonDates,
    int pMax,
    double rho1,
    double rho2,
    int Series,
    double sigma1,
    double sigma2,
    double theta1,
    double theta2,
    double v10,
    double v20,
    const SciArray1<double>& XMax,
    const SciArray1<double>& XMin,
    double XSpot,
    double & Vx
    );
     


#endif /* MCDBLHESTONACCUMULATOR1_H */
