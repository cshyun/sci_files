#ifndef MCAMERMAX1_H
#define MCAMERMAX1_H

#include "SciArrayN.h" /* SciComp arrays */

void MCAmerMax1fn(
    int bestN,
    const SciArray1<double>& D0,
    double disc,
    double K,
    const SciArray1<double>& loan,
    int maxord1,
    int maxord2,
    int nD,
    int nexer,
    int pMax,
    int pMaxI,
    int put,
    const SciArray2<double>& rho,
    const SciArray1<double>& sigma,
    const SciArray1<double>& Spot,
    const SciArray1<double>& SpotI,
    int sskip,
    const SciArray1<double>& texer,
    double TMax,
    double & Ux,
    double & Vx
    );
     


#endif /* MCAMERMAX1_H */
