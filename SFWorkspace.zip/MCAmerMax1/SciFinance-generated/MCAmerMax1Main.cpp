

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for D0 in file "D0.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in D0(1..nD).

   The table for loan in file "loan.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in loan(1..nD).

   The table for rho in file "rho.dat" has maximum indices
      nD and nD, 
     with minimum indices 1, 1 respectively.
      The index bounds are not read from this file.
        Following should be the nD^2 elements,
      to be stored in rho(1..nD, 1..nD).
   The first index is the most slowly varying and 
      the last index is the most rapidly varying.

   The table for sigma in file "sigma.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in sigma(1..nD).

   The table for Spot in file "Spot.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in Spot(1..nD).

   The table for SpotI in file "SpotI.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in SpotI(1..nD).

   The table for texer in file "texer.dat" has maximum index
      nexer, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nexer elements,
      to be stored in texer(1..nexer).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "MCAmerMax1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfileMCAmerMax1MW
#define openfileMCAmerMax1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfileMCAmerMax1MR
#define openfileMCAmerMax1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMMCAmerMax1M
#define fscanfMMCAmerMax1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1


int main()
{
    int bestN,itvar1,itvar2,maxord1,maxord2,nD,nexer,pMax,pMaxI,sskip;
    double disc,K,TMax,Ux,Vx;
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4,*IOUNIT5,*IOUNIT6,*IOUNIT7,*IOUNIT8;
    ArgumentRecord MCAmerMaxInputTable[12];
    int put;
    
    /* *** Key to program variables: *** */
    /* bestN, D0, K, loan, maxord1, maxord2, put, rho, sigma, Spot, SpotI, sskip: solution variable */
    /* disc: discount rate */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5, IOUNIT6, IOUNIT7, IOUNIT8: I/O channel */
    /* nD: maximum for iv */
    /* nexer: array maximum for texer */
    /* pMax: maximum for path */
    /* pMaxI: maximum for pathI */
    /* texer: Sample array for Exercise */
    /* TMax: maximum time */
    /* Ux, Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfileMCAmerMax1MR(IOUNIT1,"MCAmerMax.dat");
    setupargs(MCAmerMaxInputTable, 0, "bestN", bestN, READINPUTSINTEGER);
    setupargs(MCAmerMaxInputTable, 1, "disc", disc, READINPUTSDOUBLE);
    setupargs(MCAmerMaxInputTable, 2, "K", K, READINPUTSDOUBLE);
    setupargs(MCAmerMaxInputTable, 3, "maxord1", maxord1, READINPUTSINTEGER);
    setupargs(MCAmerMaxInputTable, 4, "maxord2", maxord2, READINPUTSINTEGER);
    setupargs(MCAmerMaxInputTable, 5, "nD", nD, READINPUTSINTEGER);
    setupargs(MCAmerMaxInputTable, 6, "nexer", nexer, READINPUTSINTEGER);
    setupargs(MCAmerMaxInputTable, 7, "pMax", pMax, READINPUTSINTEGER);
    setupargs(MCAmerMaxInputTable, 8, "pMaxI", pMaxI, READINPUTSINTEGER);
    setupargs(MCAmerMaxInputTable, 9, "put", put, READINPUTSBOOLEAN);
    setupargs(MCAmerMaxInputTable, 10, "sskip", sskip, READINPUTSINTEGER);
    setupargs(MCAmerMaxInputTable, 11, "TMax", TMax, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,MCAmerMaxInputTable,12)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    SciArray1<double>D0(nD + 1);
    SciArray2<double>rho(nD + 1, nD + 1);
    SciArray1<double>sigma(nD + 1);
    SciArray1<double>Spot(nD + 1);
    SciArray1<double>SpotI(nD + 1);
    SciArray1<double>loan(nD + 1);
    if (nD>=1)
        {
        /* Read D0 from file */
        openfileMCAmerMax1MR(IOUNIT2,"D0.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMMCAmerMax1M(IOUNIT2,"%lg",1,((&D0(itvar1))));
        }
        fclose(IOUNIT2);
        /* Read rho from file */
        openfileMCAmerMax1MR(IOUNIT3,"rho.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            for (itvar2=1; itvar2<=nD; itvar2++) {
                fscanfMMCAmerMax1M(IOUNIT3,"%lg",1,((&rho(itvar1,itvar2))));
            }
        }
        fclose(IOUNIT3);
        /* Read sigma from file */
        openfileMCAmerMax1MR(IOUNIT4,"sigma.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMMCAmerMax1M(IOUNIT4,"%lg",1,((&sigma(itvar1))));
        }
        fclose(IOUNIT4);
        /* Read Spot from file */
        openfileMCAmerMax1MR(IOUNIT5,"Spot.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMMCAmerMax1M(IOUNIT5,"%lg",1,((&Spot(itvar1))));
        }
        fclose(IOUNIT5);
        /* Read SpotI from file */
        openfileMCAmerMax1MR(IOUNIT6,"SpotI.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMMCAmerMax1M(IOUNIT6,"%lg",1,((&SpotI(itvar1))));
        }
        fclose(IOUNIT6);
        /* Read loan from file */
        openfileMCAmerMax1MR(IOUNIT7,"loan.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMMCAmerMax1M(IOUNIT7,"%lg",1,((&loan(itvar1))));
        }
        fclose(IOUNIT7);
        }
    /* Read texer from file */
    SciArray1<double>texer(nexer + 1);
    if (nexer>=1)
        {
        openfileMCAmerMax1MR(IOUNIT8,"texer.dat");
        for (itvar1=1; itvar1<=nexer; itvar1++) {
            fscanfMMCAmerMax1M(IOUNIT8,"%lg",1,((&texer(itvar1))));
        }
        fclose(IOUNIT8);
        }
    /*                            */
    /* Call the computation function. */
    MCAmerMax1fn(bestN,D0,disc,K,loan,maxord1,maxord2,nD,nexer,pMax,pMaxI,put,rho,sigma,Spot,SpotI,sskip,texer,TMax,Ux,
       Vx);
    /*                            */
    /* Writing collected output to file atSpot.out from ResultEqc. */
    openfileMCAmerMax1MW(IOUNIT,"atSpot.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file atSpot.out from ResultEq1c. */
    fprintf(IOUNIT, " %18.8e\n", Ux);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




