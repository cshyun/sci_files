#ifndef MCBERMBASKET1_H
#define MCBERMBASKET1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcBermBasket1fn(
    double D01,
    double D02,
    double disc,
    double K,
    double loan1,
    double loan2,
    int maxord,
    int nExer,
    int pMax,
    int pMaxI,
    int put,
    double rho12,
    int Seed,
    int SeedI,
    double sigma1,
    double sigma2,
    double Spot1,
    double Spot1I,
    double Spot2,
    double Spot2I,
    double TMax,
    double w1,
    double w2,
    double & devx,
    double & Vx
    );
     


#endif /* MCBERMBASKET1_H */
