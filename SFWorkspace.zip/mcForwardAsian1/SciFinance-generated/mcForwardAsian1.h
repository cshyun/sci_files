#ifndef MCFORWARDASIAN1_H
#define MCFORWARDASIAN1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcForwardAsian1fn(
    double & Deltax,
    double epsilon,
    double k,
    int nsamp,
    int pMax,
    int put,
    double q,
    double r,
    int Series,
    double sigma,
    double Spot,
    double tfix,
    double TMax,
    const SciArray1<double>& tsamp,
    double & Vegax,
    double & Vx
    );
     


#endif /* MCFORWARDASIAN1_H */
