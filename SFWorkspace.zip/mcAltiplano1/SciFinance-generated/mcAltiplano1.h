#ifndef MCALTIPLANO1_H
#define MCALTIPLANO1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcAltiplano1fn(
    int cont,
    double Coupon,
    const SciArray1<double>& D0,
    double disc,
    double K,
    double Limit,
    const SciArray1<double>& loan,
    int nD,
    int nSample,
    int pMax,
    const SciArray2<double>& rho,
    const SciArray1<double>& S0,
    int Series,
    const SciArray1<double>& sigma,
    const SciArray1<double>& Spot,
    double tEnd,
    double TMax,
    double tStart,
    double & Vx
    );
     


#endif /* MCALTIPLANO1_H */
