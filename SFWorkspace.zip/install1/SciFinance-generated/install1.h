#ifndef INSTALL1_H
#define INSTALL1_H

#include "SciArrayN.h" /* SciComp arrays */

void install1fn(
    double D0,
    const SciArray1<double>& divamount1,
    int iMax,
    int inst,
    double K,
    const SciArray1<double>& L,
    int ninst,
    int nMax,
    int nspot,
    int numdiv,
    double phi,
    int put,
    double r,
    double sigma,
    double SMax,
    SciArray1<double>& spottable,
    const SciArray1<double>& tdiv1,
    double TMax,
    const SciArray1<double>& tsample1,
    SciArray1<double>& atSpotx,
    SciArray1<double>& atSpot1x,
    SciArray1<double>& atSpot2x,
    SciArray1<double>& atSpot3x,
    SciArray1<double>& atSpot4x,
    SciArray1<double>& atSpot5x
    );
     


#endif /* INSTALL1_H */
