/*** Key to program variables: ***
  D0: continuous dividend yield; an input
  divamount1: solution variable; an input
  iMax: number of grid cells for S; an input
  inst: solution variable; an input
  K: solution variable; an input
  L: solution variable; an input
  ninst: array maximum for L and tsample1; an input
  nMax: number of grid cells for t; an input
  nspot: array maximum for spottable; an input
  numdiv: array maximum for divamount1 and tdiv1; an input
  phi: solution variable; an input
  put: solution variable; an input
  r: interest rate; an input
  sigma: volatility; an input
  SMax: maximum physical value in dimension S; an input
  spottable: solution variable; an input
  tdiv1: Sample array for DividendAtEnd; an input
  TMax: minimum physical value in dimension t; an input
  tsample1: Sample array for Exercise; an input
  atSpotx: solution variable; an output
  atSpot1x: solution variable; an output
  atSpot2x: solution variable; an output
  atSpot3x: solution variable; an output
  atSpot4x: solution variable; an output
  atSpot5x: solution variable; an output
*** end Key to program variables: ***/


/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for divamount1 in file "tdiv.dat" has maximum index
      numdiv, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the numdiv elements,
      to be stored in divamount1(1..numdiv).

   The table for L in file "tinst.dat" has maximum index
      ninst, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the ninst elements,
      to be stored in L(1..ninst).

   The table for spottable in file "spot.dat" has maximum index
      nspot, 
     with minimum index 0.
         nspot should be on line 1 of the file.
   Following should be the 1 + nspot elements,
      to be stored in spottable(0..nspot).

   The table for tdiv1 in file "tdiv.dat" has maximum index
      numdiv, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the numdiv elements,
      to be stored in tdiv1(1..numdiv).

   The table for tsample1 in file "tinst.dat" has maximum index
      ninst, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the ninst elements,
      to be stored in tsample1(1..ninst).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "install1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfileinstall1MW
#define openfileinstall1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfileinstall1MR
#define openfileinstall1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMinstall1M
#define fscanfMinstall1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2


int main()
{
    int d,iMax,itvar1,ninst,nMax,nspot,numdiv;
    double D0,K,phi,r,sigma,SMax,TMax;
    int inst,put;
    ArgumentRecord instalInputTable[13];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4;
    
    /* *** Key to program variables: *** */
    /* atSpot: interpolated value of atSpot (option value)  */
    /* atSpot1: interpolated value of atSpot1 (Vega)  */
    /* atSpot2: interpolated value of atSpot2 (Rho)  */
    /* atSpot3: interpolated value of atSpot3 (option value)  */
    /* atSpot4: interpolated value of atSpot4 (option value)  */
    /* atSpot5: interpolated value of atSpot5 (option value)  */
    /* d: index variable for spottable */
    /* D0: continuous dividend yield */
    /* divamount1, inst, K, L, phi, put, spottable: solution variable */
    /* iMax: number of grid cells for S */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4: I/O channel */
    /* ninst: array maximum for L and tsample1 */
    /* nMax: number of grid cells for t */
    /* nspot: array maximum for spottable */
    /* numdiv: array maximum for divamount1 and tdiv1 */
    /* r: interest rate */
    /* sigma: volatility */
    /* SMax: maximum physical value in dimension S */
    /* tdiv1: Sample array for DividendAtEnd */
    /* TMax: minimum physical value in dimension t */
    /* tsample1: Sample array for Exercise */
    try {
    /* Read Tagged Input File */
    openfileinstall1MR(IOUNIT1,"instal.dat");
    setupargs(instalInputTable, 0, "D0", D0, READINPUTSDOUBLE);
    setupargs(instalInputTable, 1, "iMax", iMax, READINPUTSINTEGER);
    setupargs(instalInputTable, 2, "inst", inst, READINPUTSBOOLEAN);
    setupargs(instalInputTable, 3, "K", K, READINPUTSDOUBLE);
    setupargs(instalInputTable, 4, "ninst", ninst, READINPUTSINTEGER);
    setupargs(instalInputTable, 5, "nMax", nMax, READINPUTSINTEGER);
    setupargs(instalInputTable, 6, "numdiv", numdiv, READINPUTSINTEGER);
    setupargs(instalInputTable, 7, "phi", phi, READINPUTSDOUBLE);
    setupargs(instalInputTable, 8, "put", put, READINPUTSBOOLEAN);
    setupargs(instalInputTable, 9, "r", r, READINPUTSDOUBLE);
    setupargs(instalInputTable, 10, "sigma", sigma, READINPUTSDOUBLE);
    setupargs(instalInputTable, 11, "SMax", SMax, READINPUTSDOUBLE);
    setupargs(instalInputTable, 12, "TMax", TMax, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,instalInputTable,13)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    /* Read spottable from file */
    openfileinstall1MR(IOUNIT2,"spot.dat");
    fscanfMinstall1M(IOUNIT2,"%i",1,((&nspot)));
    SciArray1<double>spottable(nspot + 1);
    if (nspot>=0)
        {
        for (itvar1=0; itvar1<=nspot; itvar1++) {
            fscanfMinstall1M(IOUNIT2,"%lg",1,((&spottable(itvar1))));
        }
        }
    fclose(IOUNIT2);
    SciArray1<double>divamount1(numdiv + 1);
    SciArray1<double>tdiv1(numdiv + 1);
    /* Read divamount1 from file. Read tdiv1 from file */
    if (numdiv>=1)
        {
        openfileinstall1MR(IOUNIT3,"tdiv.dat");
        for (itvar1=1; itvar1<=numdiv; itvar1++) {
            fscanfMinstall1M(IOUNIT3,"%lg%lg",2,((&divamount1(itvar1)),(&tdiv1(itvar1))));
        }
        fclose(IOUNIT3);
        }
    SciArray1<double>L(ninst + 1);
    SciArray1<double>tsample1(ninst + 1);
    /* Read L from file. Read tsample1 from file */
    if (ninst>=1)
        {
        openfileinstall1MR(IOUNIT4,"tinst.dat");
        for (itvar1=1; itvar1<=ninst; itvar1++) {
            fscanfMinstall1M(IOUNIT4,"%lg%lg",2,((&L(itvar1)),(&tsample1(itvar1))));
        }
        fclose(IOUNIT4);
        }
    /*                            */
    /* Call the computation function. */
    SciArray1<double> atSpot;
    SciArray1<double> atSpot1;
    SciArray1<double> atSpot2;
    SciArray1<double> atSpot3;
    SciArray1<double> atSpot4;
    SciArray1<double> atSpot5;
    install1fn(D0,divamount1,iMax,inst,K,L,ninst,nMax,nspot,numdiv,phi,put,r,sigma,SMax,spottable,tdiv1,TMax,tsample1,
       atSpot,atSpot1,atSpot2,atSpot3,atSpot4,atSpot5);
    /*                            */
    /* Writing collected output to file atSpot.out from ResultEqc. */
    openfileinstall1MW(IOUNIT,"atSpot.out");
    for (d=0; d<=(int)atSpot.size0() - 1; d++) {
        fprintf(IOUNIT, " %18.8e\n", atSpot(d));
    }
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file atSpot.out from ResultEq1c. */
    for (d=0; d<=(int)atSpot1.size0() - 1; d++) {
        fprintf(IOUNIT, " %18.8e\n", atSpot1(d));
    }
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file atSpot.out from ResultEq2c. */
    for (d=0; d<=(int)atSpot2.size0() - 1; d++) {
        fprintf(IOUNIT, " %18.8e\n", atSpot2(d));
    }
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file atSpot.out from ResultEq3c. */
    for (d=0; d<=(int)atSpot3.size0() - 1; d++) {
        fprintf(IOUNIT, " %18.8e\n", atSpot3(d));
    }
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file atSpot.out from ResultEq4c. */
    for (d=0; d<=(int)atSpot4.size0() - 1; d++) {
        fprintf(IOUNIT, " %18.8e\n", atSpot4(d));
    }
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file atSpot.out from ResultEq5c. */
    for (d=0; d<=(int)atSpot5.size0() - 1; d++) {
        fprintf(IOUNIT, " %18.8e\n", atSpot5(d));
    }
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




