#ifndef MCAVERATE3_H
#define MCAVERATE3_H

#include "SciArrayN.h" /* SciComp arrays */

void mcAveRate3fn(
    double K,
    int nsamp,
    int pMax,
    int put,
    double q,
    double r,
    int Series,
    double sigma,
    double Spot,
    double TMax,
    double & Vx
    );
     


#endif /* MCAVERATE3_H */
