#ifndef MCBESTWORST1_H
#define MCBESTWORST1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcBestWorst1fn(
    int Best,
    const SciArray1<int>& calcGreeks,
    double disc,
    double K,
    const SciArray1<double>& loan,
    int nD,
    int pMax,
    const SciArray1<double>& q,
    const SciArray2<double>& rho,
    double Sbump,
    int Series,
    const SciArray1<double>& sigma,
    const SciArray1<double>& Spot,
    double TMax,
    const SciArray1<double>& W,
    SciArray1<double>& Deltax,
    SciArray1<double>& Gammax,
    double & Vx
    );
     


#endif /* MCBESTWORST1_H */
