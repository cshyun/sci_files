



#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcExactCir1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcExactCir1MW
#define openfilemcExactCir1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcExactCir1MR
#define openfilemcExactCir1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcExactCir1M
#define fscanfMmcExactCir1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }



int main()
{
    int nMax,pMax,Seed;
    double devx,kappa,rSpot,sigma,theta,TMax,Vx;
    ArgumentRecord initInputTable[8];
    FILE *IOUNIT,*IOUNIT1;
    
    /* *** Key to program variables: *** */
    /* devx: standard deviation error estimate */
    /* IOUNIT, IOUNIT1: I/O channel */
    /* kappa, rSpot, Seed, sigma, theta: solution variable */
    /* nMax: number of grid cells for t */
    /* pMax: maximum for path */
    /* TMax: maximum time */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcExactCir1MR(IOUNIT1,"init.dat");
    setupargs(initInputTable, 0, "kappa", kappa, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "nMax", nMax, READINPUTSINTEGER);
    setupargs(initInputTable, 2, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 3, "rSpot", rSpot, READINPUTSDOUBLE);
    setupargs(initInputTable, 4, "Seed", Seed, READINPUTSINTEGER);
    setupargs(initInputTable, 5, "sigma", sigma, READINPUTSDOUBLE);
    setupargs(initInputTable, 6, "theta", theta, READINPUTSDOUBLE);
    setupargs(initInputTable, 7, "TMax", TMax, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,initInputTable,8)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    /*                            */
    /* Call the computation function. */
    mcExactCir1fn(kappa,nMax,pMax,rSpot,Seed,sigma,theta,TMax,devx,Vx);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfilemcExactCir1MW(IOUNIT,"V.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file V.out from ResultEq1c. */
    fprintf(IOUNIT, " %18.8e\n", devx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




