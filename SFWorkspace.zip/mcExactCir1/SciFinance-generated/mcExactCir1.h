#ifndef MCEXACTCIR1_H
#define MCEXACTCIR1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcExactCir1fn(
    double kappa,
    int nMax,
    int pMax,
    double rSpot,
    int Seed,
    double sigma,
    double theta,
    double TMax,
    double & devx,
    double & Vx
    );
     


#endif /* MCEXACTCIR1_H */
