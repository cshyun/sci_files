#ifndef MCCOMPOUNDASIAN1_H
#define MCCOMPOUNDASIAN1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcCompoundAsian1fn(
    int callC,
    int callU,
    double KC,
    double KU,
    int maxord,
    int nsamp,
    int pMax,
    int pMaxI,
    double q,
    double r,
    int Series,
    double sigma,
    double Spot,
    double SpotI,
    double T1,
    double TMax,
    const SciArray1<double>& tsamp,
    double & VCx,
    double & VUx
    );
     


#endif /* MCCOMPOUNDASIAN1_H */
