

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for tsamp in file "AsamplingTime.dat" has maximum index
      nsamp, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nsamp elements,
      to be stored in tsamp(1..nsamp).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcCompoundAsian1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcCompoundAsian1MW
#define openfilemcCompoundAsian1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcCompoundAsian1MR
#define openfilemcCompoundAsian1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcCompoundAsian1M
#define fscanfMmcCompoundAsian1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1


int main()
{
    int itvar1,maxord,nsamp,pMax,pMaxI,Series;
    int callC,callU;
    ArgumentRecord initInputTable[16];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3;
    double KC,KU,q,r,sigma,Spot,SpotI,T1,TMax,VCx,VUx;
    
    /* *** Key to program variables: *** */
    /* callC, callU, KC, KU, maxord, q, Series, sigma, Spot, SpotI, T1: solution variable */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3: I/O channel */
    /* nsamp: array maximum for tsamp */
    /* pMax: maximum for path */
    /* pMaxI: maximum for pathI */
    /* r: discount rate */
    /* TMax: maximum time */
    /* tsamp: Sample array for Path */
    /* VCx, VUx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcCompoundAsian1MR(IOUNIT2,"init.dat");
    setupargs(initInputTable, 0, "callC", callC, READINPUTSBOOLEAN);
    setupargs(initInputTable, 1, "callU", callU, READINPUTSBOOLEAN);
    setupargs(initInputTable, 2, "KC", KC, READINPUTSDOUBLE);
    setupargs(initInputTable, 3, "KU", KU, READINPUTSDOUBLE);
    setupargs(initInputTable, 4, "maxord", maxord, READINPUTSINTEGER);
    setupargs(initInputTable, 5, "nsamp", nsamp, READINPUTSINTEGER);
    setupargs(initInputTable, 6, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 7, "pMaxI", pMaxI, READINPUTSINTEGER);
    setupargs(initInputTable, 8, "q", q, READINPUTSDOUBLE);
    setupargs(initInputTable, 9, "r", r, READINPUTSDOUBLE);
    setupargs(initInputTable, 10, "Series", Series, READINPUTSINTEGER);
    setupargs(initInputTable, 11, "sigma", sigma, READINPUTSDOUBLE);
    setupargs(initInputTable, 12, "Spot", Spot, READINPUTSDOUBLE);
    setupargs(initInputTable, 13, "SpotI", SpotI, READINPUTSDOUBLE);
    setupargs(initInputTable, 14, "T1", T1, READINPUTSDOUBLE);
    setupargs(initInputTable, 15, "TMax", TMax, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT2,initInputTable,16)!=0)
        {
        fclose(IOUNIT2);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT2);
    /* Read tsamp from file */
    SciArray1<double>tsamp(nsamp + 1);
    if (nsamp>=1)
        {
        openfilemcCompoundAsian1MR(IOUNIT3,"AsamplingTime.dat");
        for (itvar1=1; itvar1<=nsamp; itvar1++) {
            fscanfMmcCompoundAsian1M(IOUNIT3,"%lg",1,((&tsamp(itvar1))));
        }
        fclose(IOUNIT3);
        }
    /*                            */
    /* Call the computation function. */
    mcCompoundAsian1fn(callC,callU,KC,KU,maxord,nsamp,pMax,pMaxI,q,r,Series,sigma,Spot,SpotI,T1,TMax,tsamp,VCx,VUx);
    /*                            */
    /* Writing collected output to file VU.out from ResultEqc. */
    openfilemcCompoundAsian1MW(IOUNIT,"VU.out");
    fprintf(IOUNIT, " %18.8e\n", VUx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* Writing collected output to file VC.out from ResultEq1c. */
    openfilemcCompoundAsian1MW(IOUNIT1,"VC.out");
    fprintf(IOUNIT1, " %18.8e\n", VCx);
    fprintf(IOUNIT1, "\n");
    fclose(IOUNIT1);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




