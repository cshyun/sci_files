#ifndef MCCLO_H
#define MCCLO_H

#include "SciArrayN.h" /* SciComp arrays */

void mcCLOfn(
    int alpha,
    const SciArray1<int>& Amrt,
    const SciArray1<double>& Cap,
    const SciArray2<double>& CopR,
    const SciArray1<double>& Cp,
    const SciArray1<double>& CPR,
    const SciArray1<int>& DefInit,
    const SciArray1<int>& DSwitch,
    const SciArray1<double>& FInit,
    const SciArray1<double>& Flr,
    const SciArray1<double>& Frq,
    double greekFD,
    const SciArray1<double>& h,
    const SciArray1<double>& ICT,
    int leap,
    const SciArray1<double>& Load,
    int nCoupTot,
    int nD,
    const SciArray1<int>& nPrdsTot,
    int nT,
    int nZ,
    const SciArray1<double>& OCT,
    const SciArray1<double>& Par,
    const SciArray1<double>& PerCap,
    int pMax,
    const SciArray1<double>& PurchPrice,
    double r,
    const SciArray1<double>& r0,
    const SciArray1<double>& Spread,
    int sskip,
    double StartDate,
    const SciArray1<double>& TCurve,
    const SciArray1<double>& ZCurve,
    SciArray2<double>& Deltax,
    SciArray2<double>& FMcAvex,
    SciArray2<double>& IPayMcAvex,
    SciArray1<double>& Notex,
    SciArray2<double>& PPayMcAvex,
    SciArray1<double>& TotLossMcAvex
    );
     


#endif /* MCCLO_H */
