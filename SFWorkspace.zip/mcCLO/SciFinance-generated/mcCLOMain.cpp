

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for Amrt in file "LoanData.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in Amrt(1..nD).

   The table for Cap in file "LoanData.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in Cap(1..nD).

   The table for CopR in file "CopR.dat" has maximum indices
      nD and nD, 
     with minimum indices 1, 1 respectively.
      The index bounds are not read from this file.
        Following should be the nD^2 elements,
      to be stored in CopR(1..nD, 1..nD).
   The first index is the most slowly varying and 
      the last index is the most rapidly varying.

   The table for Cp in file "NoteData.dat" has maximum index
      nT, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nT elements,
      to be stored in Cp(1..nT).

   The table for CPR in file "LoanData.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in CPR(1..nD).

   The table for DefInit in file "DefInit.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in DefInit(1..nD).

   The table for DSwitch in file "DSwitch.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in DSwitch(1..nD).

   The table for FInit in file "FInit.dat" has maximum index
      nT, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nT elements,
      to be stored in FInit(1..nT).

   The table for Flr in file "LoanData.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in Flr(1..nD).

   The table for Frq in file "LoanData.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in Frq(1..nD).

   The table for h in file "hCurves.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in h(1..nD).

   The table for ICT in file "NoteData.dat" has maximum index
      nT, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nT elements,
      to be stored in ICT(1..nT).

   The table for Load in file "NoteData.dat" has maximum index
      nT, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nT elements,
      to be stored in Load(1..nT).

   The table for nPrdsTot in file "LoanData.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in nPrdsTot(1..nD).

   The table for OCT in file "NoteData.dat" has maximum index
      nT, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nT elements,
      to be stored in OCT(1..nT).

   The table for Par in file "LoanData.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in Par(1..nD).

   The table for PerCap in file "LoanData.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in PerCap(1..nD).

   The table for PurchPrice in file "LoanData.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in PurchPrice(1..nD).

   The table for r0 in file "r0.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in r0(1..nD).

   The table for Spread in file "LoanData.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in Spread(1..nD).

   The table for TCurve in file "ZCurve.dat" has maximum index
      nZ, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nZ elements,
      to be stored in TCurve(1..nZ).

   The table for ZCurve in file "ZCurve.dat" has maximum index
      nZ, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nZ elements,
      to be stored in ZCurve(1..nZ).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcCLO.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcCLOMW
#define openfilemcCLOMW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcCLOMR
#define openfilemcCLOMR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcCLOM
#define fscanfMmcCLOM(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2

#undef spreadargs4
#define spreadargs4(a1,a2,a3,a4) a1,a2,a3,a4

#undef spreadargs10
#define spreadargs10(a1,a2,a3,a4,a5,a6,a7,a8,a9,a10) a1,a2,a3,a4,a5,a6,a7,a8,a9,a10


int main()
{
    int alpha,i,iCoup,iT,iT1,itvar1,itvar2,leap,nCoupTot,nD,nT,nZ,pMax,sskip;
    double greekFD,r,StartDate;
    ArgumentRecord initInputTable[11];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT10,*IOUNIT11,*IOUNIT12,*IOUNIT13,*IOUNIT14,*IOUNIT15,*IOUNIT2,*IOUNIT3,*IOUNIT4,*
       IOUNIT5,*IOUNIT6,*IOUNIT7,*IOUNIT8,*IOUNIT9;
    
    /* *** Key to program variables: *** */
    /* alpha, Amrt, Cap, CopR, Cp, CPR, DefInit, Delta, DSwitch, FInit, Flr, Frq, greekFD, h, ICT, leap, Load, nCoupTot,
       nPrdsTot, OCT, Par, PerCap, PurchPrice, r, r0, Spread, sskip, StartDate, TCurve, ZCurve: solution variable */
    /* FMcAve: McAve value for F */
    /* i: index variable for h */
    /* iCoup: index variable for DiscFactor */
    /* IOUNIT, IOUNIT1, IOUNIT10, IOUNIT11, IOUNIT12, IOUNIT13, IOUNIT14, IOUNIT15, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5, 
       IOUNIT6, IOUNIT7, IOUNIT8, IOUNIT9: I/O channel */
    /* IPayMcAve: McAve value for IPay */
    /* iT: index variable for FInit */
    /* iT1: vector index */
    /* nD: array maximum for h, CopR, r0, DefInit, Par, CPR, PurchPrice, Amrt, Frq, nPrdsTot, Flr, Cap, PerCap, Spread  
       and DSwitch */
    /* Note: discounted value */
    /* nT: array maximum for FInit, Cp, Load, OCT and ICT */
    /* nZ: array maximum for ZCurve and TCurve */
    /* pMax: maximum for path */
    /* PPayMcAve: McAve value for PPay */
    /* TotLossMcAve: McAve value for TotLoss */
    try {
    /* Read Tagged Input File */
    openfilemcCLOMR(IOUNIT6,"init.dat");
    setupargs(initInputTable, 0, "alpha", alpha, READINPUTSINTEGER);
    setupargs(initInputTable, 1, "greekFD", greekFD, READINPUTSDOUBLE);
    setupargs(initInputTable, 2, "leap", leap, READINPUTSINTEGER);
    setupargs(initInputTable, 3, "nCoupTot", nCoupTot, READINPUTSINTEGER);
    setupargs(initInputTable, 4, "nD", nD, READINPUTSINTEGER);
    setupargs(initInputTable, 5, "nT", nT, READINPUTSINTEGER);
    setupargs(initInputTable, 6, "nZ", nZ, READINPUTSINTEGER);
    setupargs(initInputTable, 7, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 8, "r", r, READINPUTSDOUBLE);
    setupargs(initInputTable, 9, "sskip", sskip, READINPUTSINTEGER);
    setupargs(initInputTable, 10, "StartDate", StartDate, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT6,initInputTable,11)!=0)
        {
        fclose(IOUNIT6);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT6);
    SciArray2<double>CopR(nD + 1, nD + 1);
    SciArray1<int>DSwitch(nD + 1);
    SciArray1<double>h(nD + 1);
    SciArray1<double>Par(nD + 1);
    SciArray1<double>CPR(nD + 1);
    SciArray1<double>PurchPrice(nD + 1);
    SciArray1<int>Amrt(nD + 1);
    SciArray1<double>Frq(nD + 1);
    SciArray1<int>nPrdsTot(nD + 1);
    SciArray1<double>Flr(nD + 1);
    SciArray1<double>Cap(nD + 1);
    SciArray1<double>PerCap(nD + 1);
    SciArray1<double>Spread(nD + 1);
    SciArray1<double>r0(nD + 1);
    SciArray1<int>DefInit(nD + 1);
    if (nD>=1)
        {
        /* Read CopR from file */
        openfilemcCLOMR(IOUNIT7,"CopR.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            for (itvar2=1; itvar2<=nD; itvar2++) {
                fscanfMmcCLOM(IOUNIT7,"%lg",1,((&CopR(itvar1,itvar2))));
            }
        }
        fclose(IOUNIT7);
        /* Read DSwitch from file */
        openfilemcCLOMR(IOUNIT8,"DSwitch.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCLOM(IOUNIT8,"%i",1,((&DSwitch(itvar1))));
        }
        fclose(IOUNIT8);
        /* Read h from file */
        openfilemcCLOMR(IOUNIT9,"hCurves.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCLOM(IOUNIT9,"%lg",1,((&h(itvar1))));
        }
        fclose(IOUNIT9);
        /* Read Par from file. Read CPR from file. Read PurchPrice from file. Read Amrt from file. Read Frq from file.  
           Read nPrdsTot from file. Read Flr from file. Read Cap from file. Read PerCap from file. Read Spread from file
           */
        openfilemcCLOMR(IOUNIT10,"LoanData.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCLOM(IOUNIT10,
               "%lg%lg%lg%i%lg%i%lg%lg%lg%lg"
               ,10,((&Par(itvar1)),(&CPR(itvar1)),(&PurchPrice(itvar1)),(&Amrt(itvar1)),(&Frq(itvar1)),(&nPrdsTot(itvar1
               )),(&Flr(itvar1)),(&Cap(itvar1)),(&PerCap(itvar1)),(&Spread(itvar1))));
        }
        fclose(IOUNIT10);
        /* Read r0 from file */
        openfilemcCLOMR(IOUNIT11,"r0.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCLOM(IOUNIT11,"%lg",1,((&r0(itvar1))));
        }
        fclose(IOUNIT11);
        /* Read DefInit from file */
        openfilemcCLOMR(IOUNIT12,"DefInit.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCLOM(IOUNIT12,"%i",1,((&DefInit(itvar1))));
        }
        fclose(IOUNIT12);
        }
    SciArray1<double>FInit(nT + 1);
    SciArray1<double>Cp(nT + 1);
    SciArray1<double>Load(nT + 1);
    SciArray1<double>OCT(nT + 1);
    SciArray1<double>ICT(nT + 1);
    if (nT>=1)
        {
        /* Read FInit from file */
        openfilemcCLOMR(IOUNIT13,"FInit.dat");
        for (itvar1=1; itvar1<=nT; itvar1++) {
            fscanfMmcCLOM(IOUNIT13,"%lg",1,((&FInit(itvar1))));
        }
        fclose(IOUNIT13);
        /* Read Cp from file. Read Load from file. Read OCT from file. Read ICT from file */
        openfilemcCLOMR(IOUNIT14,"NoteData.dat");
        for (itvar1=1; itvar1<=nT; itvar1++) {
            fscanfMmcCLOM(IOUNIT14,"%lg%lg%lg%lg",4,((&Cp(itvar1)),(&Load(itvar1)),(&OCT(itvar1)),(&ICT(itvar1))));
        }
        fclose(IOUNIT14);
        }
    SciArray1<double>ZCurve(nZ + 1);
    SciArray1<double>TCurve(nZ + 1);
    /* Read ZCurve from file. Read TCurve from file */
    if (nZ>=1)
        {
        openfilemcCLOMR(IOUNIT15,"ZCurve.dat");
        for (itvar1=1; itvar1<=nZ; itvar1++) {
            fscanfMmcCLOM(IOUNIT15,"%lg%lg",2,((&ZCurve(itvar1)),(&TCurve(itvar1))));
        }
        fclose(IOUNIT15);
        }
    /*                            */
    /* Call the computation function. */
    SciArray2<double> Delta;
    SciArray2<double> FMcAve;
    SciArray2<double> IPayMcAve;
    SciArray1<double> Note;
    SciArray2<double> PPayMcAve;
    SciArray1<double> TotLossMcAve;
    mcCLOfn(alpha,Amrt,Cap,CopR,Cp,CPR,DefInit,DSwitch,FInit,Flr,Frq,greekFD,h,ICT,leap,Load,nCoupTot,nD,nPrdsTot,nT,nZ,
       OCT,Par,PerCap,pMax,PurchPrice,r,r0,Spread,sskip,StartDate,TCurve,ZCurve,Delta,FMcAve,IPayMcAve,Note,PPayMcAve,
       TotLossMcAve);
    /*                            */
    /* Writing collected output to file Note.out from ResultEqc. */
    openfilemcCLOMW(IOUNIT,"Note.out");
    for (iT1=1; iT1<=(int)Note.size0() - 1; iT1++) {
        fprintf(IOUNIT, " %18.8e\n", Note(iT1));
    }
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* Writing collected output to file Delta.out from ResultEq1c. */
    openfilemcCLOMW(IOUNIT1,"Delta.out");
    for (i=1; i<=(int)Delta.size0() - 1; i++) {
        for (iT1=1; iT1<=(int)Delta.size1() - 1; iT1++) {
            fprintf(IOUNIT1, " %18.8e\n", Delta(i,iT1));
        }
    }
    fprintf(IOUNIT1, "\n");
    fclose(IOUNIT1);
    /* Writing collected output to file TotLossMcAve.out from ResultEq2c. */
    openfilemcCLOMW(IOUNIT2,"TotLossMcAve.out");
    for (iCoup=1; iCoup<=(int)TotLossMcAve.size0() - 1; iCoup++) {
        fprintf(IOUNIT2, " %18.8e\n", TotLossMcAve(iCoup));
    }
    fprintf(IOUNIT2, "\n");
    fclose(IOUNIT2);
    /* Writing collected output to file IPayMcAve.out from ResultEq3c. */
    openfilemcCLOMW(IOUNIT3,"IPayMcAve.out");
    for (iT=1; iT<=(int)IPayMcAve.size0() - 1; iT++) {
        for (iCoup=1; iCoup<=(int)IPayMcAve.size1() - 1; iCoup++) {
            fprintf(IOUNIT3, " %18.8e\n", IPayMcAve(iT,iCoup));
        }
    }
    fprintf(IOUNIT3, "\n");
    fclose(IOUNIT3);
    /* Writing collected output to file PPayMcAve.out from ResultEq4c. */
    openfilemcCLOMW(IOUNIT4,"PPayMcAve.out");
    for (iT=1; iT<=(int)PPayMcAve.size0() - 1; iT++) {
        for (iCoup=1; iCoup<=(int)PPayMcAve.size1() - 1; iCoup++) {
            fprintf(IOUNIT4, " %18.8e\n", PPayMcAve(iT,iCoup));
        }
    }
    fprintf(IOUNIT4, "\n");
    fclose(IOUNIT4);
    /* Writing collected output to file FMcAve.out from ResultEq5c. */
    openfilemcCLOMW(IOUNIT5,"FMcAve.out");
    for (iT=1; iT<=(int)FMcAve.size0() - 1; iT++) {
        for (iCoup=1; iCoup<=(int)FMcAve.size1() - 1; iCoup++) {
            fprintf(IOUNIT5, " %18.8e\n", FMcAve(iT,iCoup));
        }
    }
    fprintf(IOUNIT5, "\n");
    fclose(IOUNIT5);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




