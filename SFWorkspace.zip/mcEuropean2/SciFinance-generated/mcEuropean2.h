#ifndef MCEUROPEAN2_H
#define MCEUROPEAN2_H

#include "SciArrayN.h" /* SciComp arrays */

void mcEuropean2fn(
    double K,
    int pMax,
    int put,
    double q,
    double r,
    int Series,
    double sigma,
    double Spot,
    double TMax,
    double & Vx
    );
     


#endif /* MCEUROPEAN2_H */
