#ifndef MCBARBASKET2_H
#define MCBARBASKET2_H

#include "SciArrayN.h" /* SciComp arrays */

void mcBarBasket2fn(
    const SciArray1<double>& Bar,
    const SciArray1<double>& D0,
    double disc,
    double K,
    const SciArray1<double>& loan,
    int nD,
    int nsamp,
    int pMax,
    double Rebate,
    const SciArray2<double>& rho,
    int Series,
    const SciArray1<double>& sigma,
    const SciArray1<double>& Spot,
    double TMax,
    const SciArray1<double>& tsamp,
    int up,
    const SciArray1<double>& weight,
    double & Vx
    );
     


#endif /* MCBARBASKET2_H */
