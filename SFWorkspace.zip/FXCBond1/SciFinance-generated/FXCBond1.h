#ifndef FXCBOND1_H
#define FXCBOND1_H

#include "SciArrayN.h" /* SciComp arrays */

void FXCBond1fn(
    double Accuracy,
    double callPrice,
    const SciArray1<double>& coupTab,
    const SciArray1<double>& couptTab,
    double CR,
    double D0,
    const SciArray1<double>& divAmounts,
    const SciArray1<double>& divTimes,
    int iMax,
    int ncoup,
    int nMax,
    int nput,
    int numdiv,
    double parValue,
    const SciArray1<double>& putTab,
    const SciArray1<double>& puttTab,
    double rdfree,
    double rho,
    double sigmaS,
    double sigmaX,
    double SMax,
    double SMin,
    double Spot,
    double spread,
    double tcallStart,
    double TMax,
    double tolSOR,
    double XSpot,
    double & atSpot1x,
    double & atSpot11x,
    double & atSpot2x,
    SciArray1<double>& Sx,
    SciArray1<double>& Vx
    );
     


#endif /* FXCBOND1_H */
