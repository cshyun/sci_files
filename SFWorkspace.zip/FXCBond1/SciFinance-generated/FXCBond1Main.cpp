/*** Key to program variables: ***
  Accuracy: solution variable; an input
  callPrice: solution variable; an input
  coupTab: solution variable; an input
  couptTab: Sample array for Exercise; an input
  CR: solution variable; an input
  D0: continuous dividend yield; an input
  divAmounts: solution variable; an input
  divTimes: Sample array for DividendAtEnd; an input
  iMax: number of grid cells for x; an input
  ncoup: array maximum for coupTab and couptTab; an input
  nMax: number of grid cells for tau; an input
  nput: array maximum for putTab and puttTab; an input
  numdiv: array maximum for divAmounts and divTimes; an input
  parValue: solution variable; an input
  putTab: solution variable; an input
  puttTab: Sample array for Exercise; an input
  rdfree: solution variable; an input
  rho: solution variable; an input
  sigmaS: solution variable; an input
  sigmaX: solution variable; an input
  SMax: solution variable; an input
  SMin: solution variable; an input
  Spot: solution variable; an input
  spread: solution variable; an input
  tcallStart: solution variable; an input
  TMax: minimum physical value in dimension tau; an input
  tolSOR: solution variable; an input
  XSpot: solution variable; an input
  atSpot1x: solution variable; an output
  atSpot11x: solution variable; an output
  atSpot2x: solution variable; an output
  Sx: solution variable; an output
  Vx: option value; an output
*** end Key to program variables: ***/


/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for coupTab in file "coupTable.dat" has maximum index
      ncoup, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the ncoup elements,
      to be stored in coupTab(1..ncoup).

   The table for couptTab in file "coupTable.dat" has maximum index
      ncoup, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the ncoup elements,
      to be stored in couptTab(1..ncoup).

   The table for divAmounts in file "tdiv.dat" has maximum index
      numdiv, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the numdiv elements,
      to be stored in divAmounts(1..numdiv).

   The table for divTimes in file "tdiv.dat" has maximum index
      numdiv, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the numdiv elements,
      to be stored in divTimes(1..numdiv).

   The table for putTab in file "putTable.dat" has maximum index
      nput, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nput elements,
      to be stored in putTab(1..nput).

   The table for puttTab in file "putTable.dat" has maximum index
      nput, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nput elements,
      to be stored in puttTab(1..nput).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "FXCBond1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfileFXCBond1MW
#define openfileFXCBond1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfileFXCBond1MR
#define openfileFXCBond1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMFXCBond1M
#define fscanfMFXCBond1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2


int main()
{
    int i5,iMax,itvar1,ncoup,nMax,nput,numdiv;
    double Accuracy,atSpot11x,atSpot1x,atSpot2x,callPrice,CR,D0,parValue,rdfree,rho,sigmaS,sigmaX,SMax,SMin,Spot,spread,
       tcallStart,TMax,tolSOR,XSpot;
    ArgumentRecord fxcbond1InputTable[22];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4,*IOUNIT5,*IOUNIT6;
    
    /* *** Key to program variables: *** */
    /* Accuracy, atSpot11x, atSpot1x, atSpot2x, callPrice, coupTab, CR, divAmounts, parValue, putTab, rdfree, rho,      
       sigmaS, sigmaX, SMax, SMin, Spot, spread, tcallStart, tolSOR, XSpot: solution variable */
    /* couptTab, puttTab: Sample array for Exercise */
    /* D0: continuous dividend yield */
    /* divTimes: Sample array for DividendAtEnd */
    /* i5: index variable for x */
    /* iMax: number of grid cells for x */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5, IOUNIT6: I/O channel */
    /* ncoup: array maximum for coupTab and couptTab */
    /* nMax: number of grid cells for tau */
    /* nput: array maximum for putTab and puttTab */
    /* numdiv: array maximum for divAmounts and divTimes */
    /* TMax: minimum physical value in dimension tau */
    /* V: option value */
    try {
    /* Read Tagged Input File */
    openfileFXCBond1MR(IOUNIT3,"fxcbond1.dat");
    setupargs(fxcbond1InputTable, 0, "Accuracy", Accuracy, READINPUTSDOUBLE);
    setupargs(fxcbond1InputTable, 1, "callPrice", callPrice, READINPUTSDOUBLE);
    setupargs(fxcbond1InputTable, 2, "CR", CR, READINPUTSDOUBLE);
    setupargs(fxcbond1InputTable, 3, "D0", D0, READINPUTSDOUBLE);
    setupargs(fxcbond1InputTable, 4, "iMax", iMax, READINPUTSINTEGER);
    setupargs(fxcbond1InputTable, 5, "ncoup", ncoup, READINPUTSINTEGER);
    setupargs(fxcbond1InputTable, 6, "nMax", nMax, READINPUTSINTEGER);
    setupargs(fxcbond1InputTable, 7, "nput", nput, READINPUTSINTEGER);
    setupargs(fxcbond1InputTable, 8, "numdiv", numdiv, READINPUTSINTEGER);
    setupargs(fxcbond1InputTable, 9, "parValue", parValue, READINPUTSDOUBLE);
    setupargs(fxcbond1InputTable, 10, "rdfree", rdfree, READINPUTSDOUBLE);
    setupargs(fxcbond1InputTable, 11, "rho", rho, READINPUTSDOUBLE);
    setupargs(fxcbond1InputTable, 12, "sigmaS", sigmaS, READINPUTSDOUBLE);
    setupargs(fxcbond1InputTable, 13, "sigmaX", sigmaX, READINPUTSDOUBLE);
    setupargs(fxcbond1InputTable, 14, "SMax", SMax, READINPUTSDOUBLE);
    setupargs(fxcbond1InputTable, 15, "SMin", SMin, READINPUTSDOUBLE);
    setupargs(fxcbond1InputTable, 16, "Spot", Spot, READINPUTSDOUBLE);
    setupargs(fxcbond1InputTable, 17, "spread", spread, READINPUTSDOUBLE);
    setupargs(fxcbond1InputTable, 18, "tcallStart", tcallStart, READINPUTSDOUBLE);
    setupargs(fxcbond1InputTable, 19, "TMax", TMax, READINPUTSDOUBLE);
    setupargs(fxcbond1InputTable, 20, "tolSOR", tolSOR, READINPUTSDOUBLE);
    setupargs(fxcbond1InputTable, 21, "XSpot", XSpot, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT3,fxcbond1InputTable,22)!=0)
        {
        fclose(IOUNIT3);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT3);
    SciArray1<double>couptTab(ncoup + 1);
    SciArray1<double>coupTab(ncoup + 1);
    /* Read couptTab from file. Read coupTab from file */
    if (ncoup>=1)
        {
        openfileFXCBond1MR(IOUNIT4,"coupTable.dat");
        for (itvar1=1; itvar1<=ncoup; itvar1++) {
            fscanfMFXCBond1M(IOUNIT4,"%lg%lg",2,((&couptTab(itvar1)),(&coupTab(itvar1))));
        }
        fclose(IOUNIT4);
        }
    SciArray1<double>puttTab(nput + 1);
    SciArray1<double>putTab(nput + 1);
    /* Read puttTab from file. Read putTab from file */
    if (nput>=1)
        {
        openfileFXCBond1MR(IOUNIT5,"putTable.dat");
        for (itvar1=1; itvar1<=nput; itvar1++) {
            fscanfMFXCBond1M(IOUNIT5,"%lg%lg",2,((&puttTab(itvar1)),(&putTab(itvar1))));
        }
        fclose(IOUNIT5);
        }
    SciArray1<double>divAmounts(numdiv + 1);
    SciArray1<double>divTimes(numdiv + 1);
    /* Read divAmounts from file. Read divTimes from file */
    if (numdiv>=1)
        {
        openfileFXCBond1MR(IOUNIT6,"tdiv.dat");
        for (itvar1=1; itvar1<=numdiv; itvar1++) {
            fscanfMFXCBond1M(IOUNIT6,"%lg%lg",2,((&divAmounts(itvar1)),(&divTimes(itvar1))));
        }
        fclose(IOUNIT6);
        }
    /*                            */
    /* Call the computation function. */
    SciArray1<double> S;
    SciArray1<double> V;
    FXCBond1fn(Accuracy,callPrice,coupTab,couptTab,CR,D0,divAmounts,divTimes,iMax,ncoup,nMax,nput,numdiv,parValue,putTab
       ,puttTab,rdfree,rho,sigmaS,sigmaX,SMax,SMin,Spot,spread,tcallStart,TMax,tolSOR,XSpot,atSpot1x,atSpot11x,atSpot2x,
       S,V);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfileFXCBond1MW(IOUNIT,"V.out");
    for (i5=0; i5<=(int)V.size0() - 1; i5++) {
        fprintf(IOUNIT, " %g %18.8e %18.8e\n", 0.,S(i5),V(i5));
    }
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* Writing collected output to file atSpot1.out from ResultEq1c. */
    openfileFXCBond1MW(IOUNIT1,"atSpot1.out");
    fprintf(IOUNIT1, " %g %18.8e %18.8e\n", 0.,Spot*XSpot,atSpot1x);
    fprintf(IOUNIT1, "\n");
    /* Writing collected output to file atSpot1.out from ResultEq2c. */
    fprintf(IOUNIT1, " %g %18.8e %18.8e\n", 0.,Spot*XSpot,atSpot11x);
    fprintf(IOUNIT1, "\n");
    fclose(IOUNIT1);
    /* Writing collected output to file atSpot2.out from ResultEq3c. */
    openfileFXCBond1MW(IOUNIT2,"atSpot2.out");
    fprintf(IOUNIT2, " %g %18.8e %18.8e\n", 0.,Spot*XSpot,atSpot2x);
    fprintf(IOUNIT2, "\n");
    fclose(IOUNIT2);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




