#ifndef MCG2BSWAPTION1_H
#define MCG2BSWAPTION1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcG2BSwaption1fn(
    double K,
    double kappa1,
    double kappa2,
    int maxord1,
    int maxord2,
    int nExer,
    int nMax,
    double Notional,
    int nSwap,
    int nZero,
    int payer,
    int pMax,
    double rho12,
    int Series,
    double sigma1,
    double sigma2,
    const SciArray1<double>& SwapDates,
    const SciArray1<double>& zDates,
    const SciArray1<double>& zRates,
    double & Vx
    );
     


#endif /* MCG2BSWAPTION1_H */
