

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for SwapDates in file "SwapDates.dat" has maximum index
      imax1, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the imax1 elements,
      to be stored in SwapDates(1..imax1).

   The table for zDates in file "ZeroCurve.dat" has maximum index
      nZero, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nZero elements,
      to be stored in zDates(0..nZero).

   The table for zRates in file "ZeroCurve.dat" has maximum index
      nZero, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nZero elements,
      to be stored in zRates(0..nZero).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcG2BSwaption1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcG2BSwaption1MW
#define openfilemcG2BSwaption1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcG2BSwaption1MR
#define openfilemcG2BSwaption1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcG2BSwaption1M
#define fscanfMmcG2BSwaption1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2


int main()
{
    int imax1,itvar1,maxord1,maxord2,nExer,nMax,nSwap,nZero,payer,pMax,Series;
    ArgumentRecord initInputTable[16];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3;
    double K,kappa1,kappa2,Notional,rho12,sigma1,sigma2,Vx;
    
    /* *** Key to program variables: *** */
    /* imax1: maximum for is */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3: I/O channel */
    /* K, kappa1, kappa2, maxord1, maxord2, nExer, Notional, nSwap, payer, rho12, Series, sigma1, sigma2, SwapDates,    
       zDates, zRates: solution variable */
    /* nMax: number of grid cells for t */
    /* nZero: array maximum for zDates and zRates */
    /* pMax: maximum for path */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcG2BSwaption1MR(IOUNIT1,"init.dat");
    setupargs(initInputTable, 0, "K", K, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "kappa1", kappa1, READINPUTSDOUBLE);
    setupargs(initInputTable, 2, "kappa2", kappa2, READINPUTSDOUBLE);
    setupargs(initInputTable, 3, "maxord1", maxord1, READINPUTSINTEGER);
    setupargs(initInputTable, 4, "maxord2", maxord2, READINPUTSINTEGER);
    setupargs(initInputTable, 5, "nExer", nExer, READINPUTSINTEGER);
    setupargs(initInputTable, 6, "nMax", nMax, READINPUTSINTEGER);
    setupargs(initInputTable, 7, "Notional", Notional, READINPUTSDOUBLE);
    setupargs(initInputTable, 8, "nSwap", nSwap, READINPUTSINTEGER);
    setupargs(initInputTable, 9, "nZero", nZero, READINPUTSINTEGER);
    setupargs(initInputTable, 10, "payer", payer, READINPUTSINTEGER);
    setupargs(initInputTable, 11, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 12, "rho12", rho12, READINPUTSDOUBLE);
    setupargs(initInputTable, 13, "Series", Series, READINPUTSINTEGER);
    setupargs(initInputTable, 14, "sigma1", sigma1, READINPUTSDOUBLE);
    setupargs(initInputTable, 15, "sigma2", sigma2, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,initInputTable,16)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    imax1 = nSwap + 1;
    /* Read SwapDates from file */
    SciArray1<double>SwapDates(imax1 + 1);
    if (imax1>=1)
        {
        openfilemcG2BSwaption1MR(IOUNIT2,"SwapDates.dat");
        for (itvar1=1; itvar1<=imax1; itvar1++) {
            fscanfMmcG2BSwaption1M(IOUNIT2,"%lg",1,((&SwapDates(itvar1))));
        }
        fclose(IOUNIT2);
        }
    SciArray1<double>zDates(nZero + 1);
    SciArray1<double>zRates(nZero + 1);
    /* Read zDates from file. Read zRates from file */
    if (nZero>=0)
        {
        openfilemcG2BSwaption1MR(IOUNIT3,"ZeroCurve.dat");
        for (itvar1=0; itvar1<=nZero; itvar1++) {
            fscanfMmcG2BSwaption1M(IOUNIT3,"%lg%lg",2,((&zDates(itvar1)),(&zRates(itvar1))));
        }
        fclose(IOUNIT3);
        }
    /*                            */
    /* Call the computation function. */
    mcG2BSwaption1fn(K,kappa1,kappa2,maxord1,maxord2,nExer,nMax,Notional,nSwap,nZero,payer,pMax,rho12,Series,sigma1,
       sigma2,SwapDates,zDates,zRates,Vx);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfilemcG2BSwaption1MW(IOUNIT,"V.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




