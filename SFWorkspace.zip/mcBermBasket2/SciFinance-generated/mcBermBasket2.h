#ifndef MCBERMBASKET2_H
#define MCBERMBASKET2_H

#include "SciArrayN.h" /* SciComp arrays */

void mcBermBasket2fn(
    const SciArray1<double>& D0,
    double disc,
    double K,
    const SciArray1<double>& loan,
    int maxord,
    int nD,
    int nExer,
    int pMax,
    int pMaxI,
    int put,
    const SciArray2<double>& rho,
    int Seed,
    const SciArray1<double>& sigma,
    const SciArray1<double>& Spot,
    double TMax,
    const SciArray1<double>& weight,
    double & devx,
    double & Vx
    );
     


#endif /* MCBERMBASKET2_H */
