/*** Key to program variables: ***
  Accuracy: solution variable; an input
  alphaS1: solution variable; an input
  alphaS2: solution variable; an input
  callPrice: solution variable; an input
  coupTab: solution variable; an input
  couptTab: Sample array for Exercise; an input
  CR1: solution variable; an input
  CR2: solution variable; an input
  D01: continuous dividend yield security 1; an input
  D02: continuous dividend yield security 2; an input
  div1Amounts: solution variable; an input
  div1Times: Sample array for DividendAtEnd; an input
  div2Amounts: solution variable; an input
  div2Times: Sample array for DividendAtEnd; an input
  iMax: number of grid cells for x; an input
  jMax: number of grid cells for y; an input
  ncoup: array maximum for coupTab and couptTab; an input
  nMax: number of grid cells for tau; an input
  nput: array maximum for putTab and puttTab; an input
  numdiv1: array maximum for div1Amounts and div1Times; an input
  numdiv2: array maximum for div2Amounts and div2Times; an input
  parValue: solution variable; an input
  protPrice1: solution variable; an input
  protPrice2: solution variable; an input
  putTab: solution variable; an input
  puttTab: Sample array for Exercise; an input
  r: risk-free interest rate; an input
  rho: correlation coefficient; an input
  S1Max: solution variable; an input
  S1Min: solution variable; an input
  S2Max: solution variable; an input
  S2Min: solution variable; an input
  sigma1: volatility security 1; an input
  sigma2: volatility security 2; an input
  Spot1: solution variable; an input
  Spot2: solution variable; an input
  tcallStart: solution variable; an input
  TMax: minimum physical value in dimension tau; an input
  tolSOR: solution variable; an input
  atSpotx: solution variable; an output
  atSpot1x: solution variable; an output
  atSpot2x: solution variable; an output
*** end Key to program variables: ***/


/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for coupTab in file "coupTable.dat" has maximum index
      ncoup, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the ncoup elements,
      to be stored in coupTab(1..ncoup).

   The table for couptTab in file "coupTable.dat" has maximum index
      ncoup, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the ncoup elements,
      to be stored in couptTab(1..ncoup).

   The table for div1Amounts in file "tdiv1.dat" has maximum index
      numdiv1, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the numdiv1 elements,
      to be stored in div1Amounts(1..numdiv1).

   The table for div1Times in file "tdiv1.dat" has maximum index
      numdiv1, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the numdiv1 elements,
      to be stored in div1Times(1..numdiv1).

   The table for div2Amounts in file "tdiv2.dat" has maximum index
      numdiv2, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the numdiv2 elements,
      to be stored in div2Amounts(1..numdiv2).

   The table for div2Times in file "tdiv2.dat" has maximum index
      numdiv2, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the numdiv2 elements,
      to be stored in div2Times(1..numdiv2).

   The table for putTab in file "putTable.dat" has maximum index
      nput, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nput elements,
      to be stored in putTab(1..nput).

   The table for puttTab in file "putTable.dat" has maximum index
      nput, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nput elements,
      to be stored in puttTab(1..nput).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "CBBestOf2.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfileCBBestOf2MW
#define openfileCBBestOf2MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfileCBBestOf2MR
#define openfileCBBestOf2MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMCBBestOf2M
#define fscanfMCBBestOf2M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2


int main()
{
    int iMax,itvar1,jMax,ncoup,nMax,nput,numdiv1,numdiv2;
    double Accuracy,alphaS1,alphaS2,atSpot1x,atSpot2x,atSpotx,callPrice,CR1,CR2,D01,D02,parValue,protPrice1,protPrice2,r
       ,rho,S1Max,S1Min,S2Max,S2Min,sigma1,sigma2,Spot1,Spot2,tcallStart,TMax,tolSOR;
    ArgumentRecord cbbestof2InputTable[31];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4,*IOUNIT5;
    
    /* *** Key to program variables: *** */
    /* Accuracy, alphaS1, alphaS2, atSpot1x, atSpot2x, atSpotx, callPrice, coupTab, CR1, CR2, div1Amounts, div2Amounts, 
       parValue, protPrice1, protPrice2, putTab, S1Max, S1Min, S2Max, S2Min, Spot1, Spot2, tcallStart, tolSOR: solution 
       variable */
    /* couptTab, puttTab: Sample array for Exercise */
    /* D01: continuous dividend yield security 1 */
    /* D02: continuous dividend yield security 2 */
    /* div1Times, div2Times: Sample array for DividendAtEnd */
    /* iMax: number of grid cells for x */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5: I/O channel */
    /* jMax: number of grid cells for y */
    /* ncoup: array maximum for coupTab and couptTab */
    /* nMax: number of grid cells for tau */
    /* nput: array maximum for putTab and puttTab */
    /* numdiv1: array maximum for div1Amounts and div1Times */
    /* numdiv2: array maximum for div2Amounts and div2Times */
    /* r: risk-free interest rate */
    /* rho: correlation coefficient */
    /* sigma1: volatility security 1 */
    /* sigma2: volatility security 2 */
    /* TMax: minimum physical value in dimension tau */
    try {
    /* Read Tagged Input File */
    openfileCBBestOf2MR(IOUNIT1,"cbbestof2.dat");
    setupargs(cbbestof2InputTable, 0, "Accuracy", Accuracy, READINPUTSDOUBLE);
    setupargs(cbbestof2InputTable, 1, "alphaS1", alphaS1, READINPUTSDOUBLE);
    setupargs(cbbestof2InputTable, 2, "alphaS2", alphaS2, READINPUTSDOUBLE);
    setupargs(cbbestof2InputTable, 3, "callPrice", callPrice, READINPUTSDOUBLE);
    setupargs(cbbestof2InputTable, 4, "CR1", CR1, READINPUTSDOUBLE);
    setupargs(cbbestof2InputTable, 5, "CR2", CR2, READINPUTSDOUBLE);
    setupargs(cbbestof2InputTable, 6, "D01", D01, READINPUTSDOUBLE);
    setupargs(cbbestof2InputTable, 7, "D02", D02, READINPUTSDOUBLE);
    setupargs(cbbestof2InputTable, 8, "iMax", iMax, READINPUTSINTEGER);
    setupargs(cbbestof2InputTable, 9, "jMax", jMax, READINPUTSINTEGER);
    setupargs(cbbestof2InputTable, 10, "ncoup", ncoup, READINPUTSINTEGER);
    setupargs(cbbestof2InputTable, 11, "nMax", nMax, READINPUTSINTEGER);
    setupargs(cbbestof2InputTable, 12, "nput", nput, READINPUTSINTEGER);
    setupargs(cbbestof2InputTable, 13, "numdiv1", numdiv1, READINPUTSINTEGER);
    setupargs(cbbestof2InputTable, 14, "numdiv2", numdiv2, READINPUTSINTEGER);
    setupargs(cbbestof2InputTable, 15, "parValue", parValue, READINPUTSDOUBLE);
    setupargs(cbbestof2InputTable, 16, "protPrice1", protPrice1, READINPUTSDOUBLE);
    setupargs(cbbestof2InputTable, 17, "protPrice2", protPrice2, READINPUTSDOUBLE);
    setupargs(cbbestof2InputTable, 18, "r", r, READINPUTSDOUBLE);
    setupargs(cbbestof2InputTable, 19, "rho", rho, READINPUTSDOUBLE);
    setupargs(cbbestof2InputTable, 20, "S1Max", S1Max, READINPUTSDOUBLE);
    setupargs(cbbestof2InputTable, 21, "S1Min", S1Min, READINPUTSDOUBLE);
    setupargs(cbbestof2InputTable, 22, "S2Max", S2Max, READINPUTSDOUBLE);
    setupargs(cbbestof2InputTable, 23, "S2Min", S2Min, READINPUTSDOUBLE);
    setupargs(cbbestof2InputTable, 24, "sigma1", sigma1, READINPUTSDOUBLE);
    setupargs(cbbestof2InputTable, 25, "sigma2", sigma2, READINPUTSDOUBLE);
    setupargs(cbbestof2InputTable, 26, "Spot1", Spot1, READINPUTSDOUBLE);
    setupargs(cbbestof2InputTable, 27, "Spot2", Spot2, READINPUTSDOUBLE);
    setupargs(cbbestof2InputTable, 28, "tcallStart", tcallStart, READINPUTSDOUBLE);
    setupargs(cbbestof2InputTable, 29, "TMax", TMax, READINPUTSDOUBLE);
    setupargs(cbbestof2InputTable, 30, "tolSOR", tolSOR, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,cbbestof2InputTable,31)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    SciArray1<double>couptTab(ncoup + 1);
    SciArray1<double>coupTab(ncoup + 1);
    /* Read couptTab from file. Read coupTab from file */
    if (ncoup>=1)
        {
        openfileCBBestOf2MR(IOUNIT2,"coupTable.dat");
        for (itvar1=1; itvar1<=ncoup; itvar1++) {
            fscanfMCBBestOf2M(IOUNIT2,"%lg%lg",2,((&couptTab(itvar1)),(&coupTab(itvar1))));
        }
        fclose(IOUNIT2);
        }
    SciArray1<double>puttTab(nput + 1);
    SciArray1<double>putTab(nput + 1);
    /* Read puttTab from file. Read putTab from file */
    if (nput>=1)
        {
        openfileCBBestOf2MR(IOUNIT3,"putTable.dat");
        for (itvar1=1; itvar1<=nput; itvar1++) {
            fscanfMCBBestOf2M(IOUNIT3,"%lg%lg",2,((&puttTab(itvar1)),(&putTab(itvar1))));
        }
        fclose(IOUNIT3);
        }
    SciArray1<double>div1Amounts(numdiv1 + 1);
    SciArray1<double>div1Times(numdiv1 + 1);
    /* Read div1Amounts from file. Read div1Times from file */
    if (numdiv1>=1)
        {
        openfileCBBestOf2MR(IOUNIT4,"tdiv1.dat");
        for (itvar1=1; itvar1<=numdiv1; itvar1++) {
            fscanfMCBBestOf2M(IOUNIT4,"%lg%lg",2,((&div1Amounts(itvar1)),(&div1Times(itvar1))));
        }
        fclose(IOUNIT4);
        }
    SciArray1<double>div2Amounts(numdiv2 + 1);
    SciArray1<double>div2Times(numdiv2 + 1);
    /* Read div2Amounts from file. Read div2Times from file */
    if (numdiv2>=1)
        {
        openfileCBBestOf2MR(IOUNIT5,"tdiv2.dat");
        for (itvar1=1; itvar1<=numdiv2; itvar1++) {
            fscanfMCBBestOf2M(IOUNIT5,"%lg%lg",2,((&div2Amounts(itvar1)),(&div2Times(itvar1))));
        }
        fclose(IOUNIT5);
        }
    /*                            */
    /* Call the computation function. */
    CBBestOf2fn(Accuracy,alphaS1,alphaS2,callPrice,coupTab,couptTab,CR1,CR2,D01,D02,div1Amounts,div1Times,div2Amounts,
       div2Times,iMax,jMax,ncoup,nMax,nput,numdiv1,numdiv2,parValue,protPrice1,protPrice2,putTab,puttTab,r,rho,S1Max,
       S1Min,S2Max,S2Min,sigma1,sigma2,Spot1,Spot2,tcallStart,TMax,tolSOR,atSpotx,atSpot1x,atSpot2x);
    /*                            */
    /* Writing collected output to file atSpot.out from ResultEqc. */
    openfileCBBestOf2MW(IOUNIT,"atSpot.out");
    fprintf(IOUNIT, " %g %18.8e %18.8e %18.8e\n", 0.,Spot1,Spot2,atSpotx);
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file atSpot.out from ResultEq1c. */
    fprintf(IOUNIT, " %g %18.8e %18.8e %18.8e\n", 0.,Spot1,Spot2,atSpot1x);
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file atSpot.out from ResultEq2c. */
    fprintf(IOUNIT, " %g %18.8e %18.8e %18.8e\n", 0.,Spot1,Spot2,atSpot2x);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




