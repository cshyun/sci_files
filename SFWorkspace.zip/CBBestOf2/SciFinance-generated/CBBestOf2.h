#ifndef CBBESTOF2_H
#define CBBESTOF2_H

#include "SciArrayN.h" /* SciComp arrays */

void CBBestOf2fn(
    double Accuracy,
    double alphaS1,
    double alphaS2,
    double callPrice,
    const SciArray1<double>& coupTab,
    const SciArray1<double>& couptTab,
    double CR1,
    double CR2,
    double D01,
    double D02,
    const SciArray1<double>& div1Amounts,
    const SciArray1<double>& div1Times,
    const SciArray1<double>& div2Amounts,
    const SciArray1<double>& div2Times,
    int iMax,
    int jMax,
    int ncoup,
    int nMax,
    int nput,
    int numdiv1,
    int numdiv2,
    double parValue,
    double protPrice1,
    double protPrice2,
    const SciArray1<double>& putTab,
    const SciArray1<double>& puttTab,
    double r,
    double rho,
    double S1Max,
    double S1Min,
    double S2Max,
    double S2Min,
    double sigma1,
    double sigma2,
    double Spot1,
    double Spot2,
    double tcallStart,
    double TMax,
    double tolSOR,
    double & atSpotx,
    double & atSpot1x,
    double & atSpot2x
    );
     


#endif /* CBBESTOF2_H */
