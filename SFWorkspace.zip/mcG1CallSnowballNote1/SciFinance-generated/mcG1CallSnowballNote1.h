#ifndef MCG1CALLSNOWBALLNOTE1_H
#define MCG1CALLSNOWBALLNOTE1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcG1CallSnowballNote1fn(
    const SciArray1<double>& Accrual,
    double CallPrice,
    const SciArray1<double>& ExerciseDates,
    const SciArray1<double>& Flr,
    const SciArray1<double>& Gear1,
    const SciArray1<double>& Gear2,
    double kappa,
    int maxord1,
    int maxord2,
    int nCpn,
    int nExer,
    int nMax,
    double Notional,
    int nRst,
    int nZero,
    double PastCoupon,
    double PastLibor,
    const SciArray1<double>& PaymentDates,
    int pMax,
    const SciArray1<double>& ResetDates,
    int Series,
    double sigma,
    const SciArray1<double>& Spread,
    double tau,
    const SciArray1<double>& zDates,
    const SciArray1<double>& zRates,
    double & Vx
    );
     


#endif /* MCG1CALLSNOWBALLNOTE1_H */
