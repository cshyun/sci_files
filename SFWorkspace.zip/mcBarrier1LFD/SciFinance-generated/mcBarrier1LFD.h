#ifndef MCBARRIER1LFD_H
#define MCBARRIER1LFD_H

#include "SciArrayN.h" /* SciComp arrays */

void mcBarrier1LFDfn(
    double B,
    int call,
    double epsilon,
    double K,
    int nsamp,
    int pMax,
    double q,
    double r,
    double Rebate,
    int Seed,
    double sigma,
    double Spot,
    double TMax,
    const SciArray1<double>& tsamp,
    int up,
    double & Deltax,
    double & devx,
    double & EDeltax,
    double & EGammax,
    double & ERhox,
    double & ERhoQx,
    double & EThetax,
    double & EVannax,
    double & EVegax,
    double & EVolgax,
    double & Gammax,
    double & Rhox,
    double & RhoQx,
    double & Thetax,
    double & Vx,
    double & Vannax,
    double & Vegax,
    double & Volgax
    );
     


#endif /* MCBARRIER1LFD_H */
