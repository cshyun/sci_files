#ifndef MCASIANBASKET1_H
#define MCASIANBASKET1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcAsianBasket1fn(
    const SciArray1<double>& D0,
    double disc,
    double K,
    double lastA,
    const SciArray1<double>& loan,
    int nD,
    int nsampSoFar,
    int nsampToGo,
    int pMax,
    const SciArray2<double>& rho,
    int Series,
    const SciArray1<double>& sigma,
    const SciArray1<double>& Spot,
    double TMax,
    const SciArray1<double>& tsamp,
    const SciArray1<double>& weight,
    double & Vx
    );
     


#endif /* MCASIANBASKET1_H */
