#ifndef MCEVEREST1_H
#define MCEVEREST1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcEverest1fn(
    const SciArray1<double>& beta,
    double Bonus,
    const SciArray1<double>& D0,
    double disc,
    const SciArray1<double>& loan,
    int nD,
    int nMax,
    double Notional,
    double perfFloor,
    int pMax,
    const SciArray2<double>& rho,
    const SciArray1<double>& S0,
    int Series,
    const SciArray1<double>& sigma,
    const SciArray1<double>& SNorm,
    const SciArray1<double>& Spot,
    double TMax,
    double & Vx
    );
     


#endif /* MCEVEREST1_H */
