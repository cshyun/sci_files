

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for calcGreeks in file "Stocks.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in calcGreeks(1..nD).

   The table for KU in file "Stocks.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in KU(1..nD).

   The table for loan in file "Stocks.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in loan(1..nD).

   The table for q in file "Stocks.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in q(1..nD).

   The table for rho in file "rho.dat" has maximum indices
      nD and nD, 
     with minimum indices 1, 1 respectively.
      The index bounds are not read from this file.
        Following should be the nD^2 elements,
      to be stored in rho(1..nD, 1..nD).
   The first index is the most slowly varying and 
      the last index is the most rapidly varying.

   The table for sigma in file "Stocks.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in sigma(1..nD).

   The table for Spot in file "Stocks.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in Spot(1..nD).

   The table for WU in file "Stocks.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in WU(1..nD).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcBestWorst2.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcBestWorst2MW
#define openfilemcBestWorst2MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcBestWorst2MR
#define openfilemcBestWorst2MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcBestWorst2M
#define fscanfMmcBestWorst2M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs7
#define spreadargs7(a1,a2,a3,a4,a5,a6,a7) a1,a2,a3,a4,a5,a6,a7


int main()
{
    int call,iD,itvar1,itvar2,nD,pMax,Series;
    int Best;
    double disc,KB,Sbump,TB,TU,Vx;
    ArgumentRecord initInputTable[10];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4,*IOUNIT5;
    
    /* *** Key to program variables: *** */
    /* Best, calcGreeks, call, KB, KU, loan, q, rho, Sbump, Series, sigma, Spot, TB, TU, WU: solution variable */
    /* Delta: greek for if[calcGreeks, der[V, {Spot, 1}], seq[]] */
    /* disc: discount rate */
    /* Gamma: greek for if[calcGreeks, der[V, {Spot, 2}], seq[]] */
    /* iD: dependencies index */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5: I/O channel */
    /* nD: maximum for iD */
    /* pMax: maximum for path */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcBestWorst2MR(IOUNIT3,"init.dat");
    setupargs(initInputTable, 0, "Best", Best, READINPUTSBOOLEAN);
    setupargs(initInputTable, 1, "call", call, READINPUTSINTEGER);
    setupargs(initInputTable, 2, "disc", disc, READINPUTSDOUBLE);
    setupargs(initInputTable, 3, "KB", KB, READINPUTSDOUBLE);
    setupargs(initInputTable, 4, "nD", nD, READINPUTSINTEGER);
    setupargs(initInputTable, 5, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 6, "Sbump", Sbump, READINPUTSDOUBLE);
    setupargs(initInputTable, 7, "Series", Series, READINPUTSINTEGER);
    setupargs(initInputTable, 8, "TB", TB, READINPUTSDOUBLE);
    setupargs(initInputTable, 9, "TU", TU, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT3,initInputTable,10)!=0)
        {
        fclose(IOUNIT3);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT3);
    SciArray2<double>rho(nD + 1, nD + 1);
    SciArray1<double>Spot(nD + 1);
    SciArray1<double>loan(nD + 1);
    SciArray1<double>q(nD + 1);
    SciArray1<double>sigma(nD + 1);
    SciArray1<double>KU(nD + 1);
    SciArray1<double>WU(nD + 1);
    SciArray1<int>calcGreeks(nD + 1);
    if (nD>=1)
        {
        /* Read rho from file */
        openfilemcBestWorst2MR(IOUNIT4,"rho.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            for (itvar2=1; itvar2<=nD; itvar2++) {
                fscanfMmcBestWorst2M(IOUNIT4,"%lg",1,((&rho(itvar1,itvar2))));
            }
        }
        fclose(IOUNIT4);
        /* Read Spot from file. Read loan from file. Read q from file. Read sigma from file. Read KU from file. Read WU 
           from file. Read calcGreeks from file */
        openfilemcBestWorst2MR(IOUNIT5,"Stocks.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcBestWorst2M(IOUNIT5,
               "%lg%lg%lg%lg%lg%lg%i"
               ,7,((&Spot(itvar1)),(&loan(itvar1)),(&q(itvar1)),(&sigma(itvar1)),(&KU(itvar1)),(&WU(itvar1)),(
               &calcGreeks(itvar1))));
        }
        fclose(IOUNIT5);
        }
    /*                            */
    /* Call the computation function. */
    SciArray1<double> Delta;
    SciArray1<double> Gamma;
    mcBestWorst2fn(Best,calcGreeks,call,disc,KB,KU,loan,nD,pMax,q,rho,Sbump,Series,sigma,Spot,TB,TU,WU,Delta,Gamma,Vx);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfilemcBestWorst2MW(IOUNIT,"V.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* Writing collected output to file Delta.out from ResultEq1c. */
    openfilemcBestWorst2MW(IOUNIT1,"Delta.out");
    for (iD=1; iD<=(int)Delta.size0() - 1; iD++) {
        fprintf(IOUNIT1, " %18.8e\n", Delta(iD));
    }
    fprintf(IOUNIT1, "\n");
    fclose(IOUNIT1);
    /* Writing collected output to file Gamma.out from ResultEq2c. */
    openfilemcBestWorst2MW(IOUNIT2,"Gamma.out");
    for (iD=1; iD<=(int)Gamma.size0() - 1; iD++) {
        fprintf(IOUNIT2, " %18.8e\n", Gamma(iD));
    }
    fprintf(IOUNIT2, "\n");
    fclose(IOUNIT2);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




