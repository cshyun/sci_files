#ifndef MCBESTWORST2_H
#define MCBESTWORST2_H

#include "SciArrayN.h" /* SciComp arrays */

void mcBestWorst2fn(
    int Best,
    const SciArray1<int>& calcGreeks,
    int call,
    double disc,
    double KB,
    const SciArray1<double>& KU,
    const SciArray1<double>& loan,
    int nD,
    int pMax,
    const SciArray1<double>& q,
    const SciArray2<double>& rho,
    double Sbump,
    int Series,
    const SciArray1<double>& sigma,
    const SciArray1<double>& Spot,
    double TB,
    double TU,
    const SciArray1<double>& WU,
    SciArray1<double>& Deltax,
    SciArray1<double>& Gammax,
    double & Vx
    );
     


#endif /* MCBESTWORST2_H */
