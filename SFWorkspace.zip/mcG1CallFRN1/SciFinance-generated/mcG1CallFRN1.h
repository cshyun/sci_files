#ifndef MCG1CALLFRN1_H
#define MCG1CALLFRN1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcG1CallFRN1fn(
    const SciArray1<double>& Accrual,
    double CallPrice,
    const SciArray1<double>& Cap,
    const SciArray1<double>& ExerciseDates,
    const SciArray1<double>& Flr,
    const SciArray1<double>& Gear,
    double kappa,
    int maxord1,
    int maxord2,
    int nCpn,
    int nExer,
    int nMax,
    double Notional,
    int nRst,
    int nZero,
    double PastLibor,
    const SciArray1<double>& PaymentDates,
    int pMax,
    const SciArray1<double>& ResetDates,
    int Series,
    double sigma,
    const SciArray1<double>& Spread,
    double tau,
    const SciArray1<double>& zDates,
    const SciArray1<double>& zRates,
    double & Vx
    );
     


#endif /* MCG1CALLFRN1_H */
