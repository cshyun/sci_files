#ifndef MCEXACTOU1_H
#define MCEXACTOU1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcExactOU1fn(
    double kappa1,
    double kappa2,
    int nCurve,
    int nMax,
    int pMax,
    double rho12,
    int Series,
    double sigma1,
    double sigma2,
    double TMax,
    const SciArray1<double>& ZeroDates,
    const SciArray1<double>& ZeroRates,
    double & Vx
    );
     


#endif /* MCEXACTOU1_H */
