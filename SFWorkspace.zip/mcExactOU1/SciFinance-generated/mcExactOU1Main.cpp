

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for ZeroDates in file "ZeroCurve.dat" has maximum index
      nCurve, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nCurve elements,
      to be stored in ZeroDates(0..nCurve).

   The table for ZeroRates in file "ZeroCurve.dat" has maximum index
      nCurve, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nCurve elements,
      to be stored in ZeroRates(0..nCurve).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcExactOU1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcExactOU1MW
#define openfilemcExactOU1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcExactOU1MR
#define openfilemcExactOU1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcExactOU1M
#define fscanfMmcExactOU1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2


int main()
{
    int itvar1,nCurve,nMax,pMax,Series;
    ArgumentRecord initInputTable[10];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2;
    double kappa1,kappa2,rho12,sigma1,sigma2,TMax,Vx;
    
    /* *** Key to program variables: *** */
    /* IOUNIT, IOUNIT1, IOUNIT2: I/O channel */
    /* kappa1, kappa2, rho12, Series, sigma1, sigma2, ZeroDates, ZeroRates: solution variable */
    /* nCurve: array maximum for ZeroDates and ZeroRates */
    /* nMax: number of grid cells for t */
    /* pMax: maximum for path */
    /* TMax: maximum time */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcExactOU1MR(IOUNIT1,"init.dat");
    setupargs(initInputTable, 0, "kappa1", kappa1, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "kappa2", kappa2, READINPUTSDOUBLE);
    setupargs(initInputTable, 2, "nCurve", nCurve, READINPUTSINTEGER);
    setupargs(initInputTable, 3, "nMax", nMax, READINPUTSINTEGER);
    setupargs(initInputTable, 4, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 5, "rho12", rho12, READINPUTSDOUBLE);
    setupargs(initInputTable, 6, "Series", Series, READINPUTSINTEGER);
    setupargs(initInputTable, 7, "sigma1", sigma1, READINPUTSDOUBLE);
    setupargs(initInputTable, 8, "sigma2", sigma2, READINPUTSDOUBLE);
    setupargs(initInputTable, 9, "TMax", TMax, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,initInputTable,10)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    SciArray1<double>ZeroDates(nCurve + 1);
    SciArray1<double>ZeroRates(nCurve + 1);
    /* Read ZeroDates from file. Read ZeroRates from file */
    if (nCurve>=0)
        {
        openfilemcExactOU1MR(IOUNIT2,"ZeroCurve.dat");
        for (itvar1=0; itvar1<=nCurve; itvar1++) {
            fscanfMmcExactOU1M(IOUNIT2,"%lg%lg",2,((&ZeroDates(itvar1)),(&ZeroRates(itvar1))));
        }
        fclose(IOUNIT2);
        }
    /*                            */
    /* Call the computation function. */
    mcExactOU1fn(kappa1,kappa2,nCurve,nMax,pMax,rho12,Series,sigma1,sigma2,TMax,ZeroDates,ZeroRates,Vx);
    /*                            */
    /* Writing collected output to file Value.out from ResultEqc. */
    openfilemcExactOU1MW(IOUNIT,"Value.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




