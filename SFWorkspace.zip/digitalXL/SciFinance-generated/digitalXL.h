/*** Key to program variables: ***
  Accuracy: controls numerical accuracy, typically 1; an input
  Cash: cash parameter; an input
  disc: risk-free rate; an input
  divyld: continuous dividend yield; an input
  iMax: number of grid cells for S; an input
  K: strike; an input
  loan: hedge rate; an input
  nMax: number of grid cells for t; an input
  sigma: volatility; an input
  Spot: Spot price; an input
  TMax: expiration; an input
  V1p1: interpolated value of V1 (option value) ; an output
*** end Key to program variables: ***/




#ifdef __cplusplus
extern "C" {
#endif
extern int digitalXLfn(
    double Accuracy,
    double Cash,
    double disc,
    double divyld,
    int iMax,
    double K,
    double loan,
    int nMax,
    double sigma,
    double Spot,
    double TMax,
    double *V1p1,
    int * SciErrorFlagp,
    struct error_struct * SciErrorBufferp
    );
     
#ifdef __cplusplus
}
#endif
