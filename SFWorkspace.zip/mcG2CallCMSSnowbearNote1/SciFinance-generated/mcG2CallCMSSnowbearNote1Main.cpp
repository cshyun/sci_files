

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for AccrualCms in file "CouponStruct.dat" has maximum index
      nCpn, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nCpn elements,
      to be stored in AccrualCms(1..nCpn).

   The table for CmsResetDates in file "CmsResetDates.dat" has maximum index
      nRst, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nRst elements,
      to be stored in CmsResetDates(1..nRst).

   The table for ExerciseDates in file "ExerciseDates.dat" has maximum index
      nExer, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nExer elements,
      to be stored in ExerciseDates(1..nExer).

   The table for Flr in file "CouponStruct.dat" has maximum index
      nCpn, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nCpn elements,
      to be stored in Flr(1..nCpn).

   The table for Gear1 in file "CouponStruct.dat" has maximum index
      nCpn, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nCpn elements,
      to be stored in Gear1(1..nCpn).

   The table for Gear2 in file "CouponStruct.dat" has maximum index
      nCpn, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nCpn elements,
      to be stored in Gear2(1..nCpn).

   The table for PaymentDates in file "CouponStruct.dat" has maximum index
      nCpn, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nCpn elements,
      to be stored in PaymentDates(1..nCpn).

   The table for Spread in file "CouponStruct.dat" has maximum index
      nCpn, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nCpn elements,
      to be stored in Spread(1..nCpn).

   The table for zDates in file "ZeroCurve.dat" has maximum index
      nZero, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nZero elements,
      to be stored in zDates(0..nZero).

   The table for zRates in file "ZeroCurve.dat" has maximum index
      nZero, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nZero elements,
      to be stored in zRates(0..nZero).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcG2CallCMSSnowbearNote1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcG2CallCMSSnowbearNote1MW
#define openfilemcG2CallCMSSnowbearNote1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcG2CallCMSSnowbearNote1MR
#define openfilemcG2CallCMSSnowbearNote1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcG2CallCMSSnowbearNote1M
#define fscanfMmcG2CallCMSSnowbearNote1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2

#undef spreadargs6
#define spreadargs6(a1,a2,a3,a4,a5,a6) a1,a2,a3,a4,a5,a6


int main()
{
    int itvar1,maxord1,maxord2,maxord3,nCMS,nCpn,nExer,nMax,nRst,nZero,pMax,Series;
    double CallPrice,CmsInitCoupon,kappa1,kappa2,Notional,PastCms,rho12,sigma1,sigma2,tauCMS,Vx;
    ArgumentRecord initInputTable[21];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4,*IOUNIT5;
    
    /* *** Key to program variables: *** */
    /* AccrualCms, CallPrice, CmsInitCoupon, CmsResetDates, ExerciseDates, Flr, Gear1, Gear2, kappa1, kappa2, maxord1,  
       maxord2, maxord3, nCMS, Notional, PastCms, PaymentDates, rho12, Series, sigma1, sigma2, Spread, tauCMS, zDates,  
       zRates: solution variable */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5: I/O channel */
    /* nCpn: array maximum for PaymentDates, Gear1, Gear2, Flr, Spread and AccrualCms */
    /* nExer: array maximum for ExerciseDates */
    /* nMax: number of grid cells for t */
    /* nRst: array maximum for CmsResetDates */
    /* nZero: array maximum for zDates and zRates */
    /* pMax: maximum for path */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcG2CallCMSSnowbearNote1MR(IOUNIT1,"init.dat");
    setupargs(initInputTable, 0, "CallPrice", CallPrice, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "CmsInitCoupon", CmsInitCoupon, READINPUTSDOUBLE);
    setupargs(initInputTable, 2, "kappa1", kappa1, READINPUTSDOUBLE);
    setupargs(initInputTable, 3, "kappa2", kappa2, READINPUTSDOUBLE);
    setupargs(initInputTable, 4, "maxord1", maxord1, READINPUTSINTEGER);
    setupargs(initInputTable, 5, "maxord2", maxord2, READINPUTSINTEGER);
    setupargs(initInputTable, 6, "maxord3", maxord3, READINPUTSINTEGER);
    setupargs(initInputTable, 7, "nCMS", nCMS, READINPUTSINTEGER);
    setupargs(initInputTable, 8, "nCpn", nCpn, READINPUTSINTEGER);
    setupargs(initInputTable, 9, "nExer", nExer, READINPUTSINTEGER);
    setupargs(initInputTable, 10, "nMax", nMax, READINPUTSINTEGER);
    setupargs(initInputTable, 11, "Notional", Notional, READINPUTSDOUBLE);
    setupargs(initInputTable, 12, "nRst", nRst, READINPUTSINTEGER);
    setupargs(initInputTable, 13, "nZero", nZero, READINPUTSINTEGER);
    setupargs(initInputTable, 14, "PastCms", PastCms, READINPUTSDOUBLE);
    setupargs(initInputTable, 15, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 16, "rho12", rho12, READINPUTSDOUBLE);
    setupargs(initInputTable, 17, "Series", Series, READINPUTSINTEGER);
    setupargs(initInputTable, 18, "sigma1", sigma1, READINPUTSDOUBLE);
    setupargs(initInputTable, 19, "sigma2", sigma2, READINPUTSDOUBLE);
    setupargs(initInputTable, 20, "tauCMS", tauCMS, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,initInputTable,21)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    /* Read CmsResetDates from file */
    SciArray1<double>CmsResetDates(nRst + 1);
    if (nRst>=1)
        {
        openfilemcG2CallCMSSnowbearNote1MR(IOUNIT2,"CmsResetDates.dat");
        for (itvar1=1; itvar1<=nRst; itvar1++) {
            fscanfMmcG2CallCMSSnowbearNote1M(IOUNIT2,"%lg",1,((&CmsResetDates(itvar1))));
        }
        fclose(IOUNIT2);
        }
    SciArray1<double>PaymentDates(nCpn + 1);
    SciArray1<double>Gear1(nCpn + 1);
    SciArray1<double>Gear2(nCpn + 1);
    SciArray1<double>Flr(nCpn + 1);
    SciArray1<double>Spread(nCpn + 1);
    SciArray1<double>AccrualCms(nCpn + 1);
    /* Read PaymentDates from file. Read Gear1 from file. Read Gear2 from file. Read Flr from file. Read Spread from    
       file. Read AccrualCms from file */
    if (nCpn>=1)
        {
        openfilemcG2CallCMSSnowbearNote1MR(IOUNIT3,"CouponStruct.dat");
        for (itvar1=1; itvar1<=nCpn; itvar1++) {
            fscanfMmcG2CallCMSSnowbearNote1M(IOUNIT3,
               "%lg%lg%lg%lg%lg%lg"
               ,6,((&PaymentDates(itvar1)),(&Gear1(itvar1)),(&Gear2(itvar1)),(&Flr(itvar1)),(&Spread(itvar1)),(
               &AccrualCms(itvar1))));
        }
        fclose(IOUNIT3);
        }
    /* Read ExerciseDates from file */
    SciArray1<double>ExerciseDates(nExer + 1);
    if (nExer>=1)
        {
        openfilemcG2CallCMSSnowbearNote1MR(IOUNIT4,"ExerciseDates.dat");
        for (itvar1=1; itvar1<=nExer; itvar1++) {
            fscanfMmcG2CallCMSSnowbearNote1M(IOUNIT4,"%lg",1,((&ExerciseDates(itvar1))));
        }
        fclose(IOUNIT4);
        }
    SciArray1<double>zDates(nZero + 1);
    SciArray1<double>zRates(nZero + 1);
    /* Read zDates from file. Read zRates from file */
    if (nZero>=0)
        {
        openfilemcG2CallCMSSnowbearNote1MR(IOUNIT5,"ZeroCurve.dat");
        for (itvar1=0; itvar1<=nZero; itvar1++) {
            fscanfMmcG2CallCMSSnowbearNote1M(IOUNIT5,"%lg%lg",2,((&zDates(itvar1)),(&zRates(itvar1))));
        }
        fclose(IOUNIT5);
        }
    /*                            */
    /* Call the computation function. */
    mcG2CallCMSSnowbearNote1fn(AccrualCms,CallPrice,CmsInitCoupon,CmsResetDates,ExerciseDates,Flr,Gear1,Gear2,kappa1,
       kappa2,maxord1,maxord2,maxord3,nCMS,nCpn,nExer,nMax,Notional,nRst,nZero,PastCms,PaymentDates,pMax,rho12,Series,
       sigma1,sigma2,Spread,tauCMS,zDates,zRates,Vx);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfilemcG2CallCMSSnowbearNote1MW(IOUNIT,"V.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




