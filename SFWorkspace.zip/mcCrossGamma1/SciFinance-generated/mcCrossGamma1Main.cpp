

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for D0 in file "D0.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in D0(1..nD).

   The table for loan in file "loan.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in loan(1..nD).

   The table for rho in file "rho.dat" has maximum indices
      nD and nD, 
     with minimum indices 1, 1 respectively.
      The index bounds are not read from this file.
        Following should be the nD^2 elements,
      to be stored in rho(1..nD, 1..nD).
   The first index is the most slowly varying and 
      the last index is the most rapidly varying.

   The table for sigma in file "sigma.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in sigma(1..nD).

   The table for Spot in file "Spot.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in Spot(1..nD).

   The table for weight in file "weight.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in weight(1..nD).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcCrossGamma1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcCrossGamma1MW
#define openfilemcCrossGamma1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcCrossGamma1MR
#define openfilemcCrossGamma1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcCrossGamma1M
#define fscanfMmcCrossGamma1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1


int main()
{
    int iD,itvar1,itvar2,nD,ndx1,pMax,Series;
    double disc,epsilon,K,TMax,Vx;
    ArgumentRecord initInputTable[7];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT10,*IOUNIT2,*IOUNIT3,*IOUNIT4,*IOUNIT5,*IOUNIT6,*IOUNIT7,*IOUNIT8,*IOUNIT9;
    
    /* *** Key to program variables: *** */
    /* D0, epsilon, K, loan, rho, Series, sigma, Spot, weight: solution variable */
    /* Delta: greek for der[V, {Spot, 1}] */
    /* disc: discount rate */
    /* Gamma: greek for der[V, {Spot, 2}] */
    /* iD: dependencies index */
    /* IOUNIT, IOUNIT1, IOUNIT10, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5, IOUNIT6, IOUNIT7, IOUNIT8, IOUNIT9: I/O channel */
    /* nD: maximum for iD */
    /* ndx1: local index */
    /* pMax: maximum for path */
    /* rhonew: temporary */
    /* TMax: maximum time */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcCrossGamma1MR(IOUNIT4,"init.dat");
    setupargs(initInputTable, 0, "disc", disc, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "epsilon", epsilon, READINPUTSDOUBLE);
    setupargs(initInputTable, 2, "K", K, READINPUTSDOUBLE);
    setupargs(initInputTable, 3, "nD", nD, READINPUTSINTEGER);
    setupargs(initInputTable, 4, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 5, "Series", Series, READINPUTSINTEGER);
    setupargs(initInputTable, 6, "TMax", TMax, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT4,initInputTable,7)!=0)
        {
        fclose(IOUNIT4);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT4);
    SciArray1<double>D0(nD + 1);
    SciArray2<double>rho(nD + 1, nD + 1);
    SciArray1<double>sigma(nD + 1);
    SciArray1<double>Spot(nD + 1);
    SciArray1<double>weight(nD + 1);
    SciArray1<double>loan(nD + 1);
    if (nD>=1)
        {
        /* Read D0 from file */
        openfilemcCrossGamma1MR(IOUNIT5,"D0.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCrossGamma1M(IOUNIT5,"%lg",1,((&D0(itvar1))));
        }
        fclose(IOUNIT5);
        /* Read rho from file */
        openfilemcCrossGamma1MR(IOUNIT6,"rho.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            for (itvar2=1; itvar2<=nD; itvar2++) {
                fscanfMmcCrossGamma1M(IOUNIT6,"%lg",1,((&rho(itvar1,itvar2))));
            }
        }
        fclose(IOUNIT6);
        /* Read sigma from file */
        openfilemcCrossGamma1MR(IOUNIT7,"sigma.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCrossGamma1M(IOUNIT7,"%lg",1,((&sigma(itvar1))));
        }
        fclose(IOUNIT7);
        /* Read Spot from file */
        openfilemcCrossGamma1MR(IOUNIT8,"Spot.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCrossGamma1M(IOUNIT8,"%lg",1,((&Spot(itvar1))));
        }
        fclose(IOUNIT8);
        /* Read weight from file */
        openfilemcCrossGamma1MR(IOUNIT9,"weight.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCrossGamma1M(IOUNIT9,"%lg",1,((&weight(itvar1))));
        }
        fclose(IOUNIT9);
        /* Read loan from file */
        openfilemcCrossGamma1MR(IOUNIT10,"loan.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCrossGamma1M(IOUNIT10,"%lg",1,((&loan(itvar1))));
        }
        fclose(IOUNIT10);
        }
    /*                            */
    /* Call the computation function. */
    SciArray1<double> Delta;
    SciArray2<double> Gamma;
    SciArray2<double> rhonew;
    mcCrossGamma1fn(D0,disc,epsilon,K,loan,nD,pMax,rho,Series,sigma,Spot,TMax,weight,Delta,Gamma,rhonew,Vx);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfilemcCrossGamma1MW(IOUNIT,"V.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* Writing collected output to file Delta.out from ResultEq1c. */
    openfilemcCrossGamma1MW(IOUNIT1,"Delta.out");
    for (iD=1; iD<=(int)Delta.size0() - 1; iD++) {
        fprintf(IOUNIT1, " %18.8e\n", Delta(iD));
    }
    fprintf(IOUNIT1, "\n");
    fclose(IOUNIT1);
    /* Writing collected output to file Gamma.out from ResultEq2c. */
    openfilemcCrossGamma1MW(IOUNIT2,"Gamma.out");
    for (iD=1; iD<=(int)Gamma.size0() - 1; iD++) {
        for (ndx1=1; ndx1<=(int)Gamma.size0() - 1; ndx1++) {
            fprintf(IOUNIT2, " %18.8e\n", Gamma(iD,ndx1));
        }
    }
    fprintf(IOUNIT2, "\n");
    fclose(IOUNIT2);
    /* Writing collected output to file rhonew.out from ResultEq3c. */
    openfilemcCrossGamma1MW(IOUNIT3,"rhonew.out");
    for (iD=1; iD<=(int)rhonew.size0() - 1; iD++) {
        for (ndx1=1; ndx1<=(int)rhonew.size0() - 1; ndx1++) {
            fprintf(IOUNIT3, " %18.8e\n", rhonew(iD,ndx1));
        }
    }
    fprintf(IOUNIT3, "\n");
    fclose(IOUNIT3);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




