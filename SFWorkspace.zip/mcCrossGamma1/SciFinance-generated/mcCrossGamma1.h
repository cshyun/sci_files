#ifndef MCCROSSGAMMA1_H
#define MCCROSSGAMMA1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcCrossGamma1fn(
    const SciArray1<double>& D0,
    double disc,
    double epsilon,
    double K,
    const SciArray1<double>& loan,
    int nD,
    int pMax,
    const SciArray2<double>& rho,
    int Series,
    const SciArray1<double>& sigma,
    const SciArray1<double>& Spot,
    double TMax,
    const SciArray1<double>& weight,
    SciArray1<double>& Deltax,
    SciArray2<double>& Gammax,
    SciArray2<double>& rhonewx,
    double & Vx
    );
     


#endif /* MCCROSSGAMMA1_H */
