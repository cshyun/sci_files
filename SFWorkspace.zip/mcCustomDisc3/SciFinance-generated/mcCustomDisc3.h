#ifndef MCCUSTOMDISC3_H
#define MCCUSTOMDISC3_H

#include "SciArrayN.h" /* SciComp arrays */

void mcCustomDisc3fn(
    double K,
    double kappa,
    double lambda,
    double muY,
    int nMax,
    int pMax,
    int put,
    double q,
    double r,
    double rhoSv,
    int Seed,
    double sigma,
    double sigY,
    double Spot,
    double theta,
    double TMax,
    double vSpot,
    double & devx,
    double & Vx
    );
     


#endif /* MCCUSTOMDISC3_H */
