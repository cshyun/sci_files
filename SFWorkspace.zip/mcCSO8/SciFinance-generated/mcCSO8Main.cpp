

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for CdsCurve in file "CdsCurves.dat" has maximum indices
      nD and ncds, 
     with minimum indices 1, 1 respectively.
      The index bounds are not read from this file.
        Following should be the ncds*nD elements,
      to be stored in CdsCurve(1..nD, 1..ncds).
   The first index is the most slowly varying and 
      the last index is the most rapidly varying.

   The table for CdsTCurve in file "CdsTCurve.dat" has maximum index
      ncds, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the ncds elements,
      to be stored in CdsTCurve(1..ncds).

   The table for CopR in file "CopR.dat" has maximum indices
      nD and nD, 
     with minimum indices 1, 1 respectively.
      The index bounds are not read from this file.
        Following should be the nD^2 elements,
      to be stored in CopR(1..nD, 1..nD).
   The first index is the most slowly varying and 
      the last index is the most rapidly varying.

   The table for Coup in file "Coup.dat" has maximum index
      4, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the 4 elements,
      to be stored in Coup(1..4).

   The table for Coupon in file "Coupon.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in Coupon(1..nD).

   The table for hDswitch in file "hDswitch.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in hDswitch(1..nD).

   The table for Load in file "Load.dat" has maximum index
      4, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the 4 elements,
      to be stored in Load(1..4).

   The table for Notional in file "Notional.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in Notional(1..nD).

   The table for Recovery in file "Recovery.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in Recovery(1..nD).

   The table for tC in file "tCoup.dat" has maximum index
      nC, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nC elements,
      to be stored in tC(1..nC).

   The table for TCurve in file "ZCurve.dat" has maximum index
      nZ, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nZ elements,
      to be stored in TCurve(1..nZ).

   The table for ZCurve in file "ZCurve.dat" has maximum index
      nZ, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nZ elements,
      to be stored in ZCurve(1..nZ).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcCSO8.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcCSO8MW
#define openfilemcCSO8MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcCSO8MR
#define openfilemcCSO8MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcCSO8M
#define fscanfMmcCSO8M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2


int main()
{
    int i,icov,iT,itvar1,itvar2,leap,nC,ncds,nD,nZ,pMax,sskip;
    double alpha,CdsBump,CdsInit,CdsInterval;
    ArgumentRecord initInputTable[11];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT10,*IOUNIT11,*IOUNIT12,*IOUNIT13,*IOUNIT14,*IOUNIT15,*IOUNIT16,*IOUNIT2,*IOUNIT3,*
       IOUNIT4,*IOUNIT5,*IOUNIT6,*IOUNIT7,*IOUNIT8,*IOUNIT9;
    
    /* *** Key to program variables: *** */
    /* alpha, CdsBump, CdsCurve, CdsInit, CdsInterval, CdsTCurve, CopR, Coup, Coupon, hDswitch, leap, Load, Notional,   
       Recovery, sskip, tC, TCurve, ZCurve: solution variable */
    /* DefaultedDefaultedMcCov: McCov value for Defaulted and  Defaulted */
    /* DefaultedMcAve: McAve value for Defaulted */
    /* DefaultedMcStd: McStd value for Defaulted */
    /* hDelta: greek for if[hDswitch, der[Note[2], {h, 1}], seq[]] */
    /* i: index variable for CopR */
    /* icov: index for McCov */
    /* IOUNIT, IOUNIT1, IOUNIT10, IOUNIT11, IOUNIT12, IOUNIT13, IOUNIT14, IOUNIT15, IOUNIT16, IOUNIT2, IOUNIT3, IOUNIT4,
       IOUNIT5, IOUNIT6, IOUNIT7, IOUNIT8, IOUNIT9: I/O channel */
    /* iT: vector index */
    /* nC: array maximum for tC */
    /* ncds: array maximum for CdsCurve and CdsTCurve */
    /* nD: maximum for icov */
    /* Note: discounted value */
    /* nZ: array maximum for ZCurve and TCurve */
    /* pMax: maximum for path */
    try {
    /* Read Tagged Input File */
    openfilemcCSO8MR(IOUNIT5,"init.dat");
    setupargs(initInputTable, 0, "alpha", alpha, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "CdsBump", CdsBump, READINPUTSDOUBLE);
    setupargs(initInputTable, 2, "CdsInit", CdsInit, READINPUTSDOUBLE);
    setupargs(initInputTable, 3, "CdsInterval", CdsInterval, READINPUTSDOUBLE);
    setupargs(initInputTable, 4, "leap", leap, READINPUTSINTEGER);
    setupargs(initInputTable, 5, "nC", nC, READINPUTSINTEGER);
    setupargs(initInputTable, 6, "ncds", ncds, READINPUTSINTEGER);
    setupargs(initInputTable, 7, "nD", nD, READINPUTSINTEGER);
    setupargs(initInputTable, 8, "nZ", nZ, READINPUTSINTEGER);
    setupargs(initInputTable, 9, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 10, "sskip", sskip, READINPUTSINTEGER);
    if (ReadInputs(IOUNIT5,initInputTable,11)!=0)
        {
        fclose(IOUNIT5);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT5);
    /* Read CdsCurve from file */
    SciArray2<double>CdsCurve(nD + 1, ncds + 1);
    if ((ncds>=1&&nD>=1))
        {
        openfilemcCSO8MR(IOUNIT6,"CdsCurves.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            for (itvar2=1; itvar2<=ncds; itvar2++) {
                fscanfMmcCSO8M(IOUNIT6,"%lg",1,((&CdsCurve(itvar1,itvar2))));
            }
        }
        fclose(IOUNIT6);
        }
    /* Read CdsTCurve from file */
    SciArray1<double>CdsTCurve(ncds + 1);
    if (ncds>=1)
        {
        openfilemcCSO8MR(IOUNIT7,"CdsTCurve.dat");
        for (itvar1=1; itvar1<=ncds; itvar1++) {
            fscanfMmcCSO8M(IOUNIT7,"%lg",1,((&CdsTCurve(itvar1))));
        }
        fclose(IOUNIT7);
        }
    /* Read CopR from file */
    SciArray2<double>CopR(nD + 1, nD + 1);
    if (nD>=1)
        {
        openfilemcCSO8MR(IOUNIT8,"CopR.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            for (itvar2=1; itvar2<=nD; itvar2++) {
                fscanfMmcCSO8M(IOUNIT8,"%lg",1,((&CopR(itvar1,itvar2))));
            }
        }
        fclose(IOUNIT8);
        }
    /* Read Coup from file */
    openfilemcCSO8MR(IOUNIT9,"Coup.dat");
    SciArray1<double>Coup(5);
    for (itvar1=1; itvar1<=4; itvar1++) {
        fscanfMmcCSO8M(IOUNIT9,"%lg",1,((&Coup(itvar1))));
    }
    fclose(IOUNIT9);
    SciArray1<double>Coupon(nD + 1);
    SciArray1<int>hDswitch(nD + 1);
    if (nD>=1)
        {
        /* Read Coupon from file */
        openfilemcCSO8MR(IOUNIT10,"Coupon.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCSO8M(IOUNIT10,"%lg",1,((&Coupon(itvar1))));
        }
        fclose(IOUNIT10);
        /* Read hDswitch from file */
        openfilemcCSO8MR(IOUNIT11,"hDswitch.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCSO8M(IOUNIT11,"%i",1,((&hDswitch(itvar1))));
        }
        fclose(IOUNIT11);
        }
    /* Read Load from file */
    openfilemcCSO8MR(IOUNIT12,"Load.dat");
    SciArray1<double>Load(5);
    for (itvar1=1; itvar1<=4; itvar1++) {
        fscanfMmcCSO8M(IOUNIT12,"%lg",1,((&Load(itvar1))));
    }
    fclose(IOUNIT12);
    SciArray1<double>Notional(nD + 1);
    SciArray1<double>Recovery(nD + 1);
    if (nD>=1)
        {
        /* Read Notional from file */
        openfilemcCSO8MR(IOUNIT13,"Notional.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCSO8M(IOUNIT13,"%lg",1,((&Notional(itvar1))));
        }
        fclose(IOUNIT13);
        /* Read Recovery from file */
        openfilemcCSO8MR(IOUNIT14,"Recovery.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCSO8M(IOUNIT14,"%lg",1,((&Recovery(itvar1))));
        }
        fclose(IOUNIT14);
        }
    /* Read tC from file */
    SciArray1<double>tC(nC + 1);
    if (nC>=1)
        {
        openfilemcCSO8MR(IOUNIT15,"tCoup.dat");
        for (itvar1=1; itvar1<=nC; itvar1++) {
            fscanfMmcCSO8M(IOUNIT15,"%lg",1,((&tC(itvar1))));
        }
        fclose(IOUNIT15);
        }
    SciArray1<double>ZCurve(nZ + 1);
    SciArray1<double>TCurve(nZ + 1);
    /* Read ZCurve from file. Read TCurve from file */
    if (nZ>=1)
        {
        openfilemcCSO8MR(IOUNIT16,"ZCurve.dat");
        for (itvar1=1; itvar1<=nZ; itvar1++) {
            fscanfMmcCSO8M(IOUNIT16,"%lg%lg",2,((&ZCurve(itvar1)),(&TCurve(itvar1))));
        }
        fclose(IOUNIT16);
        }
    /*                            */
    /* Call the computation function. */
    SciArray2<double> DefaultedDefaultedMcCov;
    SciArray1<double> DefaultedMcAve;
    SciArray1<double> DefaultedMcStd;
    SciArray1<double> hDelta;
    SciArray1<double> Note;
    mcCSO8fn(alpha,CdsBump,CdsCurve,CdsInit,CdsInterval,CdsTCurve,CopR,Coup,Coupon,hDswitch,leap,Load,nC,ncds,nD,
       Notional,nZ,pMax,Recovery,sskip,tC,TCurve,ZCurve,DefaultedDefaultedMcCov,DefaultedMcAve,DefaultedMcStd,hDelta,
       Note);
    /*                            */
    /* Writing collected output to file Notes.out from ResultEqc. */
    openfilemcCSO8MW(IOUNIT,"Notes.out");
    for (iT=1; iT<=4; iT++) {
        fprintf(IOUNIT, " %18.8e\n", Note(iT));
    }
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* Writing collected output to file hDelta.out from ResultEq1c. */
    openfilemcCSO8MW(IOUNIT1,"hDelta.out");
    for (i=1; i<=(int)hDelta.size0() - 1; i++) {
        fprintf(IOUNIT1, " %18.8e\n", hDelta(i));
    }
    fprintf(IOUNIT1, "\n");
    fclose(IOUNIT1);
    /* Writing collected output to file DefaultedMcAve.out from ResultEq2c. */
    openfilemcCSO8MW(IOUNIT2,"DefaultedMcAve.out");
    for (i=1; i<=(int)DefaultedMcAve.size0() - 1; i++) {
        fprintf(IOUNIT2, " %18.8e\n", DefaultedMcAve(i));
    }
    fprintf(IOUNIT2, "\n");
    fclose(IOUNIT2);
    /* Writing collected output to file DefaultedMcStd.out from ResultEq3c. */
    openfilemcCSO8MW(IOUNIT3,"DefaultedMcStd.out");
    for (i=1; i<=(int)DefaultedMcStd.size0() - 1; i++) {
        fprintf(IOUNIT3, " %18.8e\n", DefaultedMcStd(i));
    }
    fprintf(IOUNIT3, "\n");
    fclose(IOUNIT3);
    /* Writing collected output to file DefaultedDefaultedMcCov.out from ResultEq4c. */
    openfilemcCSO8MW(IOUNIT4,"DefaultedDefaultedMcCov.out");
    for (i=1; i<=(int)DefaultedDefaultedMcCov.size0() - 1; i++) {
        for (icov=1; icov<=(int)DefaultedDefaultedMcCov.size0() - 1; icov++) {
            fprintf(IOUNIT4, " %18.8e\n", DefaultedDefaultedMcCov(i,icov));
        }
    }
    fprintf(IOUNIT4, "\n");
    fclose(IOUNIT4);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




