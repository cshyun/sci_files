#ifndef MCCSO8_H
#define MCCSO8_H

#include "SciArrayN.h" /* SciComp arrays */

void mcCSO8fn(
    double alpha,
    double CdsBump,
    const SciArray2<double>& CdsCurve,
    double CdsInit,
    double CdsInterval,
    const SciArray1<double>& CdsTCurve,
    const SciArray2<double>& CopR,
    const SciArray1<double>& Coup,
    const SciArray1<double>& Coupon,
    const SciArray1<int>& hDswitch,
    int leap,
    const SciArray1<double>& Load,
    int nC,
    int ncds,
    int nD,
    const SciArray1<double>& Notional,
    int nZ,
    int pMax,
    const SciArray1<double>& Recovery,
    int sskip,
    const SciArray1<double>& tC,
    const SciArray1<double>& TCurve,
    const SciArray1<double>& ZCurve,
    SciArray2<double>& DefaultedDefaultedMcCovx,
    SciArray1<double>& DefaultedMcAvex,
    SciArray1<double>& DefaultedMcStdx,
    SciArray1<double>& hDeltax,
    SciArray1<double>& Notex
    );
     


#endif /* MCCSO8_H */
