



#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcAveStrike2.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcAveStrike2MW
#define openfilemcAveStrike2MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcAveStrike2MR
#define openfilemcAveStrike2MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcAveStrike2M
#define fscanfMmcAveStrike2M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }



int main()
{
    int nsampSoFar,nsampToGo,pMax,pMaxI,Series;
    ArgumentRecord initInputTable[12];
    FILE *IOUNIT,*IOUNIT1;
    double lastA,q,r,sigma,Spot,TMax,Vx;
    int put;
    
    /* *** Key to program variables: *** */
    /* IOUNIT, IOUNIT1: I/O channel */
    /* lastA, nsampSoFar, nsampToGo, put, q, Series, sigma, Spot: solution variable */
    /* pMax: maximum for path */
    /* pMaxI: maximum for pathI */
    /* r: discount rate */
    /* TMax: maximum time */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcAveStrike2MR(IOUNIT1,"init.dat");
    setupargs(initInputTable, 0, "lastA", lastA, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "nsampSoFar", nsampSoFar, READINPUTSINTEGER);
    setupargs(initInputTable, 2, "nsampToGo", nsampToGo, READINPUTSINTEGER);
    setupargs(initInputTable, 3, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 4, "pMaxI", pMaxI, READINPUTSINTEGER);
    setupargs(initInputTable, 5, "put", put, READINPUTSBOOLEAN);
    setupargs(initInputTable, 6, "q", q, READINPUTSDOUBLE);
    setupargs(initInputTable, 7, "r", r, READINPUTSDOUBLE);
    setupargs(initInputTable, 8, "Series", Series, READINPUTSINTEGER);
    setupargs(initInputTable, 9, "sigma", sigma, READINPUTSDOUBLE);
    setupargs(initInputTable, 10, "Spot", Spot, READINPUTSDOUBLE);
    setupargs(initInputTable, 11, "TMax", TMax, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,initInputTable,12)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    /*                            */
    /* Call the computation function. */
    mcAveStrike2fn(lastA,nsampSoFar,nsampToGo,pMax,pMaxI,put,q,r,Series,sigma,Spot,TMax,Vx);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfilemcAveStrike2MW(IOUNIT,"V.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




