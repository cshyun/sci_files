#ifndef MCAVESTRIKE2_H
#define MCAVESTRIKE2_H

#include "SciArrayN.h" /* SciComp arrays */

void mcAveStrike2fn(
    double lastA,
    int nsampSoFar,
    int nsampToGo,
    int pMax,
    int pMaxI,
    int put,
    double q,
    double r,
    int Series,
    double sigma,
    double Spot,
    double TMax,
    double & Vx
    );
     


#endif /* MCAVESTRIKE2_H */
