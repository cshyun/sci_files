#ifndef MCG1RATCHETCAP1_H
#define MCG1RATCHETCAP1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcG1RatchetCap1fn(
    const SciArray1<double>& Gear,
    double kappa,
    int nCpn,
    int nMax,
    double Notional,
    int nRst,
    int nZero,
    double PastLibor,
    const SciArray1<double>& PaymentDates,
    int pMax,
    double PrevStrike,
    const SciArray1<double>& Ratchet,
    const SciArray1<double>& ResetDates,
    int Series,
    double sigma,
    const SciArray1<double>& Spread,
    double tau,
    const SciArray1<double>& zDates,
    const SciArray1<double>& zRates,
    double & Vx
    );
     


#endif /* MCG1RATCHETCAP1_H */
