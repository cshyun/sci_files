

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for Gear in file "CouponStruct.dat" has maximum index
      nCpn, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nCpn elements,
      to be stored in Gear(1..nCpn).

   The table for PaymentDates in file "CouponStruct.dat" has maximum index
      nCpn, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nCpn elements,
      to be stored in PaymentDates(1..nCpn).

   The table for Ratchet in file "CouponStruct.dat" has maximum index
      nCpn, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nCpn elements,
      to be stored in Ratchet(1..nCpn).

   The table for ResetDates in file "ResetDates.dat" has maximum index
      nRst, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nRst elements,
      to be stored in ResetDates(1..nRst).

   The table for Spread in file "CouponStruct.dat" has maximum index
      nCpn, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nCpn elements,
      to be stored in Spread(1..nCpn).

   The table for zDates in file "ZeroCurve.dat" has maximum index
      nZero, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nZero elements,
      to be stored in zDates(0..nZero).

   The table for zRates in file "ZeroCurve.dat" has maximum index
      nZero, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nZero elements,
      to be stored in zRates(0..nZero).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcG1RatchetCap1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcG1RatchetCap1MW
#define openfilemcG1RatchetCap1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcG1RatchetCap1MR
#define openfilemcG1RatchetCap1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcG1RatchetCap1M
#define fscanfMmcG1RatchetCap1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2

#undef spreadargs4
#define spreadargs4(a1,a2,a3,a4) a1,a2,a3,a4


int main()
{
    int itvar1,nCpn,nMax,nRst,nZero,pMax,Series;
    ArgumentRecord initInputTable[12];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4;
    double kappa,Notional,PastLibor,PrevStrike,sigma,tau,Vx;
    
    /* *** Key to program variables: *** */
    /* Gear, kappa, Notional, PastLibor, PaymentDates, PrevStrike, Ratchet, ResetDates, Series, sigma, Spread, tau,     
       zDates, zRates: solution variable */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4: I/O channel */
    /* nCpn: array maximum for PaymentDates, Gear, Spread and Ratchet */
    /* nMax: number of grid cells for t */
    /* nRst: array maximum for ResetDates */
    /* nZero: array maximum for zDates and zRates */
    /* pMax: maximum for path */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcG1RatchetCap1MR(IOUNIT1,"init.dat");
    setupargs(initInputTable, 0, "kappa", kappa, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "nCpn", nCpn, READINPUTSINTEGER);
    setupargs(initInputTable, 2, "nMax", nMax, READINPUTSINTEGER);
    setupargs(initInputTable, 3, "Notional", Notional, READINPUTSDOUBLE);
    setupargs(initInputTable, 4, "nRst", nRst, READINPUTSINTEGER);
    setupargs(initInputTable, 5, "nZero", nZero, READINPUTSINTEGER);
    setupargs(initInputTable, 6, "PastLibor", PastLibor, READINPUTSDOUBLE);
    setupargs(initInputTable, 7, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 8, "PrevStrike", PrevStrike, READINPUTSDOUBLE);
    setupargs(initInputTable, 9, "Series", Series, READINPUTSINTEGER);
    setupargs(initInputTable, 10, "sigma", sigma, READINPUTSDOUBLE);
    setupargs(initInputTable, 11, "tau", tau, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,initInputTable,12)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    SciArray1<double>PaymentDates(nCpn + 1);
    SciArray1<double>Gear(nCpn + 1);
    SciArray1<double>Spread(nCpn + 1);
    SciArray1<double>Ratchet(nCpn + 1);
    /* Read PaymentDates from file. Read Gear from file. Read Spread from file. Read Ratchet from file */
    if (nCpn>=1)
        {
        openfilemcG1RatchetCap1MR(IOUNIT2,"CouponStruct.dat");
        for (itvar1=1; itvar1<=nCpn; itvar1++) {
            fscanfMmcG1RatchetCap1M(IOUNIT2,
               "%lg%lg%lg%lg",4,((&PaymentDates(itvar1)),(&Gear(itvar1)),(&Spread(itvar1)),(&Ratchet(itvar1))));
        }
        fclose(IOUNIT2);
        }
    /* Read ResetDates from file */
    SciArray1<double>ResetDates(nRst + 1);
    if (nRst>=1)
        {
        openfilemcG1RatchetCap1MR(IOUNIT3,"ResetDates.dat");
        for (itvar1=1; itvar1<=nRst; itvar1++) {
            fscanfMmcG1RatchetCap1M(IOUNIT3,"%lg",1,((&ResetDates(itvar1))));
        }
        fclose(IOUNIT3);
        }
    SciArray1<double>zDates(nZero + 1);
    SciArray1<double>zRates(nZero + 1);
    /* Read zDates from file. Read zRates from file */
    if (nZero>=0)
        {
        openfilemcG1RatchetCap1MR(IOUNIT4,"ZeroCurve.dat");
        for (itvar1=0; itvar1<=nZero; itvar1++) {
            fscanfMmcG1RatchetCap1M(IOUNIT4,"%lg%lg",2,((&zDates(itvar1)),(&zRates(itvar1))));
        }
        fclose(IOUNIT4);
        }
    /*                            */
    /* Call the computation function. */
    mcG1RatchetCap1fn(Gear,kappa,nCpn,nMax,Notional,nRst,nZero,PastLibor,PaymentDates,pMax,PrevStrike,Ratchet,ResetDates
       ,Series,sigma,Spread,tau,zDates,zRates,Vx);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfilemcG1RatchetCap1MW(IOUNIT,"V.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




