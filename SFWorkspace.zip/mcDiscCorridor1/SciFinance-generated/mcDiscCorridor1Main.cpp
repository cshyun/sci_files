

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for LBDates in file "LBarrier.dat" has maximum index
      nLBar, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nLBar elements,
      to be stored in LBDates(1..nLBar).

   The table for LBLevels in file "LBarrier.dat" has maximum index
      nLBar, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nLBar elements,
      to be stored in LBLevels(1..nLBar).

   The table for LBRebates in file "LBarrier.dat" has maximum index
      nLBar, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nLBar elements,
      to be stored in LBRebates(1..nLBar).

   The table for tsamp in file "tsamp.dat" has maximum index
      nsamp, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nsamp elements,
      to be stored in tsamp(1..nsamp).

   The table for UBDates in file "UBarrier.dat" has maximum index
      nUBar, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nUBar elements,
      to be stored in UBDates(1..nUBar).

   The table for UBLevels in file "UBarrier.dat" has maximum index
      nUBar, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nUBar elements,
      to be stored in UBLevels(1..nUBar).

   The table for UBRebates in file "UBarrier.dat" has maximum index
      nUBar, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nUBar elements,
      to be stored in UBRebates(1..nUBar).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcDiscCorridor1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcDiscCorridor1MW
#define openfilemcDiscCorridor1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcDiscCorridor1MR
#define openfilemcDiscCorridor1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcDiscCorridor1M
#define fscanfMmcDiscCorridor1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs3
#define spreadargs3(a1,a2,a3) a1,a2,a3


int main()
{
    int itvar1,nLBar,nsamp,nUBar,pMax,Seed;
    double devx,K,q,r,sigma,Spot,TMax,Vx;
    ArgumentRecord initInputTable[12];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4;
    int put;
    
    /* *** Key to program variables: *** */
    /* devx: standard deviation error estimate */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4: I/O channel */
    /* K, LBDates, LBLevels, LBRebates, put, q, Seed, sigma, Spot, tsamp, UBDates, UBLevels, UBRebates: solution        
       variable */
    /* nLBar: array maximum for LBDates, LBLevels and LBRebates */
    /* nsamp: array maximum for tsamp */
    /* nUBar: array maximum for UBDates, UBLevels and UBRebates */
    /* pMax: maximum for path */
    /* r: discount rate */
    /* TMax: maximum time */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcDiscCorridor1MR(IOUNIT1,"init.dat");
    setupargs(initInputTable, 0, "K", K, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "nLBar", nLBar, READINPUTSINTEGER);
    setupargs(initInputTable, 2, "nsamp", nsamp, READINPUTSINTEGER);
    setupargs(initInputTable, 3, "nUBar", nUBar, READINPUTSINTEGER);
    setupargs(initInputTable, 4, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 5, "put", put, READINPUTSBOOLEAN);
    setupargs(initInputTable, 6, "q", q, READINPUTSDOUBLE);
    setupargs(initInputTable, 7, "r", r, READINPUTSDOUBLE);
    setupargs(initInputTable, 8, "Seed", Seed, READINPUTSINTEGER);
    setupargs(initInputTable, 9, "sigma", sigma, READINPUTSDOUBLE);
    setupargs(initInputTable, 10, "Spot", Spot, READINPUTSDOUBLE);
    setupargs(initInputTable, 11, "TMax", TMax, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,initInputTable,12)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    SciArray1<double>LBDates(nLBar + 1);
    SciArray1<double>LBLevels(nLBar + 1);
    SciArray1<double>LBRebates(nLBar + 1);
    /* Read LBDates from file. Read LBLevels from file. Read LBRebates from file */
    if (nLBar>=1)
        {
        openfilemcDiscCorridor1MR(IOUNIT2,"LBarrier.dat");
        for (itvar1=1; itvar1<=nLBar; itvar1++) {
            fscanfMmcDiscCorridor1M(IOUNIT2,
               "%lg%lg%lg",3,((&LBDates(itvar1)),(&LBLevels(itvar1)),(&LBRebates(itvar1))));
        }
        fclose(IOUNIT2);
        }
    /* Read tsamp from file */
    SciArray1<double>tsamp(nsamp + 1);
    if (nsamp>=1)
        {
        openfilemcDiscCorridor1MR(IOUNIT3,"tsamp.dat");
        for (itvar1=1; itvar1<=nsamp; itvar1++) {
            fscanfMmcDiscCorridor1M(IOUNIT3,"%lg",1,((&tsamp(itvar1))));
        }
        fclose(IOUNIT3);
        }
    SciArray1<double>UBDates(nUBar + 1);
    SciArray1<double>UBLevels(nUBar + 1);
    SciArray1<double>UBRebates(nUBar + 1);
    /* Read UBDates from file. Read UBLevels from file. Read UBRebates from file */
    if (nUBar>=1)
        {
        openfilemcDiscCorridor1MR(IOUNIT4,"UBarrier.dat");
        for (itvar1=1; itvar1<=nUBar; itvar1++) {
            fscanfMmcDiscCorridor1M(IOUNIT4,
               "%lg%lg%lg",3,((&UBDates(itvar1)),(&UBLevels(itvar1)),(&UBRebates(itvar1))));
        }
        fclose(IOUNIT4);
        }
    /*                            */
    /* Call the computation function. */
    mcDiscCorridor1fn(K,LBDates,LBLevels,LBRebates,nLBar,nsamp,nUBar,pMax,put,q,r,Seed,sigma,Spot,TMax,tsamp,UBDates,
       UBLevels,UBRebates,devx,Vx);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfilemcDiscCorridor1MW(IOUNIT,"V.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file V.out from ResultEq1c. */
    fprintf(IOUNIT, " %18.8e\n", devx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




