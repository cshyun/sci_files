#ifndef MCDISCCORRIDOR1_H
#define MCDISCCORRIDOR1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcDiscCorridor1fn(
    double K,
    const SciArray1<double>& LBDates,
    const SciArray1<double>& LBLevels,
    const SciArray1<double>& LBRebates,
    int nLBar,
    int nsamp,
    int nUBar,
    int pMax,
    int put,
    double q,
    double r,
    int Seed,
    double sigma,
    double Spot,
    double TMax,
    const SciArray1<double>& tsamp,
    const SciArray1<double>& UBDates,
    const SciArray1<double>& UBLevels,
    const SciArray1<double>& UBRebates,
    double & devx,
    double & Vx
    );
     


#endif /* MCDISCCORRIDOR1_H */
