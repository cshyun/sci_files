

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for Rhorr in file "Rhorr.dat" has maximum indices
      3 and 3, 
     with minimum indices 1, 1 respectively.
      The index bounds are not read from this file.
        Following should be the 9 elements,
      to be stored in Rhorr(1..3, 1..3).
   The first index is the most slowly varying and 
      the last index is the most rapidly varying.

   The table for RhoXr in file "RhoXr.dat" has maximum indices
      2 and 3, 
     with minimum indices 1, 1 respectively.
      The index bounds are not read from this file.
        Following should be the 6 elements,
      to be stored in RhoXr(1..2, 1..3).
   The first index is the most slowly varying and 
      the last index is the most rapidly varying.

   The table for RhoXX in file "RhoXX.dat" has maximum indices
      2 and 2, 
     with minimum indices 1, 1 respectively.
      The index bounds are not read from this file.
        Following should be the 4 elements,
      to be stored in RhoXX(1..2, 1..2).
   The first index is the most slowly varying and 
      the last index is the most rapidly varying.

   The table for volParams1 in file "volParams1.dat" has maximum index
      nvP1, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nvP1 elements,
      to be stored in volParams1(1..nvP1).

   The table for volParams2 in file "volParams2.dat" has maximum index
      nvP2, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nvP2 elements,
      to be stored in volParams2(1..nvP2).

   The table for ZeroDatesD in file "ZCurveD.dat" has maximum index
      nZCD, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nZCD elements,
      to be stored in ZeroDatesD(0..nZCD).

   The table for ZeroDatesF1 in file "ZCurveF1.dat" has maximum index
      nZCF1, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nZCF1 elements,
      to be stored in ZeroDatesF1(0..nZCF1).

   The table for ZeroDatesF2 in file "ZCurveF2.dat" has maximum index
      nZCF2, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nZCF2 elements,
      to be stored in ZeroDatesF2(0..nZCF2).

   The table for ZeroRatesD in file "ZCurveD.dat" has maximum index
      nZCD, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nZCD elements,
      to be stored in ZeroRatesD(0..nZCD).

   The table for ZeroRatesF1 in file "ZCurveF1.dat" has maximum index
      nZCF1, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nZCF1 elements,
      to be stored in ZeroRatesF1(0..nZCF1).

   The table for ZeroRatesF2 in file "ZCurveF2.dat" has maximum index
      nZCF2, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nZCF2 elements,
      to be stored in ZeroRatesF2(0..nZCF2).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcFXCrossBarrier1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcFXCrossBarrier1MW
#define openfilemcFXCrossBarrier1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcFXCrossBarrier1MR
#define openfilemcFXCrossBarrier1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcFXCrossBarrier1M
#define fscanfMmcFXCrossBarrier1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2


int main()
{
    int itvar1,itvar2,nMax,nSD,nvP1,nvP2,nZCD,nZCF1,nZCF2,pMax,Series;
    double B,Delta1x,Delta2x,FX10,FX20,FXbump,Gamma12x,Gamma1x,Gamma2x,K,kapparD,kapparF1,kapparF2,Rebate,sigmarD,
       sigmarF1,sigmarF2,TMax,Vx;
    int calcGreeks,call,deferred,in,up;
    ArgumentRecord initInputTable[27];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT10,*IOUNIT2,*IOUNIT3,*IOUNIT4,*IOUNIT5,*IOUNIT6,*IOUNIT7,*IOUNIT8,*IOUNIT9;
    
    /* *** Key to program variables: *** */
    /* B, calcGreeks, call, deferred, Delta1x, Delta2x, FX10, FX20, FXbump, Gamma12x, Gamma1x, Gamma2x, in, K, kapparD, 
       kapparF1, kapparF2, nSD, Rebate, Rhorr, RhoXr, RhoXX, Series, sigmarD, sigmarF1, sigmarF2, up, volParams1,       
       volParams2, ZeroDatesD, ZeroDatesF1, ZeroDatesF2, ZeroRatesD, ZeroRatesF1, ZeroRatesF2: solution variable */
    /* IOUNIT, IOUNIT1, IOUNIT10, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5, IOUNIT6, IOUNIT7, IOUNIT8, IOUNIT9: I/O channel */
    /* nMax: number of grid cells for t */
    /* nvP1: array maximum for volParams1 */
    /* nvP2: array maximum for volParams2 */
    /* nZCD: array maximum for ZeroDatesD and ZeroRatesD */
    /* nZCF1: array maximum for ZeroDatesF1 and ZeroRatesF1 */
    /* nZCF2: array maximum for ZeroDatesF2 and ZeroRatesF2 */
    /* pMax: maximum for path */
    /* TMax: maximum time */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcFXCrossBarrier1MR(IOUNIT2,"init.dat");
    setupargs(initInputTable, 0, "B", B, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "calcGreeks", calcGreeks, READINPUTSBOOLEAN);
    setupargs(initInputTable, 2, "call", call, READINPUTSBOOLEAN);
    setupargs(initInputTable, 3, "deferred", deferred, READINPUTSBOOLEAN);
    setupargs(initInputTable, 4, "FX10", FX10, READINPUTSDOUBLE);
    setupargs(initInputTable, 5, "FX20", FX20, READINPUTSDOUBLE);
    setupargs(initInputTable, 6, "FXbump", FXbump, READINPUTSDOUBLE);
    setupargs(initInputTable, 7, "in", in, READINPUTSBOOLEAN);
    setupargs(initInputTable, 8, "K", K, READINPUTSDOUBLE);
    setupargs(initInputTable, 9, "kapparD", kapparD, READINPUTSDOUBLE);
    setupargs(initInputTable, 10, "kapparF1", kapparF1, READINPUTSDOUBLE);
    setupargs(initInputTable, 11, "kapparF2", kapparF2, READINPUTSDOUBLE);
    setupargs(initInputTable, 12, "nMax", nMax, READINPUTSINTEGER);
    setupargs(initInputTable, 13, "nSD", nSD, READINPUTSINTEGER);
    setupargs(initInputTable, 14, "nvP1", nvP1, READINPUTSINTEGER);
    setupargs(initInputTable, 15, "nvP2", nvP2, READINPUTSINTEGER);
    setupargs(initInputTable, 16, "nZCD", nZCD, READINPUTSINTEGER);
    setupargs(initInputTable, 17, "nZCF1", nZCF1, READINPUTSINTEGER);
    setupargs(initInputTable, 18, "nZCF2", nZCF2, READINPUTSINTEGER);
    setupargs(initInputTable, 19, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 20, "Rebate", Rebate, READINPUTSDOUBLE);
    setupargs(initInputTable, 21, "Series", Series, READINPUTSINTEGER);
    setupargs(initInputTable, 22, "sigmarD", sigmarD, READINPUTSDOUBLE);
    setupargs(initInputTable, 23, "sigmarF1", sigmarF1, READINPUTSDOUBLE);
    setupargs(initInputTable, 24, "sigmarF2", sigmarF2, READINPUTSDOUBLE);
    setupargs(initInputTable, 25, "TMax", TMax, READINPUTSDOUBLE);
    setupargs(initInputTable, 26, "up", up, READINPUTSBOOLEAN);
    if (ReadInputs(IOUNIT2,initInputTable,27)!=0)
        {
        fclose(IOUNIT2);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT2);
    /* Read Rhorr from file */
    openfilemcFXCrossBarrier1MR(IOUNIT3,"Rhorr.dat");
    SciArray2<double>Rhorr(4, 4);
    for (itvar1=1; itvar1<=3; itvar1++) {
        for (itvar2=1; itvar2<=3; itvar2++) {
            fscanfMmcFXCrossBarrier1M(IOUNIT3,"%lg",1,((&Rhorr(itvar1,itvar2))));
        }
    }
    fclose(IOUNIT3);
    /* Read RhoXr from file */
    openfilemcFXCrossBarrier1MR(IOUNIT4,"RhoXr.dat");
    SciArray2<double>RhoXr(3, 4);
    for (itvar1=1; itvar1<=2; itvar1++) {
        for (itvar2=1; itvar2<=3; itvar2++) {
            fscanfMmcFXCrossBarrier1M(IOUNIT4,"%lg",1,((&RhoXr(itvar1,itvar2))));
        }
    }
    fclose(IOUNIT4);
    /* Read RhoXX from file */
    openfilemcFXCrossBarrier1MR(IOUNIT5,"RhoXX.dat");
    SciArray2<double>RhoXX(3, 3);
    for (itvar1=1; itvar1<=2; itvar1++) {
        for (itvar2=1; itvar2<=2; itvar2++) {
            fscanfMmcFXCrossBarrier1M(IOUNIT5,"%lg",1,((&RhoXX(itvar1,itvar2))));
        }
    }
    fclose(IOUNIT5);
    /* Read volParams1 from file */
    SciArray1<double>volParams1(nvP1 + 1);
    if (nvP1>=1)
        {
        openfilemcFXCrossBarrier1MR(IOUNIT6,"volParams1.dat");
        for (itvar1=1; itvar1<=nvP1; itvar1++) {
            fscanfMmcFXCrossBarrier1M(IOUNIT6,"%lg",1,((&volParams1(itvar1))));
        }
        fclose(IOUNIT6);
        }
    /* Read volParams2 from file */
    SciArray1<double>volParams2(nvP2 + 1);
    if (nvP2>=1)
        {
        openfilemcFXCrossBarrier1MR(IOUNIT7,"volParams2.dat");
        for (itvar1=1; itvar1<=nvP2; itvar1++) {
            fscanfMmcFXCrossBarrier1M(IOUNIT7,"%lg",1,((&volParams2(itvar1))));
        }
        fclose(IOUNIT7);
        }
    SciArray1<double>ZeroDatesD(nZCD + 1);
    SciArray1<double>ZeroRatesD(nZCD + 1);
    /* Read ZeroDatesD from file. Read ZeroRatesD from file */
    if (nZCD>=0)
        {
        openfilemcFXCrossBarrier1MR(IOUNIT8,"ZCurveD.dat");
        for (itvar1=0; itvar1<=nZCD; itvar1++) {
            fscanfMmcFXCrossBarrier1M(IOUNIT8,"%lg%lg",2,((&ZeroDatesD(itvar1)),(&ZeroRatesD(itvar1))));
        }
        fclose(IOUNIT8);
        }
    SciArray1<double>ZeroDatesF1(nZCF1 + 1);
    SciArray1<double>ZeroRatesF1(nZCF1 + 1);
    /* Read ZeroDatesF1 from file. Read ZeroRatesF1 from file */
    if (nZCF1>=0)
        {
        openfilemcFXCrossBarrier1MR(IOUNIT9,"ZCurveF1.dat");
        for (itvar1=0; itvar1<=nZCF1; itvar1++) {
            fscanfMmcFXCrossBarrier1M(IOUNIT9,"%lg%lg",2,((&ZeroDatesF1(itvar1)),(&ZeroRatesF1(itvar1))));
        }
        fclose(IOUNIT9);
        }
    SciArray1<double>ZeroDatesF2(nZCF2 + 1);
    SciArray1<double>ZeroRatesF2(nZCF2 + 1);
    /* Read ZeroDatesF2 from file. Read ZeroRatesF2 from file */
    if (nZCF2>=0)
        {
        openfilemcFXCrossBarrier1MR(IOUNIT10,"ZCurveF2.dat");
        for (itvar1=0; itvar1<=nZCF2; itvar1++) {
            fscanfMmcFXCrossBarrier1M(IOUNIT10,"%lg%lg",2,((&ZeroDatesF2(itvar1)),(&ZeroRatesF2(itvar1))));
        }
        fclose(IOUNIT10);
        }
    /*                            */
    /* Call the computation function. */
    mcFXCrossBarrier1fn(B,calcGreeks,call,deferred,Delta1x,Delta2x,FX10,FX20,FXbump,Gamma12x,Gamma1x,Gamma2x,in,K,
       kapparD,kapparF1,kapparF2,nMax,nSD,nvP1,nvP2,nZCD,nZCF1,nZCF2,pMax,Rebate,Rhorr,RhoXr,RhoXX,Series,sigmarD,
       sigmarF1,sigmarF2,TMax,up,volParams1,volParams2,ZeroDatesD,ZeroDatesF1,ZeroDatesF2,ZeroRatesD,ZeroRatesF1,
       ZeroRatesF2,Vx);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfilemcFXCrossBarrier1MW(IOUNIT,"V.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* Writing collected output to file Greeks.out from ResultEq1c. */
    openfilemcFXCrossBarrier1MW(IOUNIT1,"Greeks.out");
    fprintf(IOUNIT1, " %18.8e\n", Delta1x);
    fprintf(IOUNIT1, "\n");
    /* Writing collected output to file Greeks.out from ResultEq2c. */
    fprintf(IOUNIT1, " %18.8e\n", Delta2x);
    fprintf(IOUNIT1, "\n");
    /* Writing collected output to file Greeks.out from ResultEq3c. */
    fprintf(IOUNIT1, " %18.8e\n", Gamma1x);
    fprintf(IOUNIT1, "\n");
    /* Writing collected output to file Greeks.out from ResultEq4c. */
    fprintf(IOUNIT1, " %18.8e\n", Gamma2x);
    fprintf(IOUNIT1, "\n");
    /* Writing collected output to file Greeks.out from ResultEq5c. */
    fprintf(IOUNIT1, " %18.8e\n", Gamma12x);
    fprintf(IOUNIT1, "\n");
    fclose(IOUNIT1);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




