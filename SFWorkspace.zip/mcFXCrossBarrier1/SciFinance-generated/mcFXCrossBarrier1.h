#ifndef MCFXCROSSBARRIER1_H
#define MCFXCROSSBARRIER1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcFXCrossBarrier1fn(
    double B,
    int calcGreeks,
    int call,
    int deferred,
    double & Delta1x,
    double & Delta2x,
    double FX10,
    double FX20,
    double FXbump,
    double & Gamma12x,
    double & Gamma1x,
    double & Gamma2x,
    int in,
    double K,
    double kapparD,
    double kapparF1,
    double kapparF2,
    int nMax,
    int nSD,
    int nvP1,
    int nvP2,
    int nZCD,
    int nZCF1,
    int nZCF2,
    int pMax,
    double Rebate,
    const SciArray2<double>& Rhorr,
    const SciArray2<double>& RhoXr,
    const SciArray2<double>& RhoXX,
    int Series,
    double sigmarD,
    double sigmarF1,
    double sigmarF2,
    double TMax,
    int up,
    const SciArray1<double>& volParams1,
    const SciArray1<double>& volParams2,
    const SciArray1<double>& ZeroDatesD,
    const SciArray1<double>& ZeroDatesF1,
    const SciArray1<double>& ZeroDatesF2,
    const SciArray1<double>& ZeroRatesD,
    const SciArray1<double>& ZeroRatesF1,
    const SciArray1<double>& ZeroRatesF2,
    double & Vx
    );
     


#endif /* MCFXCROSSBARRIER1_H */
