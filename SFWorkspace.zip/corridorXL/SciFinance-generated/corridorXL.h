/*** Key to program variables: ***
  Accuracy: solution variable; an input
  disc: interest rate; an input
  divyld: continuous dividend yield; an input
  K: solution variable; an input
  LBDates: solution variable; an input
  LBLevels: solution variable; an input
  loan: stock loan rate; an input
  nLB: array maximum for LBLevels and LBDates; an input
  nUB: array maximum for UBLevels and UBDates; an input
  put: solution variable; an input
  sigma: volatility; an input
  Spot: solution variable; an input
  TMax: minimum physical value in dimension tau; an input
  UBDates: solution variable; an input
  UBLevels: solution variable; an input
  Vspotp: interpolated value of Vspot (option value) ; an output
  Deltap: interpolated value of Delta (option value) ; an output
  Gammap: interpolated value of Gamma (option value) ; an output
  Vega1p: interpolated value of Vega1 (Vega) ; an output
*** end Key to program variables: ***/


/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for LBDates in file "LBValues.dat" has maximum index
      nLB, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nLB elements,
      to be stored in LBDates(0..nLB).

   The table for LBLevels in file "LBValues.dat" has maximum index
      nLB, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nLB elements,
      to be stored in LBLevels(0..nLB).

   The table for UBDates in file "UBValues.dat" has maximum index
      nUB, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nUB elements,
      to be stored in UBDates(0..nUB).

   The table for UBLevels in file "UBValues.dat" has maximum index
      nUB, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nUB elements,
      to be stored in UBLevels(0..nUB).


******************* END FORMAT INSTRUCTIONS *******************/


#ifdef __cplusplus
extern "C" {
#endif
extern int corridorXLfn(
    double Accuracy,
    double disc,
    double divyld,
    double K,
    double *LBDates,
    double *LBLevels,
    double loan,
    int nLB,
    int nUB,
    int put,
    double sigma,
    double Spot,
    double TMax,
    double *UBDates,
    double *UBLevels,
    double *Vspotp,
    double *Deltap,
    double *Gammap,
    double *Vega1p,
    int * SciErrorFlagp,
    struct error_struct * SciErrorBufferp
    );
     
#ifdef __cplusplus
}
#endif
