



#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcAntithetic1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcAntithetic1MW
#define openfilemcAntithetic1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcAntithetic1MR
#define openfilemcAntithetic1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcAntithetic1M
#define fscanfMmcAntithetic1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }



int main()
{
    int pMax,Seed;
    double Deltax,devx,EDeltax,EGammax,epsilon,ERhoQx,ERhox,EThetax,EVannax,EVegax,EVolgax,Gammax,K,q,r,RhoQx,Rhox,sigma
       ,Spot,Thetax,TMax,Vannax,Vegax,Volgax,Vx;
    ArgumentRecord initInputTable[10];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4,*IOUNIT5,*IOUNIT6,*IOUNIT7,*IOUNIT8,*IOUNIT9;
    int put;
    
    /* *** Key to program variables: *** */
    /* Deltax, epsilon, Gammax, K, put, q, RhoQx, Rhox, Seed, sigma, Spot, Thetax, Vannax, Vegax, Volgax: solution      
       variable */
    /* devx, EDeltax, EGammax, ERhoQx, ERhox, EThetax, EVannax, EVegax, EVolgax: standard deviation error estimate */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5, IOUNIT6, IOUNIT7, IOUNIT8, IOUNIT9: I/O channel */
    /* pMax: maximum for path */
    /* r: discount rate */
    /* TMax: maximum time */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcAntithetic1MR(IOUNIT9,"init.dat");
    setupargs(initInputTable, 0, "epsilon", epsilon, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "K", K, READINPUTSDOUBLE);
    setupargs(initInputTable, 2, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 3, "put", put, READINPUTSBOOLEAN);
    setupargs(initInputTable, 4, "q", q, READINPUTSDOUBLE);
    setupargs(initInputTable, 5, "r", r, READINPUTSDOUBLE);
    setupargs(initInputTable, 6, "Seed", Seed, READINPUTSINTEGER);
    setupargs(initInputTable, 7, "sigma", sigma, READINPUTSDOUBLE);
    setupargs(initInputTable, 8, "Spot", Spot, READINPUTSDOUBLE);
    setupargs(initInputTable, 9, "TMax", TMax, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT9,initInputTable,10)!=0)
        {
        fclose(IOUNIT9);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT9);
    /*                            */
    /* Call the computation function. */
    mcAntithetic1fn(epsilon,K,pMax,put,q,r,Seed,sigma,Spot,TMax,Deltax,devx,EDeltax,EGammax,ERhox,ERhoQx,EThetax,EVannax
       ,EVegax,EVolgax,Gammax,Rhox,RhoQx,Thetax,Vx,Vannax,Vegax,Volgax);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfilemcAntithetic1MW(IOUNIT,"V.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file V.out from ResultEq1c. */
    fprintf(IOUNIT, " %18.8e\n", devx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* Writing collected output to file Delta.out from ResultEq2c. */
    openfilemcAntithetic1MW(IOUNIT1,"Delta.out");
    fprintf(IOUNIT1, " %18.8e\n", Deltax);
    fprintf(IOUNIT1, "\n");
    /* Writing collected output to file Delta.out from ResultEq3c. */
    fprintf(IOUNIT1, " %18.8e\n", EDeltax);
    fprintf(IOUNIT1, "\n");
    fclose(IOUNIT1);
    /* Writing collected output to file Gamma.out from ResultEq4c. */
    openfilemcAntithetic1MW(IOUNIT2,"Gamma.out");
    fprintf(IOUNIT2, " %18.8e\n", Gammax);
    fprintf(IOUNIT2, "\n");
    /* Writing collected output to file Gamma.out from ResultEq5c. */
    fprintf(IOUNIT2, " %18.8e\n", EGammax);
    fprintf(IOUNIT2, "\n");
    fclose(IOUNIT2);
    /* Writing collected output to file Theta.out from ResultEq6c. */
    openfilemcAntithetic1MW(IOUNIT3,"Theta.out");
    fprintf(IOUNIT3, " %18.8e\n", Thetax);
    fprintf(IOUNIT3, "\n");
    /* Writing collected output to file Theta.out from ResultEq7c. */
    fprintf(IOUNIT3, " %18.8e\n", EThetax);
    fprintf(IOUNIT3, "\n");
    fclose(IOUNIT3);
    /* Writing collected output to file Vega.out from ResultEq8c. */
    openfilemcAntithetic1MW(IOUNIT4,"Vega.out");
    fprintf(IOUNIT4, " %18.8e\n", Vegax);
    fprintf(IOUNIT4, "\n");
    /* Writing collected output to file Vega.out from ResultEq9c. */
    fprintf(IOUNIT4, " %18.8e\n", EVegax);
    fprintf(IOUNIT4, "\n");
    fclose(IOUNIT4);
    /* Writing collected output to file Rho.out from ResultEq10c. */
    openfilemcAntithetic1MW(IOUNIT5,"Rho.out");
    fprintf(IOUNIT5, " %18.8e\n", Rhox);
    fprintf(IOUNIT5, "\n");
    /* Writing collected output to file Rho.out from ResultEq11c. */
    fprintf(IOUNIT5, " %18.8e\n", ERhox);
    fprintf(IOUNIT5, "\n");
    fclose(IOUNIT5);
    /* Writing collected output to file RhoQ.out from ResultEq12c. */
    openfilemcAntithetic1MW(IOUNIT6,"RhoQ.out");
    fprintf(IOUNIT6, " %18.8e\n", RhoQx);
    fprintf(IOUNIT6, "\n");
    /* Writing collected output to file RhoQ.out from ResultEq13c. */
    fprintf(IOUNIT6, " %18.8e\n", ERhoQx);
    fprintf(IOUNIT6, "\n");
    fclose(IOUNIT6);
    /* Writing collected output to file Volga.out from ResultEq14c. */
    openfilemcAntithetic1MW(IOUNIT7,"Volga.out");
    fprintf(IOUNIT7, " %18.8e\n", Volgax);
    fprintf(IOUNIT7, "\n");
    /* Writing collected output to file Volga.out from ResultEq15c. */
    fprintf(IOUNIT7, " %18.8e\n", EVolgax);
    fprintf(IOUNIT7, "\n");
    fclose(IOUNIT7);
    /* Writing collected output to file Vanna.out from ResultEq16c. */
    openfilemcAntithetic1MW(IOUNIT8,"Vanna.out");
    fprintf(IOUNIT8, " %18.8e\n", Vannax);
    fprintf(IOUNIT8, "\n");
    /* Writing collected output to file Vanna.out from ResultEq17c. */
    fprintf(IOUNIT8, " %18.8e\n", EVannax);
    fprintf(IOUNIT8, "\n");
    fclose(IOUNIT8);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




