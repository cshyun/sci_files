#ifndef MCEQLINKSTRUCTNOTE6_H
#define MCEQLINKSTRUCTNOTE6_H

#include "SciArrayN.h" /* SciComp arrays */

void mcEqLinkStructNote6fn(
    double CallPerf,
    const SciArray1<double>& CouponDates,
    int inRangeDays0,
    double LRangeBar,
    double MaxCoupon,
    double MinCoupon,
    int nCoup,
    int nDays0,
    int nObs,
    double Notional,
    int nS,
    const SciArray1<double>& ObsDates,
    int pMax,
    const SciArray1<double>& q,
    double r,
    double RefPerf,
    const SciArray2<double>& rho,
    const SciArray1<double>& S0,
    int Series,
    double SettleDate,
    const SciArray1<double>& sigma,
    const SciArray1<double>& SRef,
    int Triggered0,
    double URangeBar,
    double & Vx
    );
     


#endif /* MCEQLINKSTRUCTNOTE6_H */
