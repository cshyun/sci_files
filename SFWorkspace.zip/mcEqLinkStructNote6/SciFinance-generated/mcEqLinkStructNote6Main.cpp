

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for CouponDates in file "CouponDates.dat" has maximum index
      nCoup, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nCoup elements,
      to be stored in CouponDates(1..nCoup).

   The table for ObsDates in file "ObsDates.dat" has maximum index
      nObs, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nObs elements,
      to be stored in ObsDates(1..nObs).

   The table for q in file "Stocks.dat" has maximum index
      nS, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nS elements,
      to be stored in q(1..nS).

   The table for rho in file "rho.dat" has maximum indices
      nS and nS, 
     with minimum indices 1, 1 respectively.
      The index bounds are not read from this file.
        Following should be the nS^2 elements,
      to be stored in rho(1..nS, 1..nS).
   The first index is the most slowly varying and 
      the last index is the most rapidly varying.

   The table for S0 in file "Stocks.dat" has maximum index
      nS, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nS elements,
      to be stored in S0(1..nS).

   The table for sigma in file "Stocks.dat" has maximum index
      nS, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nS elements,
      to be stored in sigma(1..nS).

   The table for SRef in file "Stocks.dat" has maximum index
      nS, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nS elements,
      to be stored in SRef(1..nS).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcEqLinkStructNote6.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcEqLinkStructNote6MW
#define openfilemcEqLinkStructNote6MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcEqLinkStructNote6MR
#define openfilemcEqLinkStructNote6MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcEqLinkStructNote6M
#define fscanfMmcEqLinkStructNote6M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs4
#define spreadargs4(a1,a2,a3,a4) a1,a2,a3,a4


int main()
{
    int inRangeDays0,itvar1,itvar2,nCoup,nDays0,nObs,nS,pMax,Series,Triggered0;
    double CallPerf,LRangeBar,MaxCoupon,MinCoupon,Notional,r,RefPerf,SettleDate,URangeBar,Vx;
    ArgumentRecord initInputTable[17];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4,*IOUNIT5;
    
    /* *** Key to program variables: *** */
    /* CallPerf, CouponDates, inRangeDays0, LRangeBar, MaxCoupon, MinCoupon, nDays0, Notional, ObsDates, q, RefPerf,    
       rho, S0, Series, SettleDate, sigma, SRef, Triggered0, URangeBar: solution variable */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5: I/O channel */
    /* nCoup: array maximum for CouponDates */
    /* nObs: array maximum for ObsDates */
    /* nS: maximum for iS */
    /* pMax: maximum for path */
    /* r: discount rate */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcEqLinkStructNote6MR(IOUNIT1,"init.dat");
    setupargs(initInputTable, 0, "CallPerf", CallPerf, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "inRangeDays0", inRangeDays0, READINPUTSINTEGER);
    setupargs(initInputTable, 2, "LRangeBar", LRangeBar, READINPUTSDOUBLE);
    setupargs(initInputTable, 3, "MaxCoupon", MaxCoupon, READINPUTSDOUBLE);
    setupargs(initInputTable, 4, "MinCoupon", MinCoupon, READINPUTSDOUBLE);
    setupargs(initInputTable, 5, "nCoup", nCoup, READINPUTSINTEGER);
    setupargs(initInputTable, 6, "nDays0", nDays0, READINPUTSINTEGER);
    setupargs(initInputTable, 7, "nObs", nObs, READINPUTSINTEGER);
    setupargs(initInputTable, 8, "Notional", Notional, READINPUTSDOUBLE);
    setupargs(initInputTable, 9, "nS", nS, READINPUTSINTEGER);
    setupargs(initInputTable, 10, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 11, "r", r, READINPUTSDOUBLE);
    setupargs(initInputTable, 12, "RefPerf", RefPerf, READINPUTSDOUBLE);
    setupargs(initInputTable, 13, "Series", Series, READINPUTSINTEGER);
    setupargs(initInputTable, 14, "SettleDate", SettleDate, READINPUTSDOUBLE);
    setupargs(initInputTable, 15, "Triggered0", Triggered0, READINPUTSINTEGER);
    setupargs(initInputTable, 16, "URangeBar", URangeBar, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,initInputTable,17)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    /* Read CouponDates from file */
    SciArray1<double>CouponDates(nCoup + 1);
    if (nCoup>=1)
        {
        openfilemcEqLinkStructNote6MR(IOUNIT2,"CouponDates.dat");
        for (itvar1=1; itvar1<=nCoup; itvar1++) {
            fscanfMmcEqLinkStructNote6M(IOUNIT2,"%lg",1,((&CouponDates(itvar1))));
        }
        fclose(IOUNIT2);
        }
    /* Read ObsDates from file */
    SciArray1<double>ObsDates(nObs + 1);
    if (nObs>=1)
        {
        openfilemcEqLinkStructNote6MR(IOUNIT3,"ObsDates.dat");
        for (itvar1=1; itvar1<=nObs; itvar1++) {
            fscanfMmcEqLinkStructNote6M(IOUNIT3,"%lg",1,((&ObsDates(itvar1))));
        }
        fclose(IOUNIT3);
        }
    SciArray2<double>rho(nS + 1, nS + 1);
    SciArray1<double>S0(nS + 1);
    SciArray1<double>SRef(nS + 1);
    SciArray1<double>q(nS + 1);
    SciArray1<double>sigma(nS + 1);
    if (nS>=1)
        {
        /* Read rho from file */
        openfilemcEqLinkStructNote6MR(IOUNIT4,"rho.dat");
        for (itvar1=1; itvar1<=nS; itvar1++) {
            for (itvar2=1; itvar2<=nS; itvar2++) {
                fscanfMmcEqLinkStructNote6M(IOUNIT4,"%lg",1,((&rho(itvar1,itvar2))));
            }
        }
        fclose(IOUNIT4);
        /* Read S0 from file. Read SRef from file. Read q from file. Read sigma from file */
        openfilemcEqLinkStructNote6MR(IOUNIT5,"Stocks.dat");
        for (itvar1=1; itvar1<=nS; itvar1++) {
            fscanfMmcEqLinkStructNote6M(IOUNIT5,
               "%lg%lg%lg%lg",4,((&S0(itvar1)),(&SRef(itvar1)),(&q(itvar1)),(&sigma(itvar1))));
        }
        fclose(IOUNIT5);
        }
    /*                            */
    /* Call the computation function. */
    mcEqLinkStructNote6fn(CallPerf,CouponDates,inRangeDays0,LRangeBar,MaxCoupon,MinCoupon,nCoup,nDays0,nObs,Notional,nS,
       ObsDates,pMax,q,r,RefPerf,rho,S0,Series,SettleDate,sigma,SRef,Triggered0,URangeBar,Vx);
    /*                            */
    /* Writing collected output to file Value.out from ResultEqc. */
    openfilemcEqLinkStructNote6MW(IOUNIT,"Value.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




