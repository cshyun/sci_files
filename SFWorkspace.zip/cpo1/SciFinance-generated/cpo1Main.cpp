/*** Key to program variables: ***
  D0: continuous dividend yield; an input
  iMax: number of grid cells for S; an input
  K: solution variable; an input
  nMax: number of grid cells for t; an input
  nspot: array maximum for spottable; an input
  nsup: solution variable; an input
  put: solution variable; an input
  r: interest rate; an input
  Scp: solution variable; an input
  sigma: volatility; an input
  SMax: maximum physical value in dimension S; an input
  SMin: minimum physical value in dimension S; an input
  spottable: solution variable; an input
  TMax: minimum physical value in dimension t; an input
  Xcp: solution variable; an input
  atspotx: solution variable; an output
  atspot1x: solution variable; an output
  atspot2x: solution variable; an output
  atspot3x: solution variable; an output
  atspot4x: solution variable; an output
  atspot5x: solution variable; an output
*** end Key to program variables: ***/


/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for spottable in file "spottab.dat" has maximum index
      nspot, 
     with minimum index 0.
         nspot should be on line 1 of the file.
   Following should be the 1 + nspot elements,
      to be stored in spottable(0..nspot).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "cpo1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilecpo1MW
#define openfilecpo1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilecpo1MR
#define openfilecpo1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMcpo1M
#define fscanfMcpo1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1


int main()
{
    int d,iMax,itvar1,nMax,nspot,nsup;
    ArgumentRecord cpoinitInputTable[13];
    double D0,K,r,Scp,sigma,SMax,SMin,TMax,Xcp;
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2;
    int put;
    
    /* *** Key to program variables: *** */
    /* atspot: interpolated value of atspot (option value)  */
    /* atspot1: interpolated value of atspot1 (Vega)  */
    /* atspot2: interpolated value of atspot2 (Rho)  */
    /* atspot3: interpolated value of atspot3 (option value)  */
    /* atspot4: interpolated value of atspot4 (option value)  */
    /* atspot5: interpolated value of atspot5 (option value)  */
    /* d: index variable for spottable */
    /* D0: continuous dividend yield */
    /* iMax: number of grid cells for S */
    /* IOUNIT, IOUNIT1, IOUNIT2: I/O channel */
    /* K, nsup, put, Scp, spottable, Xcp: solution variable */
    /* nMax: number of grid cells for t */
    /* nspot: array maximum for spottable */
    /* r: interest rate */
    /* sigma: volatility */
    /* SMax: maximum physical value in dimension S */
    /* SMin: minimum physical value in dimension S */
    /* TMax: minimum physical value in dimension t */
    try {
    /* Read Tagged Input File */
    openfilecpo1MR(IOUNIT1,"cpoinit.dat");
    setupargs(cpoinitInputTable, 0, "D0", D0, READINPUTSDOUBLE);
    setupargs(cpoinitInputTable, 1, "iMax", iMax, READINPUTSINTEGER);
    setupargs(cpoinitInputTable, 2, "K", K, READINPUTSDOUBLE);
    setupargs(cpoinitInputTable, 3, "nMax", nMax, READINPUTSINTEGER);
    setupargs(cpoinitInputTable, 4, "nsup", nsup, READINPUTSINTEGER);
    setupargs(cpoinitInputTable, 5, "put", put, READINPUTSBOOLEAN);
    setupargs(cpoinitInputTable, 6, "r", r, READINPUTSDOUBLE);
    setupargs(cpoinitInputTable, 7, "Scp", Scp, READINPUTSDOUBLE);
    setupargs(cpoinitInputTable, 8, "sigma", sigma, READINPUTSDOUBLE);
    setupargs(cpoinitInputTable, 9, "SMax", SMax, READINPUTSDOUBLE);
    setupargs(cpoinitInputTable, 10, "SMin", SMin, READINPUTSDOUBLE);
    setupargs(cpoinitInputTable, 11, "TMax", TMax, READINPUTSDOUBLE);
    setupargs(cpoinitInputTable, 12, "Xcp", Xcp, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,cpoinitInputTable,13)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    /* Read spottable from file */
    openfilecpo1MR(IOUNIT2,"spottab.dat");
    fscanfMcpo1M(IOUNIT2,"%i",1,((&nspot)));
    SciArray1<double>spottable(nspot + 1);
    if (nspot>=0)
        {
        for (itvar1=0; itvar1<=nspot; itvar1++) {
            fscanfMcpo1M(IOUNIT2,"%lg",1,((&spottable(itvar1))));
        }
        }
    fclose(IOUNIT2);
    /*                            */
    /* Call the computation function. */
    SciArray1<double> atspot;
    SciArray1<double> atspot1;
    SciArray1<double> atspot2;
    SciArray1<double> atspot3;
    SciArray1<double> atspot4;
    SciArray1<double> atspot5;
    cpo1fn(D0,iMax,K,nMax,nspot,nsup,put,r,Scp,sigma,SMax,SMin,spottable,TMax,Xcp,atspot,atspot1,atspot2,atspot3,atspot4
       ,atspot5);
    /*                            */
    /* Writing collected output to file atspot.out from ResultEqc. */
    openfilecpo1MW(IOUNIT,"atspot.out");
    for (d=0; d<=(int)atspot.size0() - 1; d++) {
        fprintf(IOUNIT, " %18.8e\n", atspot(d));
    }
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file atspot.out from ResultEq1c. */
    for (d=0; d<=(int)atspot1.size0() - 1; d++) {
        fprintf(IOUNIT, " %18.8e\n", atspot1(d));
    }
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file atspot.out from ResultEq2c. */
    for (d=0; d<=(int)atspot2.size0() - 1; d++) {
        fprintf(IOUNIT, " %18.8e\n", atspot2(d));
    }
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file atspot.out from ResultEq3c. */
    for (d=0; d<=(int)atspot3.size0() - 1; d++) {
        fprintf(IOUNIT, " %18.8e\n", atspot3(d));
    }
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file atspot.out from ResultEq4c. */
    for (d=0; d<=(int)atspot4.size0() - 1; d++) {
        fprintf(IOUNIT, " %18.8e\n", atspot4(d));
    }
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file atspot.out from ResultEq5c. */
    for (d=0; d<=(int)atspot5.size0() - 1; d++) {
        fprintf(IOUNIT, " %18.8e\n", atspot5(d));
    }
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




