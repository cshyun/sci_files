#ifndef CPO1_H
#define CPO1_H

#include "SciArrayN.h" /* SciComp arrays */

void cpo1fn(
    double D0,
    int iMax,
    double K,
    int nMax,
    int nspot,
    int nsup,
    int put,
    double r,
    double Scp,
    double sigma,
    double SMax,
    double SMin,
    const SciArray1<double>& spottable,
    double TMax,
    double Xcp,
    SciArray1<double>& atspotx,
    SciArray1<double>& atspot1x,
    SciArray1<double>& atspot2x,
    SciArray1<double>& atspot3x,
    SciArray1<double>& atspot4x,
    SciArray1<double>& atspot5x
    );
     


#endif /* CPO1_H */
