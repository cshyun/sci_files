#ifndef MCDISCBARRIER1_H
#define MCDISCBARRIER1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcDiscBarrier1fn(
    double B,
    double K,
    int nsamp,
    int pMax,
    int put,
    double q,
    double r,
    double Rebate,
    int Seed,
    double sigma,
    double Spot,
    double TMax,
    const SciArray1<double>& tsamp,
    int up,
    double & devx,
    double & Vx
    );
     


#endif /* MCDISCBARRIER1_H */
