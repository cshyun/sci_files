

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for aX in file "kappaX.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in aX(1..nD).

   The table for bX in file "thetaX.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in bX(1..nD).

   The table for CopR in file "CopR.dat" has maximum indices
      nD and nD, 
     with minimum indices 1, 1 respectively.
      The index bounds are not read from this file.
        Following should be the nD^2 elements,
      to be stored in CopR(1..nD, 1..nD).
   The first index is the most slowly varying and 
      the last index is the most rapidly varying.

   The table for Coupon in file "Collateral.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in Coupon(1..nD).

   The table for cX in file "sigmaX.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in cX(1..nD).

   The table for dX in file "muX.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in dX(1..nD).

   The table for lX in file "lX.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in lX(1..nD).

   The table for Notional in file "Collateral.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in Notional(1..nD).

   The table for Recovery in file "Collateral.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in Recovery(1..nD).

   The table for rho in file "rho.dat" has maximum indices
      imax1 and imax1, 
     with minimum indices 1, 1 respectively.
      The index bounds are not read from this file.
        Following should be the imax1^2 elements,
      to be stored in rho(1..imax1, 1..imax1).
   The first index is the most slowly varying and 
      the last index is the most rapidly varying.

   The table for tC in file "tCoup.dat" has maximum index
      nC, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nC elements,
      to be stored in tC(1..nC).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcCSO3.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcCSO3MW
#define openfilemcCSO3MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcCSO3MR
#define openfilemcCSO3MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcCSO3M
#define fscanfMmcCSO3M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs3
#define spreadargs3(a1,a2,a3) a1,a2,a3


int main()
{
    int imax1,itvar1,itvar2,nC,nD,nMax,pMax,Seed;
    double alpha,aXc,bXc,Coup1,Coup2,cXc,dev1x,dev2x,devx,Juniorx,Mezzaninex,P1,P2,r,Seniorx,TMax,xi;
    ArgumentRecord initInputTable[16];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT10,*IOUNIT2,*IOUNIT3,*IOUNIT4,*IOUNIT5,*IOUNIT6,*IOUNIT7,*IOUNIT8,*IOUNIT9;
    
    /* *** Key to program variables: *** */
    /* alpha, aX, aXc, bX, bXc, CopR, Coup1, Coup2, Coupon, cX, cXc, dX, lX, Notional, P1, P2, r, Recovery, rho, Seed,  
       tC, xi: solution variable */
    /* dev1x, dev2x, devx: standard deviation error estimate */
    /* imax1: maximum for irho */
    /* IOUNIT, IOUNIT1, IOUNIT10, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5, IOUNIT6, IOUNIT7, IOUNIT8, IOUNIT9: I/O channel */
    /* Juniorx, Mezzaninex, Seniorx: discounted value */
    /* nC: array maximum for tC */
    /* nD: array maximum for CopR, aX, bX, cX, dX, lX, Coupon, Notional and Recovery */
    /* nMax: number of grid cells for t */
    /* pMax: maximum for path */
    /* TMax: maximum time */
    try {
    /* Read Tagged Input File */
    openfilemcCSO3MR(IOUNIT1,"init.dat");
    setupargs(initInputTable, 0, "alpha", alpha, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "aXc", aXc, READINPUTSDOUBLE);
    setupargs(initInputTable, 2, "bXc", bXc, READINPUTSDOUBLE);
    setupargs(initInputTable, 3, "Coup1", Coup1, READINPUTSDOUBLE);
    setupargs(initInputTable, 4, "Coup2", Coup2, READINPUTSDOUBLE);
    setupargs(initInputTable, 5, "cXc", cXc, READINPUTSDOUBLE);
    setupargs(initInputTable, 6, "nC", nC, READINPUTSINTEGER);
    setupargs(initInputTable, 7, "nD", nD, READINPUTSINTEGER);
    setupargs(initInputTable, 8, "nMax", nMax, READINPUTSINTEGER);
    setupargs(initInputTable, 9, "P1", P1, READINPUTSDOUBLE);
    setupargs(initInputTable, 10, "P2", P2, READINPUTSDOUBLE);
    setupargs(initInputTable, 11, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 12, "r", r, READINPUTSDOUBLE);
    setupargs(initInputTable, 13, "Seed", Seed, READINPUTSINTEGER);
    setupargs(initInputTable, 14, "TMax", TMax, READINPUTSDOUBLE);
    setupargs(initInputTable, 15, "xi", xi, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,initInputTable,16)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    imax1 = nD + 1;
    SciArray2<double>CopR(nD + 1, nD + 1);
    SciArray1<double>aX(nD + 1);
    SciArray1<double>lX(nD + 1);
    SciArray1<double>dX(nD + 1);
    SciArray1<double>cX(nD + 1);
    SciArray1<double>bX(nD + 1);
    SciArray1<double>Coupon(nD + 1);
    SciArray1<double>Recovery(nD + 1);
    SciArray1<double>Notional(nD + 1);
    if (nD>=1)
        {
        /* Read CopR from file */
        openfilemcCSO3MR(IOUNIT2,"CopR.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            for (itvar2=1; itvar2<=nD; itvar2++) {
                fscanfMmcCSO3M(IOUNIT2,"%lg",1,((&CopR(itvar1,itvar2))));
            }
        }
        fclose(IOUNIT2);
        /* Read aX from file */
        openfilemcCSO3MR(IOUNIT3,"kappaX.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCSO3M(IOUNIT3,"%lg",1,((&aX(itvar1))));
        }
        fclose(IOUNIT3);
        /* Read lX from file */
        openfilemcCSO3MR(IOUNIT4,"lX.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCSO3M(IOUNIT4,"%lg",1,((&lX(itvar1))));
        }
        fclose(IOUNIT4);
        /* Read dX from file */
        openfilemcCSO3MR(IOUNIT5,"muX.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCSO3M(IOUNIT5,"%lg",1,((&dX(itvar1))));
        }
        fclose(IOUNIT5);
        /* Read cX from file */
        openfilemcCSO3MR(IOUNIT6,"sigmaX.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCSO3M(IOUNIT6,"%lg",1,((&cX(itvar1))));
        }
        fclose(IOUNIT6);
        /* Read bX from file */
        openfilemcCSO3MR(IOUNIT7,"thetaX.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCSO3M(IOUNIT7,"%lg",1,((&bX(itvar1))));
        }
        fclose(IOUNIT7);
        /* Read Coupon from file. Read Recovery from file. Read Notional from file */
        openfilemcCSO3MR(IOUNIT8,"Collateral.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCSO3M(IOUNIT8,"%lg%lg%lg",3,((&Coupon(itvar1)),(&Notional(itvar1)),(&Recovery(itvar1))));
        }
        fclose(IOUNIT8);
        }
    /* Read rho from file */
    SciArray2<double>rho(imax1 + 1, imax1 + 1);
    if (imax1>=1)
        {
        openfilemcCSO3MR(IOUNIT9,"rho.dat");
        for (itvar1=1; itvar1<=imax1; itvar1++) {
            for (itvar2=1; itvar2<=imax1; itvar2++) {
                fscanfMmcCSO3M(IOUNIT9,"%lg",1,((&rho(itvar1,itvar2))));
            }
        }
        fclose(IOUNIT9);
        }
    /* Read tC from file */
    SciArray1<double>tC(nC + 1);
    if (nC>=1)
        {
        openfilemcCSO3MR(IOUNIT10,"tCoup.dat");
        for (itvar1=1; itvar1<=nC; itvar1++) {
            fscanfMmcCSO3M(IOUNIT10,"%lg",1,((&tC(itvar1))));
        }
        fclose(IOUNIT10);
        }
    /*                            */
    /* Call the computation function. */
    mcCSO3fn(alpha,aX,aXc,bX,bXc,CopR,Coup1,Coup2,Coupon,cX,cXc,dX,lX,nC,nD,nMax,Notional,P1,P2,pMax,r,Recovery,rho,Seed
       ,tC,TMax,xi,devx,dev1x,dev2x,Juniorx,Mezzaninex,Seniorx);
    /*                            */
    /* Writing collected output to file W.out from ResultEqc. */
    openfilemcCSO3MW(IOUNIT,"W.out");
    fprintf(IOUNIT, " %18.8e\n", Seniorx);
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file W.out from ResultEq1c. */
    fprintf(IOUNIT, " %18.8e\n", devx);
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file W.out from ResultEq2c. */
    fprintf(IOUNIT, " %18.8e\n", Mezzaninex);
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file W.out from ResultEq3c. */
    fprintf(IOUNIT, " %18.8e\n", dev1x);
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file W.out from ResultEq4c. */
    fprintf(IOUNIT, " %18.8e\n", Juniorx);
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file W.out from ResultEq5c. */
    fprintf(IOUNIT, " %18.8e\n", dev2x);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




