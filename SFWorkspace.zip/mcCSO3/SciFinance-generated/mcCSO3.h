#ifndef MCCSO3_H
#define MCCSO3_H

#include "SciArrayN.h" /* SciComp arrays */

void mcCSO3fn(
    double alpha,
    const SciArray1<double>& aX,
    double aXc,
    const SciArray1<double>& bX,
    double bXc,
    const SciArray2<double>& CopR,
    double Coup1,
    double Coup2,
    const SciArray1<double>& Coupon,
    const SciArray1<double>& cX,
    double cXc,
    const SciArray1<double>& dX,
    const SciArray1<double>& lX,
    int nC,
    int nD,
    int nMax,
    const SciArray1<double>& Notional,
    double P1,
    double P2,
    int pMax,
    double r,
    const SciArray1<double>& Recovery,
    const SciArray2<double>& rho,
    int Seed,
    const SciArray1<double>& tC,
    double TMax,
    double xi,
    double & devx,
    double & dev1x,
    double & dev2x,
    double & Juniorx,
    double & Mezzaninex,
    double & Seniorx
    );
     


#endif /* MCCSO3_H */
