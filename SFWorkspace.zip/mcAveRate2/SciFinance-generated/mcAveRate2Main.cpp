

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for tsample in file "A1samplingTime.dat" has maximum index
      nsampleToGoA1, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nsampleToGoA1 elements,
      to be stored in tsample(1..nsampleToGoA1).

   The table for weight in file "A1samplingTime.dat" has maximum index
      nsampleToGoA1, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nsampleToGoA1 elements,
      to be stored in weight(1..nsampleToGoA1).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcAveRate2.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcAveRate2MW
#define openfilemcAveRate2MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcAveRate2MR
#define openfilemcAveRate2MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcAveRate2M
#define fscanfMmcAveRate2M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2


int main()
{
    int itvar1,nsampleSoFarA1,nsampleToGoA1,pMax,Series;
    ArgumentRecord initInputTable[12];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2;
    double K,lastA1,q,r,sigma,Spot,TMax,Vx;
    int put;
    
    /* *** Key to program variables: *** */
    /* IOUNIT, IOUNIT1, IOUNIT2: I/O channel */
    /* K, lastA1, nsampleSoFarA1, put, q, Series, sigma, Spot, weight: solution variable */
    /* nsampleToGoA1: array maximum for weight and tsample */
    /* pMax: maximum for path */
    /* r: discount rate */
    /* TMax: maximum time */
    /* tsample: Sample array for Path */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcAveRate2MR(IOUNIT1,"init.dat");
    setupargs(initInputTable, 0, "K", K, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "lastA1", lastA1, READINPUTSDOUBLE);
    setupargs(initInputTable, 2, "nsampleSoFarA1", nsampleSoFarA1, READINPUTSINTEGER);
    setupargs(initInputTable, 3, "nsampleToGoA1", nsampleToGoA1, READINPUTSINTEGER);
    setupargs(initInputTable, 4, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 5, "put", put, READINPUTSBOOLEAN);
    setupargs(initInputTable, 6, "q", q, READINPUTSDOUBLE);
    setupargs(initInputTable, 7, "r", r, READINPUTSDOUBLE);
    setupargs(initInputTable, 8, "Series", Series, READINPUTSINTEGER);
    setupargs(initInputTable, 9, "sigma", sigma, READINPUTSDOUBLE);
    setupargs(initInputTable, 10, "Spot", Spot, READINPUTSDOUBLE);
    setupargs(initInputTable, 11, "TMax", TMax, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,initInputTable,12)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    SciArray1<double>weight(nsampleToGoA1 + 1);
    SciArray1<double>tsample(nsampleToGoA1 + 1);
    /* Read weight from file. Read tsample from file */
    if (nsampleToGoA1>=1)
        {
        openfilemcAveRate2MR(IOUNIT2,"A1samplingTime.dat");
        for (itvar1=1; itvar1<=nsampleToGoA1; itvar1++) {
            fscanfMmcAveRate2M(IOUNIT2,"%lg%lg",2,((&weight(itvar1)),(&tsample(itvar1))));
        }
        fclose(IOUNIT2);
        }
    /*                            */
    /* Call the computation function. */
    mcAveRate2fn(K,lastA1,nsampleSoFarA1,nsampleToGoA1,pMax,put,q,r,Series,sigma,Spot,TMax,tsample,weight,Vx);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfilemcAveRate2MW(IOUNIT,"V.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




