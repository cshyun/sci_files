#ifndef MCAVERATE2_H
#define MCAVERATE2_H

#include "SciArrayN.h" /* SciComp arrays */

void mcAveRate2fn(
    double K,
    double lastA1,
    int nsampleSoFarA1,
    int nsampleToGoA1,
    int pMax,
    int put,
    double q,
    double r,
    int Series,
    double sigma,
    double Spot,
    double TMax,
    const SciArray1<double>& tsample,
    const SciArray1<double>& weight,
    double & Vx
    );
     


#endif /* MCAVERATE2_H */
