#ifndef MCEQLINKSTRUCTNOTE2_H
#define MCEQLINKSTRUCTNOTE2_H

#include "SciArrayN.h" /* SciComp arrays */

void mcEqLinkStructNote2fn(
    int nD,
    int nObs,
    double Notional,
    const SciArray1<double>& ObsDates,
    int pMax,
    double PR,
    const SciArray1<double>& q,
    double r,
    const SciArray2<double>& rho,
    int Series,
    const SciArray1<double>& sigma,
    const SciArray1<double>& Spot,
    const SciArray1<double>& SRef,
    double TMax,
    double & Vx
    );
     


#endif /* MCEQLINKSTRUCTNOTE2_H */
