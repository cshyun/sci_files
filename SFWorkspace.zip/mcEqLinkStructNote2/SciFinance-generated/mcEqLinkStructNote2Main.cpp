

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for ObsDates in file "ObsDates.dat" has maximum index
      nObs, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nObs elements,
      to be stored in ObsDates(1..nObs).

   The table for q in file "Basket.dat" has maximum index
      nD, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nD elements,
      to be stored in q(0..nD).

   The table for rho in file "rho.dat" has maximum indices
      nD and nD, 
     with minimum indices 0, 0 respectively.
      The index bounds are not read from this file.
        Following should be the (1 + nD)^2 elements,
      to be stored in rho(0..nD, 0..nD).
   The first index is the most slowly varying and 
      the last index is the most rapidly varying.

   The table for sigma in file "Basket.dat" has maximum index
      nD, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nD elements,
      to be stored in sigma(0..nD).

   The table for Spot in file "Basket.dat" has maximum index
      nD, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nD elements,
      to be stored in Spot(0..nD).

   The table for SRef in file "Basket.dat" has maximum index
      nD, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nD elements,
      to be stored in SRef(0..nD).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcEqLinkStructNote2.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcEqLinkStructNote2MW
#define openfilemcEqLinkStructNote2MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcEqLinkStructNote2MR
#define openfilemcEqLinkStructNote2MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcEqLinkStructNote2M
#define fscanfMmcEqLinkStructNote2M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs4
#define spreadargs4(a1,a2,a3,a4) a1,a2,a3,a4


int main()
{
    int itvar1,itvar2,nD,nObs,pMax,Series;
    ArgumentRecord initInputTable[8];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4;
    double Notional,PR,r,TMax,Vx;
    
    /* *** Key to program variables: *** */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4: I/O channel */
    /* nD: maximum for iD */
    /* nObs: array maximum for ObsDates */
    /* Notional, ObsDates, PR, q, rho, Series, sigma, Spot, SRef: solution variable */
    /* pMax: maximum for path */
    /* r: discount rate */
    /* TMax: maximum time */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcEqLinkStructNote2MR(IOUNIT1,"init.dat");
    setupargs(initInputTable, 0, "nD", nD, READINPUTSINTEGER);
    setupargs(initInputTable, 1, "nObs", nObs, READINPUTSINTEGER);
    setupargs(initInputTable, 2, "Notional", Notional, READINPUTSDOUBLE);
    setupargs(initInputTable, 3, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 4, "PR", PR, READINPUTSDOUBLE);
    setupargs(initInputTable, 5, "r", r, READINPUTSDOUBLE);
    setupargs(initInputTable, 6, "Series", Series, READINPUTSINTEGER);
    setupargs(initInputTable, 7, "TMax", TMax, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,initInputTable,8)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    SciArray2<double>rho(nD + 1, nD + 1);
    SciArray1<double>Spot(nD + 1);
    SciArray1<double>q(nD + 1);
    SciArray1<double>sigma(nD + 1);
    SciArray1<double>SRef(nD + 1);
    if (nD>=0)
        {
        /* Read rho from file */
        openfilemcEqLinkStructNote2MR(IOUNIT2,"rho.dat");
        for (itvar1=0; itvar1<=nD; itvar1++) {
            for (itvar2=0; itvar2<=nD; itvar2++) {
                fscanfMmcEqLinkStructNote2M(IOUNIT2,"%lg",1,((&rho(itvar1,itvar2))));
            }
        }
        fclose(IOUNIT2);
        /* Read Spot from file. Read q from file. Read sigma from file. Read SRef from file */
        openfilemcEqLinkStructNote2MR(IOUNIT3,"Basket.dat");
        for (itvar1=0; itvar1<=nD; itvar1++) {
            fscanfMmcEqLinkStructNote2M(IOUNIT3,
               "%lg%lg%lg%lg",4,((&Spot(itvar1)),(&SRef(itvar1)),(&q(itvar1)),(&sigma(itvar1))));
        }
        fclose(IOUNIT3);
        }
    /* Read ObsDates from file */
    SciArray1<double>ObsDates(nObs + 1);
    if (nObs>=1)
        {
        openfilemcEqLinkStructNote2MR(IOUNIT4,"ObsDates.dat");
        for (itvar1=1; itvar1<=nObs; itvar1++) {
            fscanfMmcEqLinkStructNote2M(IOUNIT4,"%lg",1,((&ObsDates(itvar1))));
        }
        fclose(IOUNIT4);
        }
    /*                            */
    /* Call the computation function. */
    mcEqLinkStructNote2fn(nD,nObs,Notional,ObsDates,pMax,PR,q,r,rho,Series,sigma,Spot,SRef,TMax,Vx);
    /*                            */
    /* Writing collected output to file Value.out from ResultEqc. */
    openfilemcEqLinkStructNote2MW(IOUNIT,"Value.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




