#ifndef MCG2CANCELCMSSNOWBEARSWAP1_H
#define MCG2CANCELCMSSNOWBEARSWAP1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcG2CancelCMSSnowbearSwap1fn(
    const SciArray1<double>& AccrualCms,
    const SciArray1<double>& AccrualFlt,
    double CallPrice,
    double CmsInitCoupon,
    const SciArray1<double>& CmsResetDates,
    double CommenceDate,
    const SciArray1<double>& ExerciseDates,
    const SciArray1<double>& Flr,
    const SciArray1<double>& Gear1,
    const SciArray1<double>& Gear2,
    double kappa1,
    double kappa2,
    int maxord1,
    int maxord2,
    int maxord3,
    int nCMS,
    int nCpn,
    int nExer,
    int nMax,
    double Notional,
    int nRst,
    int nZero,
    double PastCms,
    double PastLibor,
    const SciArray1<double>& PaymentDates,
    int pMax,
    double rho12,
    int Series,
    double sigma1,
    double sigma2,
    const SciArray1<double>& Spread,
    double tauCMS,
    double tauLibor,
    const SciArray1<double>& zDates,
    const SciArray1<double>& zRates,
    double & Vx
    );
     


#endif /* MCG2CANCELCMSSNOWBEARSWAP1_H */
