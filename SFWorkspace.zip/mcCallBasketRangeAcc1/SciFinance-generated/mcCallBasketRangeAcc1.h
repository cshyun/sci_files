#ifndef MCCALLBASKETRANGEACC1_H
#define MCCALLBASKETRANGEACC1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcCallBasketRangeAcc1fn(
    double B,
    const SciArray1<int>& calcGrks,
    const SciArray1<double>& CallAmount,
    double ConvFac,
    const SciArray1<double>& CoupAmount,
    const SciArray1<double>& D0,
    const SciArray1<int>& isCallDate,
    const SciArray1<int>& isCoupDate,
    const SciArray1<double>& L,
    int maxordC,
    int maxordS,
    int nD,
    int nObs,
    int nrTab,
    const SciArray1<double>& ObserveDates,
    int pMax,
    const SciArray2<double>& rho,
    const SciArray1<double>& rTab,
    const SciArray1<double>& rtTab,
    double Sbump,
    const SciArray1<double>& SFix,
    const SciArray1<double>& sigma,
    const SciArray1<double>& Spot,
    int sskip,
    double TMax,
    const SciArray1<double>& U,
    double Vbump,
    int worst,
    SciArray1<double>& Deltax,
    double & fracCalledx,
    SciArray1<double>& Gammax,
    double & meanTcallx,
    double & stdTcallx,
    double & Vx,
    SciArray1<double>& Vegax
    );
     


#endif /* MCCALLBASKETRANGEACC1_H */
