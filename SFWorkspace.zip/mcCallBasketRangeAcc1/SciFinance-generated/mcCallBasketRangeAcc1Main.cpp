

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for calcGrks in file "calcGrks.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in calcGrks(1..nD).

   The table for CallAmount in file "ObserveDates.dat" has maximum index
      nObs, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nObs elements,
      to be stored in CallAmount(1..nObs).

   The table for CoupAmount in file "ObserveDates.dat" has maximum index
      nObs, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nObs elements,
      to be stored in CoupAmount(1..nObs).

   The table for D0 in file "assets.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in D0(1..nD).

   The table for isCallDate in file "ObserveDates.dat" has maximum index
      nObs, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nObs elements,
      to be stored in isCallDate(1..nObs).

   The table for isCoupDate in file "ObserveDates.dat" has maximum index
      nObs, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nObs elements,
      to be stored in isCoupDate(1..nObs).

   The table for L in file "ObserveDates.dat" has maximum index
      nObs, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nObs elements,
      to be stored in L(1..nObs).

   The table for ObserveDates in file "ObserveDates.dat" has maximum index
      nObs, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nObs elements,
      to be stored in ObserveDates(1..nObs).

   The table for rho in file "rho.dat" has maximum indices
      nD and nD, 
     with minimum indices 1, 1 respectively.
      The index bounds are not read from this file.
        Following should be the nD^2 elements,
      to be stored in rho(1..nD, 1..nD).
   The first index is the most slowly varying and 
      the last index is the most rapidly varying.

   The table for rTab in file "rTab.dat" has maximum index
      nrTab, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nrTab elements,
      to be stored in rTab(0..nrTab).

   The table for rtTab in file "rTab.dat" has maximum index
      nrTab, 
     with minimum index 0.
      The index bounds are not read from this file.
        Following should be the 1 + nrTab elements,
      to be stored in rtTab(0..nrTab).

   The table for SFix in file "assets.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in SFix(1..nD).

   The table for sigma in file "assets.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in sigma(1..nD).

   The table for Spot in file "assets.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in Spot(1..nD).

   The table for U in file "ObserveDates.dat" has maximum index
      nObs, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nObs elements,
      to be stored in U(1..nObs).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcCallBasketRangeAcc1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcCallBasketRangeAcc1MW
#define openfilemcCallBasketRangeAcc1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcCallBasketRangeAcc1MR
#define openfilemcCallBasketRangeAcc1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcCallBasketRangeAcc1M
#define fscanfMmcCallBasketRangeAcc1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2

#undef spreadargs4
#define spreadargs4(a1,a2,a3,a4) a1,a2,a3,a4

#undef spreadargs7
#define spreadargs7(a1,a2,a3,a4,a5,a6,a7) a1,a2,a3,a4,a5,a6,a7


int main()
{
    int i,itvar1,itvar2,maxordC,maxordS,nD,nObs,nrTab,pMax,sskip;
    double B,ConvFac,fracCalledx,meanTcallx,Sbump,stdTcallx,TMax,Vbump,Vx;
    ArgumentRecord initInputTable[13];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4,*IOUNIT5,*IOUNIT6;
    int worst;
    
    /* *** Key to program variables: *** */
    /* B, calcGrks, CallAmount, ConvFac, CoupAmount, D0, fracCalledx, isCallDate, isCoupDate, L, maxordC, maxordS,      
       meanTcallx, ObserveDates, rho, rTab, rtTab, Sbump, SFix, sigma, Spot, sskip, stdTcallx, U, Vbump, worst: solution
       variable */
    /* Delta: greek for if[calcGrks, der[V, {Spot, 1}], seq[]] */
    /* Gamma: greek for if[calcGrks, der[V, {Spot, 2}], seq[]] */
    /* i: dependencies index */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5, IOUNIT6: I/O channel */
    /* nD: maximum for i */
    /* nObs: array maximum for ObserveDates, L, U, isCoupDate, CoupAmount, isCallDate and CallAmount */
    /* nrTab: array maximum for rTab and rtTab */
    /* pMax: maximum for path */
    /* TMax: maximum time */
    /* Vega: greek for if[calcGrks, der[V, {sigma, 1}], seq[]] */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcCallBasketRangeAcc1MR(IOUNIT1,"init.dat");
    setupargs(initInputTable, 0, "B", B, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "ConvFac", ConvFac, READINPUTSDOUBLE);
    setupargs(initInputTable, 2, "maxordC", maxordC, READINPUTSINTEGER);
    setupargs(initInputTable, 3, "maxordS", maxordS, READINPUTSINTEGER);
    setupargs(initInputTable, 4, "nD", nD, READINPUTSINTEGER);
    setupargs(initInputTable, 5, "nObs", nObs, READINPUTSINTEGER);
    setupargs(initInputTable, 6, "nrTab", nrTab, READINPUTSINTEGER);
    setupargs(initInputTable, 7, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 8, "Sbump", Sbump, READINPUTSDOUBLE);
    setupargs(initInputTable, 9, "sskip", sskip, READINPUTSINTEGER);
    setupargs(initInputTable, 10, "TMax", TMax, READINPUTSDOUBLE);
    setupargs(initInputTable, 11, "Vbump", Vbump, READINPUTSDOUBLE);
    setupargs(initInputTable, 12, "worst", worst, READINPUTSBOOLEAN);
    if (ReadInputs(IOUNIT1,initInputTable,13)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    SciArray1<int>calcGrks(nD + 1);
    SciArray2<double>rho(nD + 1, nD + 1);
    SciArray1<double>Spot(nD + 1);
    SciArray1<double>D0(nD + 1);
    SciArray1<double>sigma(nD + 1);
    SciArray1<double>SFix(nD + 1);
    if (nD>=1)
        {
        /* Read calcGrks from file */
        openfilemcCallBasketRangeAcc1MR(IOUNIT2,"calcGrks.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCallBasketRangeAcc1M(IOUNIT2,"%i",1,((&calcGrks(itvar1))));
        }
        fclose(IOUNIT2);
        /* Read rho from file */
        openfilemcCallBasketRangeAcc1MR(IOUNIT3,"rho.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            for (itvar2=1; itvar2<=nD; itvar2++) {
                fscanfMmcCallBasketRangeAcc1M(IOUNIT3,"%lg",1,((&rho(itvar1,itvar2))));
            }
        }
        fclose(IOUNIT3);
        /* Read Spot from file. Read D0 from file. Read sigma from file. Read SFix from file */
        openfilemcCallBasketRangeAcc1MR(IOUNIT4,"assets.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCallBasketRangeAcc1M(IOUNIT4,
               "%lg%lg%lg%lg",4,((&Spot(itvar1)),(&SFix(itvar1)),(&D0(itvar1)),(&sigma(itvar1))));
        }
        fclose(IOUNIT4);
        }
    SciArray1<double>ObserveDates(nObs + 1);
    SciArray1<double>L(nObs + 1);
    SciArray1<double>U(nObs + 1);
    SciArray1<int>isCoupDate(nObs + 1);
    SciArray1<double>CoupAmount(nObs + 1);
    SciArray1<int>isCallDate(nObs + 1);
    SciArray1<double>CallAmount(nObs + 1);
    /* Read ObserveDates from file. Read L from file. Read U from file. Read isCoupDate from file. Read CoupAmount from 
       file. Read isCallDate from file. Read CallAmount from file */
    if (nObs>=1)
        {
        openfilemcCallBasketRangeAcc1MR(IOUNIT5,"ObserveDates.dat");
        for (itvar1=1; itvar1<=nObs; itvar1++) {
            fscanfMmcCallBasketRangeAcc1M(IOUNIT5,
               "%lg%lg%lg%i%lg%i%lg"
               ,7,((&ObserveDates(itvar1)),(&L(itvar1)),(&U(itvar1)),(&isCoupDate(itvar1)),(&CoupAmount(itvar1)),(
               &isCallDate(itvar1)),(&CallAmount(itvar1))));
        }
        fclose(IOUNIT5);
        }
    SciArray1<double>rTab(nrTab + 1);
    SciArray1<double>rtTab(nrTab + 1);
    /* Read rTab from file. Read rtTab from file */
    if (nrTab>=0)
        {
        openfilemcCallBasketRangeAcc1MR(IOUNIT6,"rTab.dat");
        for (itvar1=0; itvar1<=nrTab; itvar1++) {
            fscanfMmcCallBasketRangeAcc1M(IOUNIT6,"%lg%lg",2,((&rTab(itvar1)),(&rtTab(itvar1))));
        }
        fclose(IOUNIT6);
        }
    /*                            */
    /* Call the computation function. */
    SciArray1<double> Delta;
    SciArray1<double> Gamma;
    SciArray1<double> Vega;
    mcCallBasketRangeAcc1fn(B,calcGrks,CallAmount,ConvFac,CoupAmount,D0,isCallDate,isCoupDate,L,maxordC,maxordS,nD,nObs,
       nrTab,ObserveDates,pMax,rho,rTab,rtTab,Sbump,SFix,sigma,Spot,sskip,TMax,U,Vbump,worst,Delta,fracCalledx,Gamma,
       meanTcallx,stdTcallx,Vx,Vega);
    /*                            */
    /* Writing collected output to file output.out from ResultEqc. */
    openfilemcCallBasketRangeAcc1MW(IOUNIT,"output.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file output.out from ResultEq1c. */
    for (i=1; i<=(int)Delta.size0() - 1; i++) {
        fprintf(IOUNIT, " %18.8e\n", Delta(i));
    }
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file output.out from ResultEq2c. */
    for (i=1; i<=(int)Gamma.size0() - 1; i++) {
        fprintf(IOUNIT, " %18.8e\n", Gamma(i));
    }
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file output.out from ResultEq3c. */
    for (i=1; i<=(int)Vega.size0() - 1; i++) {
        fprintf(IOUNIT, " %18.8e\n", Vega(i));
    }
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file output.out from ResultEq4c. */
    fprintf(IOUNIT, " %18.8e\n", meanTcallx);
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file output.out from ResultEq5c. */
    fprintf(IOUNIT, " %18.8e\n", stdTcallx);
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file output.out from ResultEq6c. */
    fprintf(IOUNIT, " %18.8e\n", fracCalledx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




