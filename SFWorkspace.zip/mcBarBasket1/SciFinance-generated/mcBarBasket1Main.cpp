

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for tsamp in file "tsamp.dat" has maximum index
      nsamp, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nsamp elements,
      to be stored in tsamp(1..nsamp).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcBarBasket1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcBarBasket1MW
#define openfilemcBarBasket1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcBarBasket1MR
#define openfilemcBarBasket1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcBarBasket1M
#define fscanfMmcBarBasket1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1


int main()
{
    int itvar1,nsamp,pMax,Series;
    double B,D01,D02,Delta1x,Delta2x,disc,epsilon,Gamma1x,Gamma2x,K,loan1,loan2,Rebate,rho12,sigma1,sigma2,Spot1,Spot2,
       TMax,Vx,w1,w2;
    ArgumentRecord initInputTable[20];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4,*IOUNIT5,*IOUNIT6;
    
    /* *** Key to program variables: *** */
    /* B, D01, D02, Delta1x, Delta2x, epsilon, Gamma1x, Gamma2x, K, loan1, loan2, Rebate, rho12, Series, sigma1, sigma2,
       Spot1, Spot2, tsamp, w1, w2: solution variable */
    /* disc: discount rate */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5, IOUNIT6: I/O channel */
    /* nsamp: array maximum for tsamp */
    /* pMax: maximum for path */
    /* TMax: maximum time */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcBarBasket1MR(IOUNIT5,"init.dat");
    setupargs(initInputTable, 0, "B", B, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "D01", D01, READINPUTSDOUBLE);
    setupargs(initInputTable, 2, "D02", D02, READINPUTSDOUBLE);
    setupargs(initInputTable, 3, "disc", disc, READINPUTSDOUBLE);
    setupargs(initInputTable, 4, "epsilon", epsilon, READINPUTSDOUBLE);
    setupargs(initInputTable, 5, "K", K, READINPUTSDOUBLE);
    setupargs(initInputTable, 6, "loan1", loan1, READINPUTSDOUBLE);
    setupargs(initInputTable, 7, "loan2", loan2, READINPUTSDOUBLE);
    setupargs(initInputTable, 8, "nsamp", nsamp, READINPUTSINTEGER);
    setupargs(initInputTable, 9, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 10, "Rebate", Rebate, READINPUTSDOUBLE);
    setupargs(initInputTable, 11, "rho12", rho12, READINPUTSDOUBLE);
    setupargs(initInputTable, 12, "Series", Series, READINPUTSINTEGER);
    setupargs(initInputTable, 13, "sigma1", sigma1, READINPUTSDOUBLE);
    setupargs(initInputTable, 14, "sigma2", sigma2, READINPUTSDOUBLE);
    setupargs(initInputTable, 15, "Spot1", Spot1, READINPUTSDOUBLE);
    setupargs(initInputTable, 16, "Spot2", Spot2, READINPUTSDOUBLE);
    setupargs(initInputTable, 17, "TMax", TMax, READINPUTSDOUBLE);
    setupargs(initInputTable, 18, "w1", w1, READINPUTSDOUBLE);
    setupargs(initInputTable, 19, "w2", w2, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT5,initInputTable,20)!=0)
        {
        fclose(IOUNIT5);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT5);
    /* Read tsamp from file */
    SciArray1<double>tsamp(nsamp + 1);
    if (nsamp>=1)
        {
        openfilemcBarBasket1MR(IOUNIT6,"tsamp.dat");
        for (itvar1=1; itvar1<=nsamp; itvar1++) {
            fscanfMmcBarBasket1M(IOUNIT6,"%lg",1,((&tsamp(itvar1))));
        }
        fclose(IOUNIT6);
        }
    /*                            */
    /* Call the computation function. */
    mcBarBasket1fn(B,D01,D02,Delta1x,Delta2x,disc,epsilon,Gamma1x,Gamma2x,K,loan1,loan2,nsamp,pMax,Rebate,rho12,Series,
       sigma1,sigma2,Spot1,Spot2,TMax,tsamp,w1,w2,Vx);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfilemcBarBasket1MW(IOUNIT,"V.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* Writing collected output to file Delta1.out from ResultEq1c. */
    openfilemcBarBasket1MW(IOUNIT1,"Delta1.out");
    fprintf(IOUNIT1, " %18.8e\n", Delta1x);
    fprintf(IOUNIT1, "\n");
    fclose(IOUNIT1);
    /* Writing collected output to file Delta2.out from ResultEq2c. */
    openfilemcBarBasket1MW(IOUNIT2,"Delta2.out");
    fprintf(IOUNIT2, " %18.8e\n", Delta2x);
    fprintf(IOUNIT2, "\n");
    fclose(IOUNIT2);
    /* Writing collected output to file Gamma1.out from ResultEq3c. */
    openfilemcBarBasket1MW(IOUNIT3,"Gamma1.out");
    fprintf(IOUNIT3, " %18.8e\n", Gamma1x);
    fprintf(IOUNIT3, "\n");
    fclose(IOUNIT3);
    /* Writing collected output to file Gamma2.out from ResultEq4c. */
    openfilemcBarBasket1MW(IOUNIT4,"Gamma2.out");
    fprintf(IOUNIT4, " %18.8e\n", Gamma2x);
    fprintf(IOUNIT4, "\n");
    fclose(IOUNIT4);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




