#ifndef MCBARBASKET1_H
#define MCBARBASKET1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcBarBasket1fn(
    double B,
    double D01,
    double D02,
    double & Delta1x,
    double & Delta2x,
    double disc,
    double epsilon,
    double & Gamma1x,
    double & Gamma2x,
    double K,
    double loan1,
    double loan2,
    int nsamp,
    int pMax,
    double Rebate,
    double rho12,
    int Series,
    double sigma1,
    double sigma2,
    double Spot1,
    double Spot2,
    double TMax,
    const SciArray1<double>& tsamp,
    double w1,
    double w2,
    double & Vx
    );
     


#endif /* MCBARBASKET1_H */
