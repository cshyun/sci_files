#ifndef MCBASKET3_H
#define MCBASKET3_H

#include "SciArrayN.h" /* SciComp arrays */

void mcBasket3fn(
    const SciArray1<double>& D0,
    double & DeltaRhox,
    double disc,
    double epsilon,
    double K,
    const SciArray1<double>& loan,
    int nD,
    int pMax,
    const SciArray2<double>& rho,
    int Series,
    const SciArray1<double>& sigma,
    const SciArray1<double>& Spot,
    double TMax,
    const SciArray1<double>& weight,
    double & Vx
    );
     


#endif /* MCBASKET3_H */
