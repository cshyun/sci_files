#ifndef MCCUSTOMDISC1_H
#define MCCUSTOMDISC1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcCustomDisc1fn(
    double K,
    double kappa,
    int nMax,
    int pMax,
    int put,
    double q,
    double r,
    double rhoSv,
    int Seed,
    double sigma,
    double Spot,
    double theta,
    double TMax,
    double vSpot,
    double & devx,
    double & Vx
    );
     


#endif /* MCCUSTOMDISC1_H */
