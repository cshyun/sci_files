#ifndef MCASIANRAINBOW1_H
#define MCASIANRAINBOW1_H

#include "SciArrayN.h" /* SciComp arrays */

void mcAsianRainbow1fn(
    const SciArray1<double>& D0,
    double disc,
    double K,
    const SciArray1<double>& lastA,
    const SciArray1<double>& loan,
    int nD,
    int nsampSoFar,
    int nsampToGo,
    int pMax,
    const SciArray2<double>& rho,
    int Series,
    const SciArray1<double>& sigma,
    const SciArray1<double>& Spot,
    double TMax,
    const SciArray1<double>& tsamp,
    const SciArray1<double>& weight,
    double & Vx
    );
     


#endif /* MCASIANRAINBOW1_H */
