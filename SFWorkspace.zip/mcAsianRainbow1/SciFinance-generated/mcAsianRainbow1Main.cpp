

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for D0 in file "D0.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in D0(1..nD).

   The table for lastA in file "lastA.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in lastA(1..nD).

   The table for loan in file "loan.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in loan(1..nD).

   The table for rho in file "rho.dat" has maximum indices
      nD and nD, 
     with minimum indices 1, 1 respectively.
      The index bounds are not read from this file.
        Following should be the nD^2 elements,
      to be stored in rho(1..nD, 1..nD).
   The first index is the most slowly varying and 
      the last index is the most rapidly varying.

   The table for sigma in file "sigma.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in sigma(1..nD).

   The table for Spot in file "Spot.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in Spot(1..nD).

   The table for tsamp in file "tsamp.dat" has maximum index
      nsampToGo, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nsampToGo elements,
      to be stored in tsamp(1..nsampToGo).

   The table for weight in file "weight.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in weight(1..nD).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcAsianRainbow1.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcAsianRainbow1MW
#define openfilemcAsianRainbow1MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcAsianRainbow1MR
#define openfilemcAsianRainbow1MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcAsianRainbow1M
#define fscanfMmcAsianRainbow1M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1


int main()
{
    int itvar1,itvar2,nD,nsampSoFar,nsampToGo,pMax,Series;
    double disc,K,TMax,Vx;
    ArgumentRecord initInputTable[8];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4,*IOUNIT5,*IOUNIT6,*IOUNIT7,*IOUNIT8,*IOUNIT9;
    
    /* *** Key to program variables: *** */
    /* D0, K, lastA, loan, nsampSoFar, rho, Series, sigma, Spot, tsamp, weight: solution variable */
    /* disc: discount rate */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5, IOUNIT6, IOUNIT7, IOUNIT8, IOUNIT9: I/O channel */
    /* nD: maximum for iD */
    /* nsampToGo: array maximum for tsamp */
    /* pMax: maximum for path */
    /* TMax: maximum time */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcAsianRainbow1MR(IOUNIT1,"init.dat");
    setupargs(initInputTable, 0, "disc", disc, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "K", K, READINPUTSDOUBLE);
    setupargs(initInputTable, 2, "nD", nD, READINPUTSINTEGER);
    setupargs(initInputTable, 3, "nsampSoFar", nsampSoFar, READINPUTSINTEGER);
    setupargs(initInputTable, 4, "nsampToGo", nsampToGo, READINPUTSINTEGER);
    setupargs(initInputTable, 5, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 6, "Series", Series, READINPUTSINTEGER);
    setupargs(initInputTable, 7, "TMax", TMax, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT1,initInputTable,8)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    SciArray1<double>D0(nD + 1);
    SciArray1<double>loan(nD + 1);
    SciArray2<double>rho(nD + 1, nD + 1);
    SciArray1<double>sigma(nD + 1);
    SciArray1<double>Spot(nD + 1);
    SciArray1<double>weight(nD + 1);
    SciArray1<double>lastA(nD + 1);
    if (nD>=1)
        {
        /* Read D0 from file */
        openfilemcAsianRainbow1MR(IOUNIT2,"D0.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcAsianRainbow1M(IOUNIT2,"%lg",1,((&D0(itvar1))));
        }
        fclose(IOUNIT2);
        /* Read loan from file */
        openfilemcAsianRainbow1MR(IOUNIT3,"loan.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcAsianRainbow1M(IOUNIT3,"%lg",1,((&loan(itvar1))));
        }
        fclose(IOUNIT3);
        /* Read rho from file */
        openfilemcAsianRainbow1MR(IOUNIT4,"rho.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            for (itvar2=1; itvar2<=nD; itvar2++) {
                fscanfMmcAsianRainbow1M(IOUNIT4,"%lg",1,((&rho(itvar1,itvar2))));
            }
        }
        fclose(IOUNIT4);
        /* Read sigma from file */
        openfilemcAsianRainbow1MR(IOUNIT5,"sigma.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcAsianRainbow1M(IOUNIT5,"%lg",1,((&sigma(itvar1))));
        }
        fclose(IOUNIT5);
        /* Read Spot from file */
        openfilemcAsianRainbow1MR(IOUNIT6,"Spot.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcAsianRainbow1M(IOUNIT6,"%lg",1,((&Spot(itvar1))));
        }
        fclose(IOUNIT6);
        /* Read weight from file */
        openfilemcAsianRainbow1MR(IOUNIT7,"weight.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcAsianRainbow1M(IOUNIT7,"%lg",1,((&weight(itvar1))));
        }
        fclose(IOUNIT7);
        /* Read lastA from file */
        openfilemcAsianRainbow1MR(IOUNIT8,"lastA.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcAsianRainbow1M(IOUNIT8,"%lg",1,((&lastA(itvar1))));
        }
        fclose(IOUNIT8);
        }
    /* Read tsamp from file */
    SciArray1<double>tsamp(nsampToGo + 1);
    if (nsampToGo>=1)
        {
        openfilemcAsianRainbow1MR(IOUNIT9,"tsamp.dat");
        for (itvar1=1; itvar1<=nsampToGo; itvar1++) {
            fscanfMmcAsianRainbow1M(IOUNIT9,"%lg",1,((&tsamp(itvar1))));
        }
        fclose(IOUNIT9);
        }
    /*                            */
    /* Call the computation function. */
    mcAsianRainbow1fn(D0,disc,K,lastA,loan,nD,nsampSoFar,nsampToGo,pMax,rho,Series,sigma,Spot,TMax,tsamp,weight,Vx);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfilemcAsianRainbow1MW(IOUNIT,"V.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




