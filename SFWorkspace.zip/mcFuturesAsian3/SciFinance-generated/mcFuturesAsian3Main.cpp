

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for alpha in file "AtmVolParams.dat" has maximum index
      nFut, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nFut elements,
      to be stored in alpha(1..nFut).

   The table for beta in file "AtmVolParams.dat" has maximum index
      nFut, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nFut elements,
      to be stored in beta(1..nFut).

   The table for FutMats in file "FuturesCurve.dat" has maximum index
      nFut, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nFut elements,
      to be stored in FutMats(1..nFut).

   The table for FutPrice in file "FuturesCurve.dat" has maximum index
      nFut, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nFut elements,
      to be stored in FutPrice(1..nFut).

   The table for lambda1 in file "AtmCorParams.dat" has maximum index
      nFut, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nFut elements,
      to be stored in lambda1(1..nFut).

   The table for lambda2 in file "AtmCorParams.dat" has maximum index
      nFut, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nFut elements,
      to be stored in lambda2(1..nFut).

   The table for lambda3 in file "AtmCorParams.dat" has maximum index
      nFut, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nFut elements,
      to be stored in lambda3(1..nFut).

   The table for SampleDates in file "SampleDates.dat" has maximum index
      nSamp, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nSamp elements,
      to be stored in SampleDates(1..nSamp).

   The table for SviA in file "SviVolParams.dat" has maximum index
      nFut, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nFut elements,
      to be stored in SviA(1..nFut).

   The table for SviB in file "SviVolParams.dat" has maximum index
      nFut, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nFut elements,
      to be stored in SviB(1..nFut).

   The table for SviMu in file "SviVolParams.dat" has maximum index
      nFut, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nFut elements,
      to be stored in SviMu(1..nFut).

   The table for SviRho in file "SviVolParams.dat" has maximum index
      nFut, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nFut elements,
      to be stored in SviRho(1..nFut).

   The table for SviSigma in file "SviVolParams.dat" has maximum index
      nFut, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nFut elements,
      to be stored in SviSigma(1..nFut).

   The table for Weight in file "SampleDates.dat" has maximum index
      nSamp, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nSamp elements,
      to be stored in Weight(1..nSamp).

   The table for zDate in file "ZeroCurve.dat" has maximum index
      nZero, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nZero elements,
      to be stored in zDate(1..nZero).

   The table for zRate in file "ZeroCurve.dat" has maximum index
      nZero, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nZero elements,
      to be stored in zRate(1..nZero).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcFuturesAsian3.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcFuturesAsian3MW
#define openfilemcFuturesAsian3MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcFuturesAsian3MR
#define openfilemcFuturesAsian3MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcFuturesAsian3M
#define fscanfMmcFuturesAsian3M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2

#undef spreadargs3
#define spreadargs3(a1,a2,a3) a1,a2,a3

#undef spreadargs5
#define spreadargs5(a1,a2,a3,a4,a5) a1,a2,a3,a4,a5


int main()
{
    int itvar1,nFut,nMax,nSamp,nSampInit,nTab,nZero,pMax,Seed;
    double Ainit,devx,K,Vx;
    int call;
    ArgumentRecord initInputTable[11];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4,*IOUNIT5,*IOUNIT6,*IOUNIT7;
    
    /* *** Key to program variables: *** */
    /* Ainit, alpha, beta, call, FutMats, FutPrice, K, lambda1, lambda2, lambda3, nSampInit, nTab, SampleDates, Seed,   
       SviA, SviB, SviMu, SviRho, SviSigma, Weight, zDate, zRate: solution variable */
    /* devx: standard deviation error estimate */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5, IOUNIT6, IOUNIT7: I/O channel */
    /* nFut: array maximum for alpha, beta, lambda1, lambda2, lambda3, SviA, SviB, SviMu, SviRho, SviSigma, FutMats and 
       FutPrice */
    /* nMax: number of grid cells for t */
    /* nSamp: array maximum for SampleDates and Weight */
    /* nZero: array maximum for zDate and zRate */
    /* pMax: maximum for path */
    /* Vx: discounted value */
    try {
    /* Read Tagged Input File */
    openfilemcFuturesAsian3MR(IOUNIT1,"init.dat");
    setupargs(initInputTable, 0, "Ainit", Ainit, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "call", call, READINPUTSBOOLEAN);
    setupargs(initInputTable, 2, "K", K, READINPUTSDOUBLE);
    setupargs(initInputTable, 3, "nFut", nFut, READINPUTSINTEGER);
    setupargs(initInputTable, 4, "nMax", nMax, READINPUTSINTEGER);
    setupargs(initInputTable, 5, "nSamp", nSamp, READINPUTSINTEGER);
    setupargs(initInputTable, 6, "nSampInit", nSampInit, READINPUTSINTEGER);
    setupargs(initInputTable, 7, "nTab", nTab, READINPUTSINTEGER);
    setupargs(initInputTable, 8, "nZero", nZero, READINPUTSINTEGER);
    setupargs(initInputTable, 9, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 10, "Seed", Seed, READINPUTSINTEGER);
    if (ReadInputs(IOUNIT1,initInputTable,11)!=0)
        {
        fclose(IOUNIT1);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT1);
    SciArray1<double>alpha(nFut + 1);
    SciArray1<double>beta(nFut + 1);
    SciArray1<double>FutMats(nFut + 1);
    SciArray1<double>FutPrice(nFut + 1);
    SciArray1<double>SviA(nFut + 1);
    SciArray1<double>SviB(nFut + 1);
    SciArray1<double>SviMu(nFut + 1);
    SciArray1<double>SviRho(nFut + 1);
    SciArray1<double>SviSigma(nFut + 1);
    SciArray1<double>lambda1(nFut + 1);
    SciArray1<double>lambda3(nFut + 1);
    SciArray1<double>lambda2(nFut + 1);
    if (nFut>=1)
        {
        /* Read alpha from file. Read beta from file */
        openfilemcFuturesAsian3MR(IOUNIT2,"AtmVolParams.dat");
        for (itvar1=1; itvar1<=nFut; itvar1++) {
            fscanfMmcFuturesAsian3M(IOUNIT2,"%lg%lg",2,((&alpha(itvar1)),(&beta(itvar1))));
        }
        fclose(IOUNIT2);
        /* Read FutMats from file. Read FutPrice from file */
        openfilemcFuturesAsian3MR(IOUNIT3,"FuturesCurve.dat");
        for (itvar1=1; itvar1<=nFut; itvar1++) {
            fscanfMmcFuturesAsian3M(IOUNIT3,"%lg%lg",2,((&FutMats(itvar1)),(&FutPrice(itvar1))));
        }
        fclose(IOUNIT3);
        /* Read SviA from file. Read SviB from file. Read SviMu from file. Read SviRho from file. Read SviSigma from    
           file */
        openfilemcFuturesAsian3MR(IOUNIT4,"SviVolParams.dat");
        for (itvar1=1; itvar1<=nFut; itvar1++) {
            fscanfMmcFuturesAsian3M(IOUNIT4,
               "%lg%lg%lg%lg%lg"
               ,5,((&SviA(itvar1)),(&SviB(itvar1)),(&SviMu(itvar1)),(&SviRho(itvar1)),(&SviSigma(itvar1))));
        }
        fclose(IOUNIT4);
        /* Read lambda1 from file. Read lambda3 from file. Read lambda2 from file */
        openfilemcFuturesAsian3MR(IOUNIT5,"AtmCorParams.dat");
        for (itvar1=1; itvar1<=nFut; itvar1++) {
            fscanfMmcFuturesAsian3M(IOUNIT5,"%lg%lg%lg",3,((&lambda1(itvar1)),(&lambda2(itvar1)),(&lambda3(itvar1))));
        }
        fclose(IOUNIT5);
        }
    SciArray1<double>SampleDates(nSamp + 1);
    SciArray1<double>Weight(nSamp + 1);
    /* Read SampleDates from file. Read Weight from file */
    if (nSamp>=1)
        {
        openfilemcFuturesAsian3MR(IOUNIT6,"SampleDates.dat");
        for (itvar1=1; itvar1<=nSamp; itvar1++) {
            fscanfMmcFuturesAsian3M(IOUNIT6,"%lg%lg",2,((&SampleDates(itvar1)),(&Weight(itvar1))));
        }
        fclose(IOUNIT6);
        }
    SciArray1<double>zDate(nZero + 1);
    SciArray1<double>zRate(nZero + 1);
    /* Read zDate from file. Read zRate from file */
    if (nZero>=1)
        {
        openfilemcFuturesAsian3MR(IOUNIT7,"ZeroCurve.dat");
        for (itvar1=1; itvar1<=nZero; itvar1++) {
            fscanfMmcFuturesAsian3M(IOUNIT7,"%lg%lg",2,((&zDate(itvar1)),(&zRate(itvar1))));
        }
        fclose(IOUNIT7);
        }
    /*                            */
    /* Call the computation function. */
    mcFuturesAsian3fn(Ainit,alpha,beta,call,FutMats,FutPrice,K,lambda1,lambda2,lambda3,nFut,nMax,nSamp,nSampInit,nTab,
       nZero,pMax,SampleDates,Seed,SviA,SviB,SviMu,SviRho,SviSigma,Weight,zDate,zRate,devx,Vx);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfilemcFuturesAsian3MW(IOUNIT,"V.out");
    fprintf(IOUNIT, " %18.8e\n", Vx);
    fprintf(IOUNIT, "\n");
    /* Writing collected output to file V.out from ResultEq1c. */
    fprintf(IOUNIT, " %18.8e\n", devx);
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




