#ifndef MCFUTURESASIAN3_H
#define MCFUTURESASIAN3_H

#include "SciArrayN.h" /* SciComp arrays */

void mcFuturesAsian3fn(
    double Ainit,
    const SciArray1<double>& alpha,
    const SciArray1<double>& beta,
    int call,
    SciArray1<double>& FutMats,
    SciArray1<double>& FutPrice,
    double K,
    const SciArray1<double>& lambda1,
    const SciArray1<double>& lambda2,
    const SciArray1<double>& lambda3,
    int nFut,
    int nMax,
    int nSamp,
    int nSampInit,
    int nTab,
    int nZero,
    int pMax,
    const SciArray1<double>& SampleDates,
    int Seed,
    SciArray1<double>& SviA,
    SciArray1<double>& SviB,
    SciArray1<double>& SviMu,
    SciArray1<double>& SviRho,
    SciArray1<double>& SviSigma,
    const SciArray1<double>& Weight,
    const SciArray1<double>& zDate,
    const SciArray1<double>& zRate,
    double & devx,
    double & Vx
    );
     


#endif /* MCFUTURESASIAN3_H */
