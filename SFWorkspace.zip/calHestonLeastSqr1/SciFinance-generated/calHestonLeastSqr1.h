#ifndef CALHESTONLEASTSQR1_H
#define CALHESTONLEASTSQR1_H

#include "SciStdIncludes.h"
#include "SciArrayN.h" /* SciComp arrays */

int calHestonLeastSqr1fnC(
    double ***CalibOptsxC,
    double *dateCurveC,
    double ftol,
    double **MarketFitxC,
    int nCol,
    int nCurve,
    int nOpt,
    double **OptionMatrixC,
    double **ParamsxC,
    double penalty,
    double *pGuessC,
    double *pMaxC,
    double *pMinC,
    double *rdCurveC,
    double *rfCurveC,
    double S0,
    double xtol,
    int *infox,
    int *nDx,
    int *nfevx,
    double *RMSFitx,
    int *tmpx
    );
     


#endif /* CALHESTONLEASTSQR1_H */
