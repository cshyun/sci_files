#ifndef FXCBOND2_H
#define FXCBOND2_H

#include "SciArrayN.h" /* SciComp arrays */

void FXCBond2fn(
    double Accuracy,
    double alphaS,
    double alphaX,
    double callPrice,
    const SciArray1<double>& coupTab,
    const SciArray1<double>& couptTab,
    double CR,
    double D0,
    const SciArray1<double>& divAmounts,
    const SciArray1<double>& divTimes,
    int iMax,
    int jMax,
    int ncoup,
    int nMax,
    int nput,
    int numdiv,
    double parValue,
    double protPrice,
    const SciArray1<double>& putTab,
    const SciArray1<double>& puttTab,
    double rdfree,
    double rffree,
    double rho,
    double sigmaS,
    double sigmaX,
    double SMax,
    double SMin,
    double Spot,
    double spread,
    double tcallStart,
    double TMax,
    double tolPG,
    double tolSOR,
    double XMax,
    double XMin,
    double XSpot,
    double & atSpotx,
    double & atSpot1x,
    double & atSpot2x,
    SciArray1<double>& Sx,
    SciArray2<double>& Vx,
    SciArray1<double>& Xx
    );
     


#endif /* FXCBOND2_H */
