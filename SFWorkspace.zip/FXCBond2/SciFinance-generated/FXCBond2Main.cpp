/*** Key to program variables: ***
  Accuracy: solution variable; an input
  alphaS: solution variable; an input
  alphaX: solution variable; an input
  callPrice: solution variable; an input
  coupTab: solution variable; an input
  couptTab: Sample array for Exercise; an input
  CR: solution variable; an input
  D0: solution variable; an input
  divAmounts: solution variable; an input
  divTimes: Sample array for DividendAtEnd; an input
  iMax: number of grid cells for x; an input
  jMax: number of grid cells for y; an input
  ncoup: array maximum for coupTab and couptTab; an input
  nMax: number of grid cells for tau; an input
  nput: array maximum for putTab and puttTab; an input
  numdiv: array maximum for divAmounts and divTimes; an input
  parValue: solution variable; an input
  protPrice: solution variable; an input
  putTab: solution variable; an input
  puttTab: Sample array for Exercise; an input
  rdfree: solution variable; an input
  rffree: solution variable; an input
  rho: solution variable; an input
  sigmaS: solution variable; an input
  sigmaX: solution variable; an input
  SMax: solution variable; an input
  SMin: solution variable; an input
  Spot: solution variable; an input
  spread: solution variable; an input
  tcallStart: solution variable; an input
  TMax: minimum physical value in dimension tau; an input
  tolPG: solution variable; an input
  tolSOR: solution variable; an input
  XMax: solution variable; an input
  XMin: solution variable; an input
  XSpot: solution variable; an input
  atSpotx: solution variable; an output
  atSpot1x: solution variable; an output
  atSpot2x: solution variable; an output
  Sx: solution variable; an output
  Vx: solution variable; an output
  Xx: solution variable; an output
*** end Key to program variables: ***/


/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for coupTab in file "coupTable.dat" has maximum index
      ncoup, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the ncoup elements,
      to be stored in coupTab(1..ncoup).

   The table for couptTab in file "coupTable.dat" has maximum index
      ncoup, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the ncoup elements,
      to be stored in couptTab(1..ncoup).

   The table for divAmounts in file "tdiv.dat" has maximum index
      numdiv, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the numdiv elements,
      to be stored in divAmounts(1..numdiv).

   The table for divTimes in file "tdiv.dat" has maximum index
      numdiv, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the numdiv elements,
      to be stored in divTimes(1..numdiv).

   The table for putTab in file "putTable.dat" has maximum index
      nput, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nput elements,
      to be stored in putTab(1..nput).

   The table for puttTab in file "putTable.dat" has maximum index
      nput, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nput elements,
      to be stored in puttTab(1..nput).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "FXCBond2.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfileFXCBond2MW
#define openfileFXCBond2MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfileFXCBond2MR
#define openfileFXCBond2MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMFXCBond2M
#define fscanfMFXCBond2M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2


int main()
{
    int i5,iMax,itvar1,j,jMax,ncoup,nMax,nput,numdiv;
    double Accuracy,alphaS,alphaX,atSpot1x,atSpot2x,atSpotx,callPrice,CR,D0,parValue,protPrice,rdfree,rffree,rho,sigmaS,
       sigmaX,SMax,SMin,Spot,spread,tcallStart,TMax,tolPG,tolSOR,XMax,XMin,XSpot;
    ArgumentRecord fxbond2InputTable[30];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT2,*IOUNIT3,*IOUNIT4,*IOUNIT5;
    
    /* *** Key to program variables: *** */
    /* Accuracy, alphaS, alphaX, atSpot1x, atSpot2x, atSpotx, callPrice, coupTab, CR, D0, divAmounts, parValue,         
       protPrice, putTab, rdfree, rffree, rho, sigmaS, sigmaX, SMax, SMin, Spot, spread, tcallStart, tolPG, tolSOR, V,  
       XMax, XMin, XSpot: solution variable */
    /* couptTab, puttTab: Sample array for Exercise */
    /* divTimes: Sample array for DividendAtEnd */
    /* i5: index variable for x */
    /* iMax: number of grid cells for x */
    /* IOUNIT, IOUNIT1, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5: I/O channel */
    /* j: index variable for y */
    /* jMax: number of grid cells for y */
    /* ncoup: array maximum for coupTab and couptTab */
    /* nMax: number of grid cells for tau */
    /* nput: array maximum for putTab and puttTab */
    /* numdiv: array maximum for divAmounts and divTimes */
    /* TMax: minimum physical value in dimension tau */
    try {
    /* Read Tagged Input File */
    openfileFXCBond2MR(IOUNIT2,"fxbond2.dat");
    setupargs(fxbond2InputTable, 0, "Accuracy", Accuracy, READINPUTSDOUBLE);
    setupargs(fxbond2InputTable, 1, "alphaS", alphaS, READINPUTSDOUBLE);
    setupargs(fxbond2InputTable, 2, "alphaX", alphaX, READINPUTSDOUBLE);
    setupargs(fxbond2InputTable, 3, "callPrice", callPrice, READINPUTSDOUBLE);
    setupargs(fxbond2InputTable, 4, "CR", CR, READINPUTSDOUBLE);
    setupargs(fxbond2InputTable, 5, "D0", D0, READINPUTSDOUBLE);
    setupargs(fxbond2InputTable, 6, "iMax", iMax, READINPUTSINTEGER);
    setupargs(fxbond2InputTable, 7, "jMax", jMax, READINPUTSINTEGER);
    setupargs(fxbond2InputTable, 8, "ncoup", ncoup, READINPUTSINTEGER);
    setupargs(fxbond2InputTable, 9, "nMax", nMax, READINPUTSINTEGER);
    setupargs(fxbond2InputTable, 10, "nput", nput, READINPUTSINTEGER);
    setupargs(fxbond2InputTable, 11, "numdiv", numdiv, READINPUTSINTEGER);
    setupargs(fxbond2InputTable, 12, "parValue", parValue, READINPUTSDOUBLE);
    setupargs(fxbond2InputTable, 13, "protPrice", protPrice, READINPUTSDOUBLE);
    setupargs(fxbond2InputTable, 14, "rdfree", rdfree, READINPUTSDOUBLE);
    setupargs(fxbond2InputTable, 15, "rffree", rffree, READINPUTSDOUBLE);
    setupargs(fxbond2InputTable, 16, "rho", rho, READINPUTSDOUBLE);
    setupargs(fxbond2InputTable, 17, "sigmaS", sigmaS, READINPUTSDOUBLE);
    setupargs(fxbond2InputTable, 18, "sigmaX", sigmaX, READINPUTSDOUBLE);
    setupargs(fxbond2InputTable, 19, "SMax", SMax, READINPUTSDOUBLE);
    setupargs(fxbond2InputTable, 20, "SMin", SMin, READINPUTSDOUBLE);
    setupargs(fxbond2InputTable, 21, "Spot", Spot, READINPUTSDOUBLE);
    setupargs(fxbond2InputTable, 22, "spread", spread, READINPUTSDOUBLE);
    setupargs(fxbond2InputTable, 23, "tcallStart", tcallStart, READINPUTSDOUBLE);
    setupargs(fxbond2InputTable, 24, "TMax", TMax, READINPUTSDOUBLE);
    setupargs(fxbond2InputTable, 25, "tolPG", tolPG, READINPUTSDOUBLE);
    setupargs(fxbond2InputTable, 26, "tolSOR", tolSOR, READINPUTSDOUBLE);
    setupargs(fxbond2InputTable, 27, "XMax", XMax, READINPUTSDOUBLE);
    setupargs(fxbond2InputTable, 28, "XMin", XMin, READINPUTSDOUBLE);
    setupargs(fxbond2InputTable, 29, "XSpot", XSpot, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT2,fxbond2InputTable,30)!=0)
        {
        fclose(IOUNIT2);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT2);
    SciArray1<double>couptTab(ncoup + 1);
    SciArray1<double>coupTab(ncoup + 1);
    /* Read couptTab from file. Read coupTab from file */
    if (ncoup>=1)
        {
        openfileFXCBond2MR(IOUNIT3,"coupTable.dat");
        for (itvar1=1; itvar1<=ncoup; itvar1++) {
            fscanfMFXCBond2M(IOUNIT3,"%lg%lg",2,((&couptTab(itvar1)),(&coupTab(itvar1))));
        }
        fclose(IOUNIT3);
        }
    SciArray1<double>puttTab(nput + 1);
    SciArray1<double>putTab(nput + 1);
    /* Read puttTab from file. Read putTab from file */
    if (nput>=1)
        {
        openfileFXCBond2MR(IOUNIT4,"putTable.dat");
        for (itvar1=1; itvar1<=nput; itvar1++) {
            fscanfMFXCBond2M(IOUNIT4,"%lg%lg",2,((&puttTab(itvar1)),(&putTab(itvar1))));
        }
        fclose(IOUNIT4);
        }
    SciArray1<double>divAmounts(numdiv + 1);
    SciArray1<double>divTimes(numdiv + 1);
    /* Read divAmounts from file. Read divTimes from file */
    if (numdiv>=1)
        {
        openfileFXCBond2MR(IOUNIT5,"tdiv.dat");
        for (itvar1=1; itvar1<=numdiv; itvar1++) {
            fscanfMFXCBond2M(IOUNIT5,"%lg%lg",2,((&divAmounts(itvar1)),(&divTimes(itvar1))));
        }
        fclose(IOUNIT5);
        }
    /*                            */
    /* Call the computation function. */
    SciArray1<double> S;
    SciArray2<double> V;
    SciArray1<double> X;
    FXCBond2fn(Accuracy,alphaS,alphaX,callPrice,coupTab,couptTab,CR,D0,divAmounts,divTimes,iMax,jMax,ncoup,nMax,nput,
       numdiv,parValue,protPrice,putTab,puttTab,rdfree,rffree,rho,sigmaS,sigmaX,SMax,SMin,Spot,spread,tcallStart,TMax,
       tolPG,tolSOR,XMax,XMin,XSpot,atSpotx,atSpot1x,atSpot2x,S,V,X);
    /*                            */
    /* Writing collected output to file V.out from ResultEqc. */
    openfileFXCBond2MW(IOUNIT,"V.out");
    for (i5=0; i5<=(int)V.size0() - 1; i5++) {
        for (j=0; j<=(int)V.size1() - 1; j++) {
            fprintf(IOUNIT, " %g %18.8e %18.8e %18.8e\n", 0.,S(i5),X(j),V(i5,j));
        }
    }
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* Writing collected output to file atSpot.out from ResultEq1c. */
    openfileFXCBond2MW(IOUNIT1,"atSpot.out");
    fprintf(IOUNIT1, " %g %18.8e %18.8e %18.8e\n", 0.,Spot,XSpot,atSpotx);
    fprintf(IOUNIT1, "\n");
    /* Writing collected output to file atSpot.out from ResultEq2c. */
    fprintf(IOUNIT1, " %g %18.8e %18.8e %18.8e\n", 0.,Spot,XSpot,atSpot1x);
    fprintf(IOUNIT1, "\n");
    /* Writing collected output to file atSpot.out from ResultEq3c. */
    fprintf(IOUNIT1, " %g %18.8e %18.8e %18.8e\n", 0.,Spot,XSpot,atSpot2x);
    fprintf(IOUNIT1, "\n");
    fclose(IOUNIT1);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




