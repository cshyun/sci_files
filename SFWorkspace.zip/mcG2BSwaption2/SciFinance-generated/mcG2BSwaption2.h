#ifndef MCG2BSWAPTION2_H
#define MCG2BSWAPTION2_H

#include "SciArrayN.h" /* SciComp arrays */

void mcG2BSwaption2fn(
    double cap,
    double flr,
    double gear,
    double K,
    double kappa1,
    double kappa2,
    int maxord1,
    int maxord2,
    int nExer,
    int nMax,
    double Notional,
    int nSwap,
    int nZero,
    int payer,
    int pMax,
    double rho12,
    int Series,
    double sigma1,
    double sigma2,
    double spread,
    const SciArray1<double>& SwapDates,
    const SciArray1<double>& zDates,
    const SciArray1<double>& zRates,
    double & Vx
    );
     


#endif /* MCG2BSWAPTION2_H */
