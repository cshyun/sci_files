#ifndef MCCSO5_H
#define MCCSO5_H

#include "SciArrayN.h" /* SciComp arrays */

void mcCSO5fn(
    const SciArray2<double>& CopR,
    const SciArray1<double>& Detach,
    const SciArray1<int>& Dswitch,
    double greekFD,
    const SciArray1<double>& h,
    int leap,
    int nC,
    int nD,
    const SciArray1<double>& Notional,
    int nT,
    int nZ,
    int pMax,
    const SciArray1<double>& Recovery,
    const SciArray1<double>& RSpread,
    int sskip,
    const SciArray1<double>& tC,
    const SciArray1<double>& TCurve,
    double TMax,
    double UFee,
    const SciArray1<double>& ZCurve,
    SciArray1<double>& Deltax,
    SciArray1<double>& FairValuex,
    SciArray1<double>& FSpreadx,
    SciArray1<double>& LossValuex,
    SciArray1<double>& PremValuex
    );
     


#endif /* MCCSO5_H */
