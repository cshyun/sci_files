

/**************  ARRAY FORMAT INSTRUCTIONS **************

Please use the following information to check carefully the formats
  of your arrays.  Although all arrays are dimensioned from 0,
  ReadArray arrays are filled from 0 unless specified otherwise.
  ReadFile arrays are filled from 1; ReadTable arrays, from 0.
  ReadTable files contain a maximum *index* (not number of items) count.

If you modify the code to input arrays directly, please check
  that the initializations fill from 0 or 1 as appropriate.

                          ****

   The table for CopR in file "CopR.dat" has maximum indices
      nD and nD, 
     with minimum indices 1, 1 respectively.
      The index bounds are not read from this file.
        Following should be the nD^2 elements,
      to be stored in CopR(1..nD, 1..nD).
   The first index is the most slowly varying and 
      the last index is the most rapidly varying.

   The table for Detach in file "Detachment.dat" has maximum index
      nT, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nT elements,
      to be stored in Detach(1..nT).

   The table for Dswitch in file "Dswitch.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in Dswitch(1..nD).

   The table for h in file "hCurves.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in h(1..nD).

   The table for Notional in file "Notional.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in Notional(1..nD).

   The table for Recovery in file "Recovery.dat" has maximum index
      nD, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nD elements,
      to be stored in Recovery(1..nD).

   The table for RSpread in file "RSpread.dat" has maximum index
      nT, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nT elements,
      to be stored in RSpread(1..nT).

   The table for tC in file "PayDates.dat" has maximum index
      nC, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nC elements,
      to be stored in tC(1..nC).

   The table for TCurve in file "ZCurve.dat" has maximum index
      nZ, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nZ elements,
      to be stored in TCurve(1..nZ).

   The table for ZCurve in file "ZCurve.dat" has maximum index
      nZ, 
     with minimum index 1.
      The index bounds are not read from this file.
        Following should be the nZ elements,
      to be stored in ZCurve(1..nZ).


******************* END FORMAT INSTRUCTIONS *******************/


#include "SciStdIncludes.h"
#include "SciArrayN.h"
#include "mcCSO5.h"
#include "TaggedInput.h"

/* Define macro to check errors on opening file for writing */
#undef openfilemcCSO5MW
#define openfilemcCSO5MW(stream, file) \
   (stream) = fopen((file), "w");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for writing.");\
       }

/* Define macro to check errors on opening file for reading */
#undef openfilemcCSO5MR
#define openfilemcCSO5MR(stream, file) \
   (stream) = fopen((file), "r");\
   if ((stream) == NULL)\
       {\
	throw new SciFileException(FileOpenError, "%s%s%s",\
	"Cannot open file ", (file), " for reading.");\
       }

/* Define macro to check errors on reading input line */
#undef fscanfMmcCSO5M
#define fscanfMmcCSO5M(file, format, numvars, vars) \
   if (fscanf((file), (format), spreadargs##numvars vars) != (numvars))\
       {\
        throw new SciErrorException(fscanfError, \
            "%s%s%s%s\n","Input error while reading ", #vars,\
              " from ", #file);\
       }


#undef spreadargs1
#define spreadargs1(a1) a1

#undef spreadargs2
#define spreadargs2(a1,a2) a1,a2


int main()
{
    int i,iT,itvar1,itvar2,leap,nC,nD,nT,nZ,pMax,sskip;
    double greekFD,TMax,UFee;
    ArgumentRecord initInputTable[10];
    FILE *IOUNIT,*IOUNIT1,*IOUNIT10,*IOUNIT11,*IOUNIT12,*IOUNIT13,*IOUNIT14,*IOUNIT2,*IOUNIT3,*IOUNIT4,*IOUNIT5,*IOUNIT6
       ,*IOUNIT7,*IOUNIT8,*IOUNIT9;
    
    /* *** Key to program variables: *** */
    /* CopR, Delta, Detach, Dswitch, FairValue, FSpread, greekFD, h, leap, Notional, Recovery, RSpread, sskip, tC,      
       TCurve, UFee, ZCurve: solution variable */
    /* i: index variable for CopR */
    /* IOUNIT, IOUNIT1, IOUNIT10, IOUNIT11, IOUNIT12, IOUNIT13, IOUNIT14, IOUNIT2, IOUNIT3, IOUNIT4, IOUNIT5, IOUNIT6,  
       IOUNIT7, IOUNIT8, IOUNIT9: I/O channel */
    /* iT: vector index */
    /* LossValue, PremValue: discounted value */
    /* nC: array maximum for tC */
    /* nD: array maximum for CopR and h */
    /* nT: maximum for iT */
    /* nZ: array maximum for ZCurve and TCurve */
    /* pMax: maximum for path */
    /* TMax: maximum time */
    try {
    /* Read Tagged Input File */
    openfilemcCSO5MR(IOUNIT5,"init.dat");
    setupargs(initInputTable, 0, "greekFD", greekFD, READINPUTSDOUBLE);
    setupargs(initInputTable, 1, "leap", leap, READINPUTSINTEGER);
    setupargs(initInputTable, 2, "nC", nC, READINPUTSINTEGER);
    setupargs(initInputTable, 3, "nD", nD, READINPUTSINTEGER);
    setupargs(initInputTable, 4, "nT", nT, READINPUTSINTEGER);
    setupargs(initInputTable, 5, "nZ", nZ, READINPUTSINTEGER);
    setupargs(initInputTable, 6, "pMax", pMax, READINPUTSINTEGER);
    setupargs(initInputTable, 7, "sskip", sskip, READINPUTSINTEGER);
    setupargs(initInputTable, 8, "TMax", TMax, READINPUTSDOUBLE);
    setupargs(initInputTable, 9, "UFee", UFee, READINPUTSDOUBLE);
    if (ReadInputs(IOUNIT5,initInputTable,10)!=0)
        {
        fclose(IOUNIT5);
        throw new SciErrorException(		"ReadInput failed",TaggedInputError);
        }
    fclose(IOUNIT5);
    SciArray2<double>CopR(nD + 1, nD + 1);
    SciArray1<int>Dswitch(nD + 1);
    SciArray1<double>h(nD + 1);
    SciArray1<double>Notional(nD + 1);
    SciArray1<double>Recovery(nD + 1);
    if (nD>=1)
        {
        /* Read CopR from file */
        openfilemcCSO5MR(IOUNIT6,"CopR.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            for (itvar2=1; itvar2<=nD; itvar2++) {
                fscanfMmcCSO5M(IOUNIT6,"%lg",1,((&CopR(itvar1,itvar2))));
            }
        }
        fclose(IOUNIT6);
        /* Read Dswitch from file */
        openfilemcCSO5MR(IOUNIT7,"Dswitch.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCSO5M(IOUNIT7,"%i",1,((&Dswitch(itvar1))));
        }
        fclose(IOUNIT7);
        /* Read h from file */
        openfilemcCSO5MR(IOUNIT8,"hCurves.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCSO5M(IOUNIT8,"%lg",1,((&h(itvar1))));
        }
        fclose(IOUNIT8);
        /* Read Notional from file */
        openfilemcCSO5MR(IOUNIT9,"Notional.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCSO5M(IOUNIT9,"%lg",1,((&Notional(itvar1))));
        }
        fclose(IOUNIT9);
        /* Read Recovery from file */
        openfilemcCSO5MR(IOUNIT10,"Recovery.dat");
        for (itvar1=1; itvar1<=nD; itvar1++) {
            fscanfMmcCSO5M(IOUNIT10,"%lg",1,((&Recovery(itvar1))));
        }
        fclose(IOUNIT10);
        }
    /* Read Detach from file */
    SciArray1<double>Detach(nT + 1);
    if (nT>=1)
        {
        openfilemcCSO5MR(IOUNIT11,"Detachment.dat");
        for (itvar1=1; itvar1<=nT; itvar1++) {
            fscanfMmcCSO5M(IOUNIT11,"%lg",1,((&Detach(itvar1))));
        }
        fclose(IOUNIT11);
        }
    /* Read tC from file */
    SciArray1<double>tC(nC + 1);
    if (nC>=1)
        {
        openfilemcCSO5MR(IOUNIT12,"PayDates.dat");
        for (itvar1=1; itvar1<=nC; itvar1++) {
            fscanfMmcCSO5M(IOUNIT12,"%lg",1,((&tC(itvar1))));
        }
        fclose(IOUNIT12);
        }
    /* Read RSpread from file */
    SciArray1<double>RSpread(nT + 1);
    if (nT>=1)
        {
        openfilemcCSO5MR(IOUNIT13,"RSpread.dat");
        for (itvar1=1; itvar1<=nT; itvar1++) {
            fscanfMmcCSO5M(IOUNIT13,"%lg",1,((&RSpread(itvar1))));
        }
        fclose(IOUNIT13);
        }
    SciArray1<double>ZCurve(nZ + 1);
    SciArray1<double>TCurve(nZ + 1);
    /* Read ZCurve from file. Read TCurve from file */
    if (nZ>=1)
        {
        openfilemcCSO5MR(IOUNIT14,"ZCurve.dat");
        for (itvar1=1; itvar1<=nZ; itvar1++) {
            fscanfMmcCSO5M(IOUNIT14,"%lg%lg",2,((&ZCurve(itvar1)),(&TCurve(itvar1))));
        }
        fclose(IOUNIT14);
        }
    /*                            */
    /* Call the computation function. */
    SciArray1<double> Delta;
    SciArray1<double> FairValue;
    SciArray1<double> FSpread;
    SciArray1<double> LossValue;
    SciArray1<double> PremValue;
    mcCSO5fn(CopR,Detach,Dswitch,greekFD,h,leap,nC,nD,Notional,nT,nZ,pMax,Recovery,RSpread,sskip,tC,TCurve,TMax,UFee,
       ZCurve,Delta,FairValue,FSpread,LossValue,PremValue);
    /*                            */
    /* Writing collected output to file FairValue.out from ResultEqc. */
    openfilemcCSO5MW(IOUNIT,"FairValue.out");
    for (iT=1; iT<=(int)FairValue.size0() - 1; iT++) {
        fprintf(IOUNIT, " %18.8e\n", FairValue(iT));
    }
    fprintf(IOUNIT, "\n");
    fclose(IOUNIT);
    /* Writing collected output to file PremValue.out from ResultEq1c. */
    openfilemcCSO5MW(IOUNIT1,"PremValue.out");
    for (iT=1; iT<=(int)PremValue.size0() - 1; iT++) {
        fprintf(IOUNIT1, " %18.8e\n", PremValue(iT));
    }
    fprintf(IOUNIT1, "\n");
    fclose(IOUNIT1);
    /* Writing collected output to file LossValue.out from ResultEq2c. */
    openfilemcCSO5MW(IOUNIT2,"LossValue.out");
    for (iT=1; iT<=(int)LossValue.size0() - 1; iT++) {
        fprintf(IOUNIT2, " %18.8e\n", LossValue(iT));
    }
    fprintf(IOUNIT2, "\n");
    fclose(IOUNIT2);
    /* Writing collected output to file FairSpread.out from ResultEq3c. */
    openfilemcCSO5MW(IOUNIT3,"FairSpread.out");
    for (iT=1; iT<=(int)FSpread.size0() - 1; iT++) {
        fprintf(IOUNIT3, " %18.8e\n", FSpread(iT));
    }
    fprintf(IOUNIT3, "\n");
    fclose(IOUNIT3);
    /* Writing collected output to file Delta.out from ResultEq4c. */
    openfilemcCSO5MW(IOUNIT4,"Delta.out");
    for (i=1; i<=(int)Delta.size0() - 1; i++) {
        fprintf(IOUNIT4, " %18.8e\n", Delta(i));
    }
    fprintf(IOUNIT4, "\n");
    fclose(IOUNIT4);
    /* end try */
    }
    catch(SciErrorException* ex1)
	{
	// Handle exceptions thrown by SF core code
	printf(
       "%s\n", ex1->getMessage());
	int rc = ex1->getErrorType();
	delete ex1;
	return rc;
	}
    catch(SciException* ex2)
	{
	// Handle any exceptions thrown by call-backs
	printf(
       "%s\n", ex2->getMessage());
	delete ex2;
	return -1;
	}
    return 0;
}




